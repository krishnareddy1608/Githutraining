/*
Database : PT5G_CENTRAL
Procedure: PopulateMarketUserReportsSubscription
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `PopulateMarketUserReportsSubscription`(pReportName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pReportOwner text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pExecuteReportAs text CHARACTER SET utf8 COLLATE utf8_bin NULL, pVendor varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pEnvironment varchar(10) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pReportSchedulerHostName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pConfidenceLevel int(11) NOT NULL, pIsEnable char(1) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL) RETURNS void AS
  DECLARE

/*!
	PROCEDURE NAME       : PopulateMarketUserReportsSubscription
	DATE CREATED         : DEC 22, 2023
	AUTHOR			   	 : Mehul Mehta
	PROCEDURE DESC	   	 : User Report Subscription - NTSCA-26827
						 : Example invocation - CALL PopulateMarketUserReportsSubscription('ERC_HQ_Market','hq',NULL,'Ericsson(5G)','5G','192.168.224.2',75,'Y');
							The procedure will do the following.
							1. Lookup REPORT_NAME from REPORT table for a given USER_NAME.
								1.1 - If report does not exist, then exit with ERROR
							2. Check to see if this report already exists in the USER_REPORTS_SUBSCRIPTION table.
								2.1 - If exists, then exit with ERROR
								2.2 - If not exists, continue
							3. Retrive groups for the report and populate USER_REPORTS_SUBSCRIPTION table 	
								3.1 - checking for each individual market
								3.2 - Checking for active groups for the new Report for the specific market
									3.2.1 - If active group exists, then records inserted into USER_REPORTS_SUBSCRIPTION table.
									3.2.2 - If not exists, then exit with ERROR
	VERSION              : V1
	MODIFICATION HISTORY : Mar 21, 2024 NTSCA-29332 manohkr - Implemented changes to detect GROUPS if the report has no formulas
						   Oct 19, 2024 NTSCA-34197 pownrvi - Implemented union query for optimization
						   Nov 12, 2024 NTSCA-32999 pownrvi - adding Confidence Level
						   Nov 26, 2024 NTSCA-35300 pownrvi - Subscriptions - Implementing SCHEDULER_HOST in USER_REPORTS_SUBSCRIPTION
*/  
	vSessionIdentifier             VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel                   VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime             DATETIME(6);  
	vReportExists                  INT;
	vSql                           LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vReportUrl                     TEXT CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vrowcount                      BIGINT DEFAULT 0;
	vTemplateID                    BIGINT;
	vActiveGroup                   LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActiveGroup2                  LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vVendorDatabase                VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vCheckReportSubscriptionStatus INT;
	vCheckTemplateidExists         INT;
	vMarketId                      VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin;
	vMarketIdList                  LONGTEXT DEFAULT '';
	qryCheckActiveGroups           QUERY(ActiveGroup LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin NULL);
	qryMarketId                    QUERY(marketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin);
	recMarketId                    ARRAY(RECORD(marketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin));
	vGroupValidationLookbackDays   INT; 
	vExecuteReportAs               TEXT CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vOmAuditLog                    RECORD(spName      VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
	                                     sqlExecuted  TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						                 sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						                 logTime      DATETIME,
										 errorCode    INT,
						                 errorMsg     TEXT CHARACTER SET utf8 COLLATE utf8_bin) 
						           = ROW( NULL, NULL, NULL, NULL, NULL, NULL);
  BEGIN
    vOmAuditLog.spName       = 'PopulateMarketUserReportsSubscription';
	vOmAuditLog.errorCode    = 0;
	vOmAuditLog.errorMsg     = '';
    vOmAuditLog.sqlVariables = pReportName||','||pReportOwner||','||IFNULL(pExecuteReportAs,'NULL')||','||pVendor||','||pEnvironment||','||pReportSchedulerHostName||','||pConfidenceLevel||','||pIsEnable;
    vOmAuditLog.sqlExecuted  = 'Starting processing with params ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')';
    	  
    SELECT NOW(6) INTO vActivityStartTime;
    SELECT UUID() INTO vSessionIdentifier;
  
    SELECT /*! PopulateMarketUserReportsSubscription */  
	       IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	  FROM APP_CONFIG 
	 WHERE APP_NAME = vOmAuditLog.spName 
	   AND APP_KEY = 'APP_LOG_LEVEL' 
	  INTO vAppLogLevel;	
 	
	SELECT /*! PopulateMarketUserReportsSubscription */  
	       KEY_VALUE 
	  FROM APP_CONFIG 
	 WHERE APP_NAME = vOmAuditLog.spName 
	   AND APP_KEY = 'VENDOR_DATABASE' 
	  INTO vVendorDatabase;	
 	
    SELECT /*!PopulateMarketUserReportsSubscription*/  
	       KEY_VALUE 
      FROM APP_CONFIG 
     WHERE APP_NAME = vOmAuditLog.spName 
       AND APP_KEY = 'REPORT_URL' 
      INTO vReportUrl;	
	
	SELECT /*! PopulateMarketUserReportsSubscription */ 
	       KEY_VALUE 
	  FROM APP_CONFIG
	 WHERE APP_NAME = vOmAuditLog.spName
	   AND APP_KEY = 'NEW_SUBSCRIPTION_GROUP_VALIDATION_LOOKBACK_DAYS'
	  INTO vGroupValidationLookbackDays;

	IF pExecuteReportAs IS NULL THEN 
	  SELECT /*! PopulateMarketUserReportsSubscription */ 
	         KEY_VALUE 
	    FROM APP_CONFIG
	   WHERE APP_NAME = vOmAuditLog.spName
	     AND APP_KEY = 'EXECUTE_REPORT_AS'
	    INTO vExecuteReportAs;
	ELSE
	  vExecuteReportAs = pExecuteReportAs;
	END IF;

    IF vAppLogLevel = 'ERROR' THEN	

	  /*! Check if the Input report/Username is exists or not*/
	  
	  vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
	          EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1 
						FROM REPORT R
					   WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
						 AND R.USER_NAME = '||QUOTE(pReportOwner) ||'
					   LIMIT 1)';
	
	  EXECUTE IMMEDIATE vSql INTO vReportExists;

	  IF vReportExists > 0 THEN	   

	    /*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		        EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1 
						  FROM USER_REPORTS_SUBSCRIPTION
						 WHERE REPORT_NAME = '||QUOTE(pReportName) ||' 
						 LIMIT 1 )';
	    
	    EXECUTE IMMEDIATE vSql INTO vCheckReportSubscriptionStatus;
	
		IF vCheckReportSubscriptionStatus = 1 THEN 
		
		  INSERT /*! PopulateMarketUserReportsSubscription */ 
		    INTO APP_ACTIVITIES_LOG 
		       ( APP_NAME,
		         BATCH_ID,
		         ACTIVITY_TYPE,
		         ACTIVITY_DETAILS,
		         ACTIVITY_OUTPUT,
		         ACTIVITY_ERROR_MSG,
		         ACTIVITY_START_TS,
		         ACTIVITY_END_TS,
		         ACTIVITY_STATUS) 
		  VALUES 
		       ( vOmAuditLog.spName,
		         vSessionIdentifier,
		         'Executing Procedure',
		         'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		         NULL,
		         'Entries for Report : ('||pReportName||') already exist in USER_REPORTS_SUBSCRIPTION',
		         vActivityStartTime,
		         NOW(6),
		         'EXCEPTION' );
		  
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS, 
		              'Entries for Report : ('||pReportName||') already exist in USER_REPORTS_SUBSCRIPTION' AS REASON 
		         FROM DUAL;
			
			RETURN;	  
			
		END IF;

	    /*! Check if template and report having template id */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		        EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1
				          FROM TEMPLATE 
				          JOIN REPORT 
				            ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
				           AND USER_NAME  = '||QUOTE(pReportOwner) ||'
				           AND REPORT_NAME = '||QUOTE(pReportName)||'
						 LIMIT 1)';
	    
	    EXECUTE IMMEDIATE vSql INTO vCheckTemplateidExists;
	
		IF vCheckTemplateidExists = 0 THEN 

		  INSERT /*! PopulateMarketUserReportsSubscription */ 
		    INTO APP_ACTIVITIES_LOG 
		       ( APP_NAME,
		         BATCH_ID,
		         ACTIVITY_TYPE,
		         ACTIVITY_DETAILS,
		         ACTIVITY_OUTPUT,
		         ACTIVITY_ERROR_MSG,
		         ACTIVITY_START_TS,
		         ACTIVITY_END_TS,
		         ACTIVITY_STATUS) 
		  VALUES 
		       ( vOmAuditLog.spName,
		         vSessionIdentifier,
		         'Executing Procedure',
		         'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		         NULL,
		         'Entries for Report : ('||pReportName||') and Report Owner : ('||pReportOwner||') not present with TEMPLATE_ID' ,
		         vActivityStartTime,
		         NOW(6),
		         'EXCEPTION' );
		  
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS, 
		              'Entries for Report : ('||pReportName||') and Report Owner : ('||pReportOwner||') not present with TEMPLATE_ID'  AS REASON 
		         FROM DUAL;
			
			RETURN;	  
			
		END IF;

		/*! Check for active groups for the new Report for all markets   */    
		
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		               TEMPLATE_ID 
				  FROM TEMPLATE 
				  JOIN REPORT 
				    ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
				   AND USER_NAME  = '||QUOTE(pReportOwner) ||'
				   AND REPORT_NAME = '||QUOTE(pReportName);

		EXECUTE IMMEDIATE vSql INTO vTemplateID;
		
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
					   GROUP_CONCAT(DISTINCT QUOTE(GROUP_NAME) SEPARATOR '','') GROUP_NM
				  FROM (
				        SELECT /*! PopulateMarketUserReportsSubscription */ FD.GROUP_NAME 
				          FROM FORMULA F,
						       FORMULA_DETAIL FD				
				         WHERE F.FORMULA_ID = FD.FORMULA_ID
						   AND F.FORMULA_ID IN (SELECT CAST(FD.OM_NAME AS unsigned)
									              FROM FORMULA F,
										               FORMULA_DETAIL FD
									             WHERE F.FORMULA_ID = FD.FORMULA_ID
										           AND F.FORMULA_ID IN (SELECT FORMULA_ID
															              FROM TEMPLATE_FORMULA H
															             WHERE H.TEMPLATE_ID = '||vTemplateID||'
															            )
									               AND FD.GROUP_NAME = ''FORMULA''									   
								                )
						   AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
						   AND FD.GROUP_NAME IS NOT NULL
				         UNION 
				        SELECT /*! PopulateMarketUserReportsSubscription */  
						       GROUP_NAME 
				          FROM FORMULA_DETAIL FD  
				         WHERE FORMULA_ID IN (SELECT FORMULA_ID 
						                        FROM TEMPLATE_FORMULA H 
					                           WHERE H.TEMPLATE_ID = '||vTemplateID||')
					       AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
				         )';

		qryCheckActiveGroups  = TO_QUERY(vSql);   
		vActiveGroup2 = SCALAR(qryCheckActiveGroups);

		IF vActiveGroup2 IS NULL THEN 

		  INSERT /*! PopulateMarketUserReportsSubscription */ 
		    INTO APP_ACTIVITIES_LOG 
		       ( APP_NAME,
		         BATCH_ID,
		         ACTIVITY_TYPE,
		         ACTIVITY_DETAILS,
		         ACTIVITY_OUTPUT,
		         ACTIVITY_ERROR_MSG,
		         ACTIVITY_START_TS,
		         ACTIVITY_END_TS,
		         ACTIVITY_STATUS) 
		  VALUES 
		       ( vOmAuditLog.spName,
		         vSessionIdentifier,
		         'Executing Procedure',
		         'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		         NULL,
		         'Unable to determine active GROUPS for the Report ('||pReportName||') with Template ID : ('||vTemplateID||')',
		         vActivityStartTime,
		         NOW(6),
		         'EXCEPTION' );
		   
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS,  
		              'Unable to determine active GROUPS for the Report ('||pReportName||') with Template ID : ('||vTemplateID||')' AS REASON 
		         FROM DUAL;
			
		  RETURN;	  

		END IF;

		/*! Now to check for each individual market */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ DISTINCT MARKET_ID FROM MARKET';
	
		qryMarketId = TO_QUERY(vSql);
		recMarketId = COLLECT(qryMarketId);
	
		vMarketIdList  = '';
	
		FOR x IN 0 .. LENGTH(recMarketId) - 1 LOOP
	
		  vMarketId = recMarketId[x].marketId;
		
		  /*! Check for active groups for the new Report for the specific market  */ 

		  vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
						 GROUP_CONCAT(DISTINCT GROUP_NAME SEPARATOR '','') GROUP_NM
				    FROM '||vVendorDatabase||'.OM_DATA_INTERVALS ODI						
				   WHERE ODI.GROUP_NAME IN ('||vActiveGroup2||')
					 AND ODI.TRAFFIC_HOUR >= NOW() - INTERVAL '||vGroupValidationLookbackDays||' DAY 
					 AND ODI.MARKET_ID = '||QUOTE(vMarketId);

		  qryCheckActiveGroups  = TO_QUERY(vSql);
		  vActiveGroup          = SCALAR(qryCheckActiveGroups);
	
		  IF vActiveGroup IS NOT NULL THEN				   
	
			vSql = 'INSERT /*! PopulateMarketUserReportsSubscription */ 
			          INTO USER_REPORTS_SUBSCRIPTION 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_END_DATE,
						   REPORT_DAYS_TO_TREND,
						   REPORT_LEVEL,
						   REPORT_TYPE,
						   REPORT_URL,
						   REPORT_DELIVERY_TARGET_PREF,
						   REPORT_SCHEDULER_HOSTNAME,
						   GROUP_NAME,
						   REGION_NAME,
						   MARKET_ID,
						   CONFIDENCE_LEVEL,
						   IS_ENABLED ) 
					SELECT /*! PopulateMarketUserReportsSubscription */ 
						   USER_NAME,
						   '||QUOTE(pEnvironment) ||' ENVIRONMENT,
						   '||QUOTE(pVendor) ||' VENDOR,				   
						   REPORT_ID,
						   REPORT_NAME,
						   ''YESTERDAY'' REPORT_END_DATE,
						   1 REPORT_DAYS_TO_TREND,
						   REPORT_LEVEL,
						   REPORT_TYPE,
						   '||QUOTE(vReportUrl||'user='||vExecuteReportAs||'&tmpl_rpt='||pReportOwner||'@'||pReportName) ||' REPORT_URL, /*! 4G requires ||| 5G requires @ */
						   ''S3'' REPORT_DELIVERY_TARGET_PREF,
						   '||QUOTE(pReportSchedulerHostName)||',
						   '||QUOTE(vActiveGroup)||',
						   NULL REGION_NAME,
						   '||QUOTE(vMarketId)||',
						   '||QUOTE(pConfidenceLevel)||',
						   '||QUOTE(pIsEnable) ||' IS_ENABLED
					  FROM REPORT R
					 WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
					   AND R.USER_NAME = '||QUOTE(pReportOwner);

			EXECUTE IMMEDIATE vSql;
			vrowcount = row_count() + vrowcount;
			
			vMarketIdList = vMarketId||','||vMarketIdList;				
			
		  ELSE /*! vActiveGroup */

		    INSERT /*! PopulateMarketUserReportsSubscription */ 
		      INTO APP_ACTIVITIES_LOG 
		         ( APP_NAME,
		           BATCH_ID,
		           ACTIVITY_TYPE,
		           ACTIVITY_DETAILS,
		           ACTIVITY_OUTPUT,
		           ACTIVITY_ERROR_MSG,
		           ACTIVITY_START_TS,
		           ACTIVITY_END_TS,
		           ACTIVITY_STATUS) 
		    VALUES 
		         ( vOmAuditLog.spName,
		           vSessionIdentifier,
		           'Executing Procedure',
		           'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		           NULL,
		           'Groups identified - ('||vActiveGroup2||'); no data found for these groups in OM_DATA_INTERVALS in the past ('||vGroupValidationLookbackDays||') days for  ('||QUOTE(vMarketId)||') Market ',
		           vActivityStartTime,
		           NOW(6),
		           'EXCEPTION' );
	  
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
			            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
			            'EXCEPTION' AS STATUS,  
			            'Groups identified - ('||vActiveGroup2||'); no data found for these groups in OM_DATA_INTERVALS in the past ('||vGroupValidationLookbackDays||') days for  ('||QUOTE(vMarketId)||') Market ' AS REASON 
			       FROM DUAL;	   
				   
		  END IF;  
		END LOOP;
		
	  ELSE /*! vReportExists */

		INSERT /*! PopulateMarketUserReportsSubscription */ 
		  INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
		       BATCH_ID,
		       ACTIVITY_TYPE,
		       ACTIVITY_DETAILS,
		       ACTIVITY_OUTPUT,
		       ACTIVITY_ERROR_MSG,
		       ACTIVITY_START_TS,
		       ACTIVITY_END_TS,
		       ACTIVITY_STATUS) 
		VALUES 
		     ( vOmAuditLog.spName,
		       vSessionIdentifier,
		       'Executing Procedure',
		       'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		       NULL,
		       'Reportname : ('|| QUOTE(pReportName) ||') / User : ('||QUOTE(pReportOwner)||') does not exist',
		       vActivityStartTime,
		       NOW(6),
		       'EXCEPTION' );
		  
		ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		            'EXCEPTION' AS STATUS, 
		            'Reportname : ('|| QUOTE(pReportName) ||') / User : ('||QUOTE(pReportOwner)||') does not exist' AS REASON 
		       FROM DUAL;

		RETURN;
      END IF; /*! vReportExists */
	
    END IF;	/*! vAppLogLevel */
  
    IF vAppLogLevel = 'DEBUG' THEN	

	  CALL writeAuditLogV2(vOmAuditLog); 

	  /*! Check if the Input report/Username is exists or not*/
	  
	  vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
	          EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1 
						FROM REPORT R
					   WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
						 AND R.USER_NAME = '||QUOTE(pReportOwner) ||'
					   LIMIT 1)';
			
	  vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
	  CALL writeAuditLogV2(vOmAuditLog);
	
	  EXECUTE IMMEDIATE vSql INTO vReportExists;

	  IF vReportExists > 0 THEN	   

	    /*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		        EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1 
						  FROM USER_REPORTS_SUBSCRIPTION
						 WHERE REPORT_NAME = '||QUOTE(pReportName) ||' 
						 LIMIT 1 )';

	    vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
	    CALL writeAuditLogV2(vOmAuditLog);
	    
	    EXECUTE IMMEDIATE vSql INTO vCheckReportSubscriptionStatus;
	
		IF vCheckReportSubscriptionStatus = 1 THEN 
		
		  vOmAuditLog.sqlExecuted =  'Entries for Report : ('||pReportName||') already exist in USER_REPORTS_SUBSCRIPTION' ;
		  CALL writeAuditLogV2(vOmAuditLog);		   
		  
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS, 
		              'Entries for Report : ('||pReportName||') already exist in USER_REPORTS_SUBSCRIPTION' AS REASON 
		         FROM DUAL;
			
			RETURN;	  
			
		END IF;

	    /*! Check if template and report having template id */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		        EXISTS (SELECT /*! PopulateMarketUserReportsSubscription */ 1
				          FROM TEMPLATE 
				          JOIN REPORT 
				            ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
				           AND USER_NAME  = '||QUOTE(pReportOwner) ||'
				           AND REPORT_NAME = '||QUOTE(pReportName)||'
						 LIMIT 1)';

	    vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
	    CALL writeAuditLogV2(vOmAuditLog);
	    
	    EXECUTE IMMEDIATE vSql INTO vCheckTemplateidExists;
	
		IF vCheckTemplateidExists = 0 THEN 
		
		  vOmAuditLog.sqlExecuted =  'Entries for Report : ('||pReportName||') and Report Owner : ('||pReportOwner||') not present with TEMPLATE_ID' ;
		  CALL writeAuditLogV2(vOmAuditLog);		   
		  
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS, 
		              'Entries for Report : ('||pReportName||') and Report Owner : ('||pReportOwner||') not present with TEMPLATE_ID'  AS REASON 
		         FROM DUAL;
			
			RETURN;	  
			
		END IF;

		/*! Check for active groups for the new Report for all markets   */    
		
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
		               TEMPLATE_ID 
				  FROM TEMPLATE 
				  JOIN REPORT 
				    ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
				   AND USER_NAME  = '||QUOTE(pReportOwner) ||'
				   AND REPORT_NAME = '||QUOTE(pReportName);

		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);	
							
		EXECUTE IMMEDIATE vSql INTO vTemplateID;

		vOmAuditLog.sqlExecuted = 'Template ID - '|| vTemplateID ;
		CALL writeAuditLogV2(vOmAuditLog);
		
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
					   GROUP_CONCAT(DISTINCT QUOTE(GROUP_NAME) SEPARATOR '','') GROUP_NM
				  FROM (
				        SELECT /*! PopulateMarketUserReportsSubscription */ FD.GROUP_NAME 
				          FROM FORMULA F,
						       FORMULA_DETAIL FD				
				         WHERE F.FORMULA_ID = FD.FORMULA_ID
						   AND F.FORMULA_ID IN (SELECT CAST(FD.OM_NAME AS unsigned)
									              FROM FORMULA F,
										               FORMULA_DETAIL FD
									             WHERE F.FORMULA_ID = FD.FORMULA_ID
										           AND F.FORMULA_ID IN (SELECT FORMULA_ID
															              FROM TEMPLATE_FORMULA H
															             WHERE H.TEMPLATE_ID = '||vTemplateID||'
															            )
									               AND FD.GROUP_NAME = ''FORMULA''									   
								                )
						   AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
						   AND FD.GROUP_NAME IS NOT NULL
				         UNION 
				        SELECT /*! PopulateMarketUserReportsSubscription */  
						       GROUP_NAME 
				          FROM FORMULA_DETAIL FD  
				         WHERE FORMULA_ID IN (SELECT FORMULA_ID 
						                        FROM TEMPLATE_FORMULA H 
					                           WHERE H.TEMPLATE_ID = '||vTemplateID||')
					       AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
				         )';

		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);

		qryCheckActiveGroups  = TO_QUERY(vSql);   
		vActiveGroup2 = SCALAR(qryCheckActiveGroups);

		IF vActiveGroup2 IS NULL THEN 

		  vOmAuditLog.sqlExecuted = 'Unable to determine active GROUPS for the Report ('||pReportName||') with Template ID : ('||vTemplateID||')';
		  CALL writeAuditLogV2(vOmAuditLog);
		   
		  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		              'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		              'EXCEPTION' AS STATUS,  
		              'Unable to determine active GROUPS for the Report ('||pReportName||') with Template ID : ('||vTemplateID||')' AS REASON 
		         FROM DUAL;
			
		  RETURN;	  

		END IF;

		/*! Now to check for each individual market */
	
		vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ DISTINCT MARKET_ID FROM MARKET';
		
		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);
	
		qryMarketId = TO_QUERY(vSql);
		recMarketId = COLLECT(qryMarketId);
	
		vMarketIdList  = '';
	
		FOR x IN 0 .. LENGTH(recMarketId) - 1 LOOP
	
		  vMarketId = recMarketId[x].marketId;
		
		  /*! Check for active groups for the new Report for the specific market  */ 

		  vSql = 'SELECT /*! PopulateMarketUserReportsSubscription */ 
						 GROUP_CONCAT(DISTINCT GROUP_NAME SEPARATOR '','') GROUP_NM
				    FROM '||vVendorDatabase||'.OM_DATA_INTERVALS ODI						
				   WHERE ODI.GROUP_NAME IN ('||vActiveGroup2||')
					 AND ODI.TRAFFIC_HOUR >= NOW() - INTERVAL '||vGroupValidationLookbackDays||' DAY 
					 AND ODI.MARKET_ID = '||QUOTE(vMarketId);

		  vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		  CALL writeAuditLogV2(vOmAuditLog);

		  qryCheckActiveGroups  = TO_QUERY(vSql);
		  vActiveGroup          = SCALAR(qryCheckActiveGroups);
	
		  IF vActiveGroup IS NOT NULL THEN				   
	
			vSql = 'INSERT /*! PopulateMarketUserReportsSubscription */ 
			          INTO USER_REPORTS_SUBSCRIPTION 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_END_DATE,
						   REPORT_DAYS_TO_TREND,
						   REPORT_LEVEL,
						   REPORT_TYPE,
						   REPORT_URL,
						   REPORT_DELIVERY_TARGET_PREF,
						   REPORT_SCHEDULER_HOSTNAME,
						   GROUP_NAME,
						   REGION_NAME,
						   MARKET_ID,
						   CONFIDENCE_LEVEL,
						   IS_ENABLED ) 
					SELECT /*! PopulateMarketUserReportsSubscription */ 
						   USER_NAME,
						   '||QUOTE(pEnvironment) ||' ENVIRONMENT,
						   '||QUOTE(pVendor) ||' VENDOR,				   
						   REPORT_ID,
						   REPORT_NAME,
						   ''YESTERDAY'' REPORT_END_DATE,
						   1 REPORT_DAYS_TO_TREND,
						   REPORT_LEVEL,
						   REPORT_TYPE,
						   '||QUOTE(vReportUrl||'user='||vExecuteReportAs||'&tmpl_rpt='||pReportOwner||'@'||pReportName) ||' REPORT_URL, /*! 4G requires ||| 5G requires @ */
						   ''S3'' REPORT_DELIVERY_TARGET_PREF,
						   '||QUOTE(pReportSchedulerHostName)||',
						   '||QUOTE(vActiveGroup)||',
						   NULL REGION_NAME,
						   '||QUOTE(vMarketId)||',
						   '||QUOTE(pConfidenceLevel)||',
						   '||QUOTE(pIsEnable) ||' IS_ENABLED
					  FROM REPORT R
					 WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
					   AND R.USER_NAME = '||QUOTE(pReportOwner);

			vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
			CALL writeAuditLogV2(vOmAuditLog);

			EXECUTE IMMEDIATE vSql;
			vrowcount = row_count() + vrowcount;
			
			vMarketIdList = vMarketId||','||vMarketIdList;				
			
		  ELSE /*! vActiveGroup */
		  
			vOmAuditLog.sqlExecuted =  'Groups identified - ('||vActiveGroup2||'); no data found for these groups in OM_DATA_INTERVALS in the past ('||vGroupValidationLookbackDays||') days for  ('||QUOTE(vMarketId)||') Market ';
			CALL writeAuditLogV2(vOmAuditLog);
	  
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
			            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
			            'EXCEPTION' AS STATUS,  
			            'Groups identified - ('||vActiveGroup2||'); no data found for these groups in OM_DATA_INTERVALS in the past ('||vGroupValidationLookbackDays||') days for  ('||QUOTE(vMarketId)||') Market ' AS REASON 
			       FROM DUAL;	   
				   
		  END IF;  
		END LOOP;
		
	  ELSE /*! vReportExists */

		vOmAuditLog.sqlExecuted =  'Reportname : ('|| QUOTE(pReportName) ||') / User : ('||QUOTE(pReportOwner)||') does not exist';
		CALL writeAuditLogV2(vOmAuditLog);
		  
		ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
		            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
		            'EXCEPTION' AS STATUS, 
		            'Reportname : ('|| QUOTE(pReportName) ||') / User : ('||QUOTE(pReportOwner)||') does not exist' AS REASON 
		       FROM DUAL;

		RETURN;
      END IF; /*! vReportExists */

	vOmAuditLog.sqlExecuted =  'Processing completed ';
	CALL writeAuditLogV2(vOmAuditLog);
	
    END IF;	/*! vAppLogLevel */
  
    /*! Final insert to track procedure execution metrics */
	 
	INSERT /*! PopulateMarketUserReportsSubscription */ 
	  INTO APP_ACTIVITIES_LOG 
		 ( APP_NAME,
		   BATCH_ID,
		   ACTIVITY_TYPE,
		   ACTIVITY_DETAILS,
		   ACTIVITY_OUTPUT,
		   ACTIVITY_ERROR_MSG,
		   ACTIVITY_START_TS,
		   ACTIVITY_END_TS,
		   ACTIVITY_STATUS ) 
	VALUES (vOmAuditLog.spName,
		   vSessionIdentifier,
		   'Executing Procedure',
       	   'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
		   'Active Groups identified: ('||vActiveGroup2||') Rows inserted/updated in USER_REPORTS_SUBSCRIPTION: ('||vrowcount||') Valid Markets identified: ('||QUOTE(vMarketIdList)||')',
		   NULL,
		   vActivityStartTime,
		   NOW(6),
		   'COMPLETE');    
		
	COMMIT;
			 
    ECHO SELECT vOmAuditLog.spName AS APP_NAME,  
	            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
	            'COMPLETE' AS STATUS, 
	            'Active Groups identified: ('||vActiveGroup2||') Rows inserted/updated in USER_REPORTS_SUBSCRIPTION: ('||vrowcount||') Valid Markets identified: ('||QUOTE(vMarketIdList)||')'  AS REASON 
	       FROM DUAL;	
	
	EXCEPTION
	  WHEN OTHERS THEN
		ROLLBACK;
		
		IF vAppLogLevel = 'ERROR' THEN
			INSERT  /*! PopulateMarketUserReportsSubscription */ 
			  INTO APP_ACTIVITIES_LOG 
				 ( APP_NAME,
				   BATCH_ID,
				   ACTIVITY_TYPE,
				   ACTIVITY_DETAILS,
				   ACTIVITY_OUTPUT,
				   ACTIVITY_ERROR_MSG,
				   ACTIVITY_START_TS,
				   ACTIVITY_END_TS,
				   ACTIVITY_STATUS) 
			VALUES 
				( vOmAuditLog.spName,
				  vSessionIdentifier,
				  'Executing Procedure',
				  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')',
				  NULL,
				  EXCEPTION_MESSAGE(),
				  vActivityStartTime,
				  NOW(6),
				  'EXCEPTION' );
        
		END IF;
		
		IF vAppLogLevel = 'DEBUG' THEN
			vOmAuditLog.sqlExecuted =  'Found Exception ';
			vOmAuditLog.errorMsg = EXCEPTION_MESSAGE();
			CALL writeAuditLogV2(vOmAuditLog);
		END IF;		
		
	COMMIT;
    
	ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
	            'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportOwner)||','||QUOTE(IFNULL(pExecuteReportAs,'NULL'))||','||QUOTE(pVendor)||','||QUOTE(pEnvironment)||','||QUOTE(pReportSchedulerHostName)||','||pConfidenceLevel||','||QUOTE(pIsEnable)||')' AS ARGUMENTS, 
	            'EXCEPTION' AS STATUS, 
	            EXCEPTION_MESSAGE() AS REASON 
	       FROM DUAL;	 
  RAISE;
END;
//
DELIMITER ;

