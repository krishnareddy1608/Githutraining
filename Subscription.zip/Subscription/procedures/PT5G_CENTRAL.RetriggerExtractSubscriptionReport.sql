/*
Database : PT5G_CENTRAL
Procedure: RetriggerExtractSubscriptionReport
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `RetriggerExtractSubscriptionReport`(pReportName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pReportIntervalStartTime datetime NOT NULL, pReportIntervalEndTime datetime NOT NULL, pMarketId longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL) RETURNS void AS
  DECLARE

/*!
	PROCEDURE NAME       : RetriggerExtractSubscriptionReport
	DATE CREATED         : Mar 08, 2024
	AUTHOR			   	 : Krishna M
	PROCEDURE DESC	   	 : Retrigger Extracts for Subscription Reports that maybe incomplete - NTSCA-29409
						 : Example invocation - call RetriggerExtractSubscriptionReport('actest_scan_1','2024-02-01 10:00:00','2024-02-02 09:00:00','081,082,083');
												call RetriggerExtractSubscriptionReport('actest_scan_1','2024-02-01 10:00:00','2024-02-02 09:00:00',NULL);
						 	The procedure will do the following.
							1. Check to see if this report exists in the USER_REPORTS_SUBSCRIPTION table and is enabled.
								1.1 - If not exists, then exit with ERROR
								1.2 - If exists, continue
							2.	Check to see if any records exist for this report and has a non null REPORT_DELIVERY_STATUS , date range and market_id (or all markets) in USER_REPORTS_SUBSCRIPTION_STATUS 
								3.1 - If not exists, exit with ERROR
								3.2 - If exists, update REPORT_DELIVERY_STATUS to NULL
									3.2.1 - For all markets (if pMarketId is NULL)
									3.2.2 - For specific markets (as in pMarketId)
	VERSION              : V1
	MODIFICATION HISTORY : 

*/  
	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);  
	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
	                    sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						sqlVariables TEXT CHARACTER SET utf8 COLLATE    utf8_bin ,
						logTime DATETIME,errorCode INT,
						errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin
						) 
						 = ROW( NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL);	
	vSql TEXT; 	
	vMarketId LONGTEXT DEFAULT '';
	vrowcount BIGINT DEFAULT 0;
	vCheckReportSubscriptionStatus INT;
	vCheckReportDeliveryStatus INT;
  BEGIN
    vOmAuditLog.spName = 'RetriggerExtractSubscriptionReport';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';	
    vOmAuditLog.sqlVariables =  pReportName||','||pReportIntervalStartTime||','||pReportIntervalEndTime||','||IFNULL(pMarketId,'');	
    vOmAuditLog.sqlExecuted =  'Starting processing with params ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')';
    	  
    SELECT /*! RetriggerExtractSubscriptionReport */ NOW(6) INTO vActivityStartTime;
    SELECT /*! RetriggerExtractSubscriptionReport */ UUID() INTO vSessionIdentifier;
  
    SELECT /*! RetriggerExtractSubscriptionReport */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;	
 	
     IF vAppLogLevel = 'ERROR' THEN	
	   
	  /*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
	  vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ EXISTS '||
				 ' (  '||
					' SELECT 1  '||
					' FROM USER_REPORTS_SUBSCRIPTION '||
					' WHERE REPORT_NAME =  '|| QUOTE(pReportName) ||' '||
					' AND IS_ENABLED = ''Y'' '||
					' LIMIT 1 ' ||
				')'; 

	  EXECUTE IMMEDIATE vSql INTO vCheckReportSubscriptionStatus;

	  IF vCheckReportSubscriptionStatus = 1 THEN 
	
		/*! Check if pMarketId is NULL and manage accordingly */ 
	
		IF pMarketId IS NULL THEN
		
			vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ GROUP_CONCAT(MARKET_ID SEPARATOR '','') ' ||
			        ' FROM USER_REPORTS_SUBSCRIPTION ' || 
			       ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
			         ' AND IS_ENABLED = ''Y'' ' ;

			EXECUTE IMMEDIATE vSql INTO vMarketId;
			
		ELSE
		
			vMarketId = pMarketId;
		
		END IF;
	
		/*! Check in USER_REPORTS_SUBSCRIPTION_STATUS TABLE */
		
		vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ EXISTS ' ||
				   ' ( ' ||
					 ' SELECT 1  ' ||
					   ' FROM USER_REPORTS_SUBSCRIPTION_STATUS ' ||
					  ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
					   ' AND MARKET_ID IN (SELECT TABLE_COL :> TEXT FROM TABLE(SPLIT('|| QUOTE(vMarketId) ||','',''))) ' ||
					   ' AND REPORT_INTERVAL_START_TIME >= '|| QUOTE(pReportIntervalStartTime) ||'  ' ||
					   ' AND REPORT_INTERVAL_END_TIME <= '|| QUOTE(pReportIntervalEndTime) ||' ' ||
					   ' AND (REPORT_DELIVERY_STATUS IS NOT NULL OR REPORT_DELIVERY_ERR_MSG IS NOT NULL) ' ||
					   ' AND REPORT_READINESS = ''READY_FOR_DELIVERY'' ' ||
				   ' ) ';

		EXECUTE IMMEDIATE vSql INTO vCheckReportDeliveryStatus;
		
		IF vCheckReportDeliveryStatus = 1 THEN
			
			vSql = 'UPDATE /*! RetriggerExtractSubscriptionReport */ ' ||
			             ' USER_REPORTS_SUBSCRIPTION_STATUS ' ||
			         ' SET REPORT_DELIVERY_STATUS = NULL ' ||
				   ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
					 ' AND MARKET_ID IN (SELECT TABLE_COL :> TEXT FROM TABLE(SPLIT('|| QUOTE(vMarketId) ||','',''))) ' ||
					 ' AND REPORT_INTERVAL_START_TIME >= '|| QUOTE(pReportIntervalStartTime) ||'  ' ||
					 ' AND REPORT_INTERVAL_END_TIME <= '|| QUOTE(pReportIntervalEndTime) ||' ' ||
					 ' AND (REPORT_DELIVERY_STATUS IS NOT NULL OR REPORT_DELIVERY_ERR_MSG IS NOT NULL) ' ||
					 ' AND REPORT_READINESS = ''READY_FOR_DELIVERY'' ';
				   
		    EXECUTE IMMEDIATE vSql ;
			vrowcount = ROW_COUNT();
		
		  ELSE 		/*! vCheckReportSubscriptionStatus */
		  
			INSERT  /*! RetriggerExtractSubscriptionReport */ INTO APP_ACTIVITIES_LOG 
			 ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS
			   ) 
			VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
			  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')',
			  NULL,
			  'No records found for Report '||pReportName||' in USER_REPORTS_SUBSCRIPTION_STATUS that need to be re-extracted',
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' 
			  );


			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
				'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS, 
				'EXCEPTION' AS STATUS,
				'No records found for Report '||pReportName||' in USER_REPORTS_SUBSCRIPTION_STATUS that need to be re-extracted' AS REASON 
				FROM DUAL;	 
			
		RETURN;				
		END IF; /*! vCheckReportSubscriptionStatus */
		
	ELSE 	
	
		INSERT  /*! RetriggerExtractSubscriptionReport */ INTO APP_ACTIVITIES_LOG 
		 ( APP_NAME,
		   BATCH_ID,
		   ACTIVITY_TYPE,
		   ACTIVITY_DETAILS,
		   ACTIVITY_OUTPUT,
		   ACTIVITY_ERROR_MSG,
		   ACTIVITY_START_TS,
		   ACTIVITY_END_TS,
		   ACTIVITY_STATUS
		   ) 
		VALUES 
		( vOmAuditLog.spName,
		  vSessionIdentifier,
		  'Executing Procedure',
		  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')',
		  NULL,
		  'Report '||pReportName||' is either not Enabled or not found in USER_REPORTS_SUBSCRIPTION',
		  vActivityStartTime,
		  NOW(6),
		  'EXCEPTION' 
		  );

		ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
			'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS, 
			'EXCEPTION' AS STATUS,
			'Report '||pReportName||' is either not Enabled or not found in USER_REPORTS_SUBSCRIPTION' AS REASON 
			FROM DUAL;	 
 	
	    RETURN;
	
	  END IF; /*! vCheckReportSubscriptionStatus */
	
	END IF;/*! vAppLogLevel */
  
    IF vAppLogLevel = 'DEBUG' THEN
	
	  CALL writeAuditLogV2(vOmAuditLog); 
	  
	  /*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
	  vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ EXISTS '||
				 ' (  '||
					' SELECT 1  '||
					' FROM USER_REPORTS_SUBSCRIPTION '||
					' WHERE REPORT_NAME =  '|| QUOTE(pReportName) ||' '||
					' AND IS_ENABLED = ''Y'' '||
					' LIMIT 1 ' ||
				')'; 
	
	  vOmAuditLog.sqlExecuted =  NVL(vSql, ' Got null ') ;
	  CALL writeAuditLogV2(vOmAuditLog);

	  EXECUTE IMMEDIATE vSql INTO vCheckReportSubscriptionStatus;

	  IF vCheckReportSubscriptionStatus = 1 THEN 
	
		/*! Check if pMarketId is NULL and manage accordingly */ 
	
		IF pMarketId IS NULL THEN
		
			vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ GROUP_CONCAT(MARKET_ID SEPARATOR '','') ' ||
			        ' FROM USER_REPORTS_SUBSCRIPTION ' || 
			       ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
			         ' AND IS_ENABLED = ''Y'' ' ;

	        vOmAuditLog.sqlExecuted =  NVL(vSql, ' Got null ') ;
	        CALL writeAuditLogV2(vOmAuditLog);

			EXECUTE IMMEDIATE vSql INTO vMarketId;
			
		ELSE
		
			vMarketId = pMarketId;
		
		END IF;
	
		/*! Check in USER_REPORTS_SUBSCRIPTION_STATUS TABLE */
		
		vSql = 'SELECT /*! RetriggerExtractSubscriptionReport */ EXISTS ' ||
				   ' ( ' ||
					 ' SELECT 1  ' ||
					   ' FROM USER_REPORTS_SUBSCRIPTION_STATUS ' ||
					  ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
					   ' AND MARKET_ID IN (SELECT TABLE_COL :> TEXT FROM TABLE(SPLIT('|| QUOTE(vMarketId) ||','',''))) ' ||
					   ' AND REPORT_INTERVAL_START_TIME >= '|| QUOTE(pReportIntervalStartTime) ||'  ' ||
					   ' AND REPORT_INTERVAL_END_TIME <= '|| QUOTE(pReportIntervalEndTime) ||' ' ||
					   ' AND (REPORT_DELIVERY_STATUS IS NOT NULL OR REPORT_DELIVERY_ERR_MSG IS NOT NULL) ' ||
					   ' AND REPORT_READINESS = ''READY_FOR_DELIVERY'' ' ||
				   ' ) ';

	    vOmAuditLog.sqlExecuted =  NVL(vSql, ' Got null ') ;
	    CALL writeAuditLogV2(vOmAuditLog);
		
		EXECUTE IMMEDIATE vSql INTO vCheckReportDeliveryStatus;
		
		IF vCheckReportDeliveryStatus = 1 THEN
			
			vSql = 'UPDATE /*! RetriggerExtractSubscriptionReport */ ' ||
			             ' USER_REPORTS_SUBSCRIPTION_STATUS ' ||
			         ' SET REPORT_DELIVERY_STATUS = NULL ' ||
				   ' WHERE REPORT_NAME = '|| QUOTE(pReportName) ||' ' ||
					 ' AND MARKET_ID IN (SELECT TABLE_COL :> TEXT FROM TABLE(SPLIT('|| QUOTE(vMarketId) ||','',''))) ' ||
					 ' AND REPORT_INTERVAL_START_TIME >= '|| QUOTE(pReportIntervalStartTime) ||'  ' ||
					 ' AND REPORT_INTERVAL_END_TIME <= '|| QUOTE(pReportIntervalEndTime) ||' ' ||
					 ' AND (REPORT_DELIVERY_STATUS IS NOT NULL OR REPORT_DELIVERY_ERR_MSG IS NOT NULL) ' ||
					 ' AND REPORT_READINESS = ''READY_FOR_DELIVERY'' ';
				   
	        vOmAuditLog.sqlExecuted =  NVL(vSql, ' Got null ') ;
	        CALL writeAuditLogV2(vOmAuditLog);
				   
		    EXECUTE IMMEDIATE vSql ;
			vrowcount = ROW_COUNT();
		
		  ELSE 		/*! vCheckReportSubscriptionStatus */

	        vOmAuditLog.sqlExecuted =  'No records found for Report '||pReportName||' in USER_REPORTS_SUBSCRIPTION_STATUS that need to be re-extracted';
	        CALL writeAuditLogV2(vOmAuditLog);

			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
				'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS, 
				'EXCEPTION' AS STATUS,
				'No records found for Report '||pReportName||' in USER_REPORTS_SUBSCRIPTION_STATUS that need to be re-extracted' AS REASON 
				FROM DUAL;	 
			
		RETURN;				
		END IF; /*! vCheckReportSubscriptionStatus */
		
	ELSE 	
	
	  vOmAuditLog.sqlExecuted =  'Report '||pReportName||' is either not Enabled or not found in USER_REPORTS_SUBSCRIPTION';
	  CALL writeAuditLogV2(vOmAuditLog);
	
		ECHO SELECT vOmAuditLog.spName AS APP_NAME, 
			'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS, 
			'EXCEPTION' AS STATUS,
			'Report '||pReportName||' is either not Enabled or not found in USER_REPORTS_SUBSCRIPTION' AS REASON 
			FROM DUAL;	 
 	
	    RETURN;
	
	  END IF; /*! vCheckReportSubscriptionStatus */

    END IF;  

    /*! Final insert to track procedure execution metrics */
	 
	INSERT /*! RetriggerExtractSubscriptionReport */ INTO APP_ACTIVITIES_LOG 
		    ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS
			   ) 
	    VALUES 
		    ( vOmAuditLog.spName,
		     vSessionIdentifier,
		     'Executing Procedure',
       	      'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')',
		     'Records updated in USER_REPORTS_SUBSCRIPTION_STATUS table : ('||vrowcount||')',
		     NULL,
		     vActivityStartTime,
		     NOW(6),
		     'COMPLETE'
			 );    
		
	COMMIT;
			 
	ECHO SELECT /*! RetriggerExtractSubscriptionReport */ vOmAuditLog.spName AS APP_NAME,  
			'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS,
			'COMPLETE' AS STATUS, 
			'Records updated in STATUS table : ('||vrowcount||')'	AS REASON 
	 FROM DUAL;	

  EXCEPTION
	WHEN OTHERS THEN
	ROLLBACK;
	
	IF vAppLogLevel = 'ERROR' THEN
		INSERT  /*! RetriggerExtractSubscriptionReport */ INTO APP_ACTIVITIES_LOG 
			 ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS
			   ) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
			  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')',
			  NULL,
			  exception_message(),
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' 
			  );
	
	END IF;
	
	IF vAppLogLevel = 'DEBUG' THEN
		vOmAuditLog.sqlExecuted =  'Found Exception ';
		vOmAuditLog.errorMsg = exception_message();
		CALL writeAuditLogV2(vOmAuditLog);
	END IF;		
	
	COMMIT;

	ECHO SELECT /*! RetriggerExtractSubscriptionReport */ vOmAuditLog.spName AS APP_NAME, 
		'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pReportIntervalStartTime)||','||QUOTE(pReportIntervalEndTime)||','||IFNULL(QUOTE(pMarketId),'')||')' AS ARGUMENTS, 
		'EXCEPTION' AS STATUS,
		exception_message() AS REASON 
	 FROM DUAL;	 
 
RAISE;
END;
//
DELIMITER ;

