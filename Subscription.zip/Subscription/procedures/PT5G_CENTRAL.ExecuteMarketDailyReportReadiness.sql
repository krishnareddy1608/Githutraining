/*
Database : PT5G_CENTRAL
Procedure: ExecuteMarketDailyReportReadiness
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `ExecuteMarketDailyReportReadiness`(pDatabase varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pReportName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pLookBackDays int(11) NULL DEFAULT NULL, pDataLossIsTrue tinyint(1) NULL DEFAULT NULL) RETURNS void AS
DECLARE

/*!
	PROCEDURE NAME      	: ExecuteMarketDailyReportReadiness
	DATE CREATED        	: Feb 07, 2024
	AUTHOR			   		: pownrvi
	PROCEDURE DESC	   		: Example invocation - CALL ExecuteMarketDailyReportReadiness('PT5G','actest_scan_1',NULL,0);
								The procedure will do the following.
								1. Lookup SUBSCRIPTION_ID from REPORT table for a given REPORT_NAME.
								2. Calling ValidateMarketDailyReportReadiness procedure for each SUBSCRIPTION_ID associated with REPORT_NAME.				    
	VERSION              	: V1
	MODIFICATION HISTORY 	:   
*/  

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
	                    sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						logTime DATETIME,errorCode INT,
						errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin
						) 
						  = ROW( NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL);	

	vActiveReport  INT;
	vSql TEXT; 
	vrowcount BIGINT DEFAULT 0;
	qrySubscriptionId QUERY(SubscriptionId VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL);
  
	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);  

BEGIN
    vOmAuditLog.spName = 'ExecuteMarketDailyReportReadiness';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';	
	
    vOmAuditLog.sqlVariables =  pDatabase||','||pReportName||','||pLookBackDays||','||pDataLossIsTrue;	
    vOmAuditLog.sqlExecuted =  'Starting processing with params ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')';
    	  
    SELECT /*! ExecuteMarketDailyReportReadiness */ NOW(6) INTO vActivityStartTime;
    SELECT /*! ExecuteMarketDailyReportReadiness */ UUID() INTO vSessionIdentifier;
  
    SELECT /*! ExecuteMarketDailyReportReadiness */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;	
 	
IF vAppLogLevel = 'ERROR' THEN
	
   /*! Check to see if the report exists in USER_REPORTS_SUBSCRIPTION */

	SELECT /*! ExecuteMarketDailyReportReadiness */ EXISTS (SELECT /*! ExecuteMarketDailyReportReadiness */ 1 
															FROM USER_REPORTS_SUBSCRIPTION 
															WHERE
															REPORT_NAME = pReportName 
															AND REPORT_TYPE = 'Daily Totals' 
															AND IS_ENABLED = 'Y' 
															LIMIT 1
															) INTO vActiveReport;


    IF vActiveReport = 1 THEN	   
		  /*! Looping through each SubscriptionId for the Input Report Name and calling  ValidateMarketDailyReportReadiness 	 */
		vSql='SELECT /*! ExecuteMarketDailyReportReadiness */ SUBSCRIPTION_ID 
			  FROM USER_REPORTS_SUBSCRIPTION 
			  WHERE REPORT_NAME  = '|| QUOTE(pReportName)||' 
			  AND IS_ENABLED = ''Y'' ';
			  
		qrySubscriptionId = TO_QUERY(vSql);
  
		FOR x IN COLLECT(qrySubscriptionId) LOOP
			CALL ValidateMarketDailyReportReadiness(pDatabase,x.SubscriptionId,pLookBackDays,pDataLossIsTrue);
			vrowcount = vrowcount + 1;
		END LOOP;
	  
	ELSE 
		INSERT  /*! ExecuteMarketDailyReportReadiness */ 
		  INTO APP_ACTIVITIES_LOG 
			 ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
			  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
			  NULL,
			  'Report does not exist or is not enabled',
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );
			  
		ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Report does not exist or is not enabled' AS REASON FROM DUAL;
		
		RETURN;
    END IF;	  	 	  
END IF;	    
		
IF vAppLogLevel = 'DEBUG' THEN

	CALL writeAuditLogV2(vOmAuditLog);

	/*! Check if the Input report/Username is exists or not*/
	/*! Check to see if the report exists in USER_REPORTS_SUBSCRIPTION */

	vSql ='SELECT /*! ExecuteMarketDailyReportReadiness */ EXISTS (SELECT /*! ExecuteMarketDailyReportReadiness */ 1 
																	FROM USER_REPORTS_SUBSCRIPTION 
																	WHERE
																	REPORT_NAME = '||QUOTE(pReportName)||' 
																	AND REPORT_TYPE = ''Daily Totals'' 
																	AND IS_ENABLED = ''Y''
																	LIMIT 1
																	)';					
	vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
	CALL writeAuditLogV2(vOmAuditLog);
					
	EXECUTE IMMEDIATE vSql INTO vActiveReport;
			
    vOmAuditLog.sqlExecuted =  'Checking to see if report is available in USER_REPORTS_SUBSCRIPTION - 1 indicates report present '||vActiveReport ;
    CALL writeAuditLogV2(vOmAuditLog);	   

    IF vActiveReport = 1 THEN	   
		  /*! Looping through each SubscriptionId for the Input Report Name and calling  ValidateMarketDailyReportReadiness 	 */
		  
  		vSql='SELECT /*! ExecuteMarketDailyReportReadiness */ SUBSCRIPTION_ID 
			 FROM USER_REPORTS_SUBSCRIPTION 
			 WHERE REPORT_NAME  = '|| QUOTE(pReportName)||' 
			 AND IS_ENABLED = ''Y'' ';
													 		  		
		vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
		CALL writeAuditLogV2(vOmAuditLog);
		
		qrySubscriptionId = TO_QUERY(vSql);	
		
		FOR x IN COLLECT(qrySubscriptionId) LOOP
			
			CALL ValidateMarketDailyReportReadiness(pDatabase,x.SubscriptionId,pLookBackDays,pDataLossIsTrue);
			vrowcount = vrowcount + 1;
			
			vOmAuditLog.sqlExecuted = 'ValidateMarketDailyReportReadiness executed for Report- ('||pReportName||')';
			CALL writeAuditLogV2(vOmAuditLog);
		END LOOP;						  
	ELSE 
	    vOmAuditLog.sqlExecuted =  'Report does not exist or is not enabled';
		CALL writeAuditLogV2(vOmAuditLog);
		
    	ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Report does not exist or is not enabled' AS REASON FROM DUAL;
		
		RETURN;		
    END IF;	  	 	  
END IF;
	
     /*! Final insert to track procedure execution metrics */	 
	    INSERT  /*! ExecuteMarketDailyReportReadiness */ 
	      INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
	     VALUES 
		    ( vOmAuditLog.spName,
		     vSessionIdentifier,
		     'Executing Procedure',
       	      'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
		     'ValidateMarketDailyReportReadiness executed ('||vrowcount||') times for ('||pReportName||')',
		     NULL,
		     vActivityStartTime,
		     now(6),
		     'COMPLETE');
			         	 
    COMMIT;
	
	ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'COMPLETE' AS STATUS, 'ValidateMarketDailyReportReadiness executed ('||vrowcount||') times for ('||pReportName||')' AS REASON FROM DUAL;
	  	   
	EXCEPTION
		WHEN OTHERS THEN
		ROLLBACK;
		IF vAppLogLevel = 'ERROR' THEN
			INSERT  /*! ExecuteMarketDailyReportReadiness */ 
			  INTO APP_ACTIVITIES_LOG 
				 ( APP_NAME,
				   BATCH_ID,
				   ACTIVITY_TYPE,
				   ACTIVITY_DETAILS,
				   ACTIVITY_OUTPUT,
				   ACTIVITY_ERROR_MSG,
				   ACTIVITY_START_TS,
				   ACTIVITY_END_TS,
				   ACTIVITY_STATUS) 
			VALUES 
				( vOmAuditLog.spName,
				  vSessionIdentifier,
				  'Executing Procedure',
				  'Procedure Arguments: ('||QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
				  NULL,
				  exception_message(),
				  vActivityStartTime,
				  NOW(6),
				  'EXCEPTION' );
        
		END IF;
		IF vAppLogLevel = 'DEBUG' THEN
			vOmAuditLog.sqlExecuted =  'Found Exception ';
			vOmAuditLog.errorMsg = exception_message();
			CALL writeAuditLogV2(vOmAuditLog);
		END IF;
	COMMIT;      
	 
	ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, exception_message() AS REASON FROM DUAL;	 
RAISE;
END;
//
DELIMITER ;

