/*
Database : PT5G_CENTRAL
Procedure: ValidateMarketHourlyReportCompleteness
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `ValidateMarketHourlyReportCompleteness`(pDatabase varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pSubscriptionId varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pLookBackHours int(11) NULL DEFAULT NULL) RETURNS void AS
DECLARE

/*!
	PROCEDURE NAME      : ValidateMarketHourlyReportCompleteness
	DATE CREATED        : Feb 7, 2024
	VERSION             : V1
	AUTHOR 				: Krishna Manoharan
	PROCEDURE DESC	   	: Smart Reports - NTSCA-27057
						: Example invocation - call ValidateMarketHourlyReportCompleteness('PT5G','0ce65105a59c4fcf847fe543749c1f8a28242c4408448462c16f6e79b767cf25a5d67aa31fd400fa3ccb9132472a4089593b1fd7e856d254f87020bd16ee3292',NULL);
					    The procedure will do the following.
						1. Lookup SUBSCRIPTION_ID (combination of REPORT_ID and MARKET_ID) from USER_REPORTS_SUBSCRIPTION (maintained by the UI) with select for update. We will take a rowlevel lock for the duration  of procedure to prevent multiple instances running at same time for the same report.
						2. Validate that the Report is Market/Hourly
						3. Retrieve the GROUP_NAMEs for the Report from USER_REPORTS_SUBSCRIPTION
						4. Retrieve other metadata relating to the Report.
						Case 1 - For published reports
							a.Compare the last time the report was run with the hourly_data_timestamp in OM_DATA_INTERVALS for a specific group/market_id.
							b.If the hourly_data_timestamp is > than the last run of the report, mark the report as ready_for_delivery so the scheduler can re-process this interval again
						Case 2 - For data loss reports
							a.If DATA_LOSS_DETECTED, check and see if data detected and go from there.
						
*/

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 logTime DATETIME,
						 errorCode INT,
						 errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin 
						 ) 
								= ROW(NULL,
									NULL,
									NULL,
									NULL,
									NULL,
									NULL
									);

	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);
	vCheckReportisEnabled INT;
	vMarketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin;
	vMarketId2 VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin;
	vGroupName LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEndDate VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vSql LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vCountMaxTrafficHour INT;
	vCountMarketId INT;
	vCountGroupName INT;
	vCountMarketGroup INT;

	vReportIntervalStartTime DATETIME;
	vReportDeliveryStartTime DATETIME;
	vReportIntervalEndTime DATETIME;
	vReportDeliveryStatus INT;
	vReportReadinessCheckStatus INT;
	vReportReRunExtractStatus INT;
	vReportMaxTrafficHour DATETIME;
	vReportCurrentMaxTrafficHour DATETIME;
	vReportUserName VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEnvironment VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportVendor VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportName VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportType VARCHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportCurrentTrafficHourCheckStatus INT;
	vReportNextTrafficHourCheckStatus INT;
	vSubscriptionRetryCount BIGINT DEFAULT 0;
	vSubscriptionDataLossRetryCount BIGINT DEFAULT 0;
	vMarketCurrentTime DATETIME;
	vLookBackHours INT;
	vReportId BIGINT;
	vDataAvailabilityFactor INT;
	vReportDataLossStatus INT;
	vReportDataLossTrafficHourCheckStatus INT;
	
	qryReportIntervalStartTime QUERY(MARKET_ID VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin , REPORT_INTERVAL_START_TIME	DATETIME, REPORT_DELIVERY_START_TIME DATETIME(6));	
	recReportIntervalStartTime ARRAY(RECORD(MARKET_ID VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin , REPORT_INTERVAL_START_TIME DATETIME, REPORT_DELIVERY_START_TIME DATETIME(6)));					

BEGIN
	vOmAuditLog.spName = 'ValidateMarketHourlyReportCompleteness';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';
  
	vOmAuditLog.sqlExecuted =  'Started processing with arguments :(' ||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||')'; 
	vOmAuditLog.sqlVariables = pDatabase||','|| pSubscriptionId||','||IFNULL(pLookBackHours,'NULL');
  	
	SELECT /*! ValidateMarketHourlyReportCompleteness */ NOW(6) INTO vActivityStartTime;
	SELECT /*! ValidateMarketHourlyReportCompleteness */ UUID() INTO vSessionIdentifier;

	SELECT /*! ValidateMarketHourlyReportCompleteness */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;

	SELECT /*! ValidateMarketHourlyReportCompleteness */ IFNULL(ANY_VALUE(KEY_VALUE),80) 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'DATA_AVAILABILITY_FACTOR' 
	INTO vDataAvailabilityFactor;	 

	IF pLookBackHours IS NULL THEN
		SELECT /*! ValidateMarketHourlyReportCompleteness */ KEY_VALUE 
		FROM APP_CONFIG 
		WHERE APP_NAME = vOmAuditLog.spName 
		AND APP_KEY = 'SUBSCRIPTION_CHECK_LOOKBACK_HOURS' 
		INTO vLookBackHours;
	ELSE 
		vLookBackHours = pLookBackHours;
	END IF;

	/*! Audit Log will be disabled when vAppLogLevel=ERROR */
	IF vAppLogLevel='ERROR' THEN
  
  		/*! - we validate the report id is enabled */
		SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
			(
				SELECT SUBSCRIPTION_ID 
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = pSubscriptionId 
				AND IS_ENABLED = 'Y' 
				AND REPORT_TYPE = 'Hourly Totals' 
				AND MARKET_ID IS NOT NULL 
				AND REGION_NAME IS NULL
			) 
		INTO vCheckReportisEnabled;

		IF vCheckReportisEnabled > 0 THEN
			/*! we select all metadata for the report and lock the report for concurrency control*/
			START TRANSACTION;
			
			SELECT /*! ValidateMarketHourlyReportCompleteness */ USER_NAME,
				 ENVIRONMENT,
				 VENDOR,
				 REPORT_ID,
				 REPORT_NAME,
				 REPORT_TYPE,
				 REPORT_END_DATE, 
				 MARKET_ID,
				 GROUP_NAME,
				 CountElementsCommaString(GROUP_NAME),
				 CountElementsCommaString(MARKET_ID)
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = pSubscriptionId FOR UPDATE
			INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
				 vReportEndDate, vMarketId, vGroupName,vCountGroupName, vCountMarketId;
				 				
			/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */		
			vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);

			/*! - Case 1 for published reports */
			/*! find out if we ever published this report within vLookBackHours hours*/
			
			SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
			(
				SELECT 1 
				FROM USER_REPORTS_SUBSCRIPTION_STATUS 
				WHERE SUBSCRIPTION_ID = pSubscriptionId
				AND REPORT_DELIVERY_STATUS = 'PUBLISHER_COMPLETE' 
				AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
				LIMIT 1
			) 
			INTO vReportDeliveryStatus;		
	  
			IF (vReportDeliveryStatus > 0) THEN
	   
				/*! We grab all intervals that was ever published for this report until SUBSCRIPTION_CHECK_LOOKBACK_HOURS */

				qryReportIntervalStartTime = SELECT /*! ValidateMarketHourlyReportCompleteness */ MARKET_ID, 
												REPORT_INTERVAL_START_TIME, REPORT_DELIVERY_START_TIME
											 FROM USER_REPORTS_SUBSCRIPTION_STATUS
											 WHERE SUBSCRIPTION_ID = pSubscriptionId
											 AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
											 AND REPORT_DELIVERY_STATUS = 'PUBLISHER_COMPLETE';
																		
				recReportIntervalStartTime = COLLECT(qryReportIntervalStartTime);
	
				/*! we check if any group, in the list of groups for the report, for that particular REPORT_INTERVAL_START_TIME, the REPORT_DELIVERY_START_TIME < hourly_data_timestamp */
	
				IF LENGTH(recReportIntervalStartTime) > 0 THEN
	
					FOR i IN 1..LENGTH(recReportIntervalStartTime) - 1 LOOP
					
					vMarketId2 = recReportIntervalStartTime[i].MARKET_ID;
					vReportIntervalStartTime = recReportIntervalStartTime[i].REPORT_INTERVAL_START_TIME;
					vReportDeliveryStartTime = recReportIntervalStartTime[i].REPORT_DELIVERY_START_TIME;
					
					vSql = 	'SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
								(
									SELECT 1 FROM '||pDatabase||'.OM_DATA_INTERVALS
									WHERE GROUP_NAME IN (SELECT TABLE_COL FROM TABLE(SPLIT('||QUOTE(vGroupName)||','','')))
									AND MARKET_ID = '||QUOTE(vMarketId2)||'
									AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||'
									AND HOURLY_DATA_TIMESTAMP > '||QUOTE(vReportDeliveryStartTime)||'
								)';

					EXECUTE IMMEDIATE vSql INTO vReportReRunExtractStatus;
								
						IF vReportReRunExtractStatus > 0 THEN
	
							UPDATE /*! ValidateMarketHourlyReportCompleteness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							SET REPORT_DELIVERY_STATUS = NULL
							WHERE 
							SUBSCRIPTION_ID = pSubscriptionId
							AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime
							AND REPORT_INTERVAL_END_TIME = vReportIntervalStartTime + INTERVAL 1 HOUR
							AND REPORT_DELIVERY_STATUS = 'PUBLISHER_COMPLETE';													

							vSubscriptionRetryCount = vSubscriptionRetryCount + row_count();							
					
						END IF; 
					END LOOP; 
				END IF; 
			END IF; 
			
			/*! Case 2 - DATA_LOSS_DETECTED scenarios */
			
			SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
			(
				SELECT 1 
				FROM USER_REPORTS_SUBSCRIPTION_STATUS 
				WHERE SUBSCRIPTION_ID = pSubscriptionId
				AND REPORT_READINESS = 'DATA_LOSS_DETECTED'
				AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
				LIMIT 1
			) 
			INTO vReportDataLossStatus;
			
			IF vReportDataLossStatus > 0 THEN
			  
				/*! We grab all intervals that was ever published for this report until SUBSCRIPTION_CHECK_LOOKBACK_HOURS */

				qryReportIntervalStartTime = SELECT /*! ValidateMarketHourlyReportCompleteness */ 
												MARKET_ID, 
												REPORT_INTERVAL_START_TIME, 
												REPORT_DELIVERY_START_TIME
											 FROM USER_REPORTS_SUBSCRIPTION_STATUS
											 WHERE SUBSCRIPTION_ID = pSubscriptionId
											 AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
											 AND REPORT_READINESS = 'DATA_LOSS_DETECTED';
							
				recReportIntervalStartTime = COLLECT(qryReportIntervalStartTime);

				/*! we need to check if data is available for the report  */
	
				IF LENGTH(recReportIntervalStartTime) > 0 THEN
	
					FOR i IN 1..LENGTH(recReportIntervalStartTime) - 1 LOOP
					
					vMarketId2 = recReportIntervalStartTime[i].MARKET_ID;
					vReportIntervalStartTime = recReportIntervalStartTime[i].REPORT_INTERVAL_START_TIME;
					vReportDeliveryStartTime = recReportIntervalStartTime[i].REPORT_DELIVERY_START_TIME;
										
					vSql = 'SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportCompleteness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN (SELECT TABLE_COL FROM TABLE(SPLIT('||QUOTE(vGroupName)||','','')))
							AND MARKET_ID = '||QUOTE(vMarketId2)||'
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
						)';
				
					EXECUTE IMMEDIATE vSql INTO vReportDataLossTrafficHourCheckStatus;
						
						IF vReportDataLossTrafficHourCheckStatus > 0 THEN
	
							UPDATE /*! ValidateMarketHourlyReportCompleteness */ USER_REPORTS_SUBSCRIPTION_STATUS  
							SET REPORT_READINESS = 'READY_FOR_DELIVERY',
            				 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE'
							WHERE 
							SUBSCRIPTION_ID = pSubscriptionId
							AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime
							AND REPORT_INTERVAL_END_TIME = vReportIntervalStartTime + INTERVAL 1 HOUR
							AND REPORT_READINESS =   'DATA_LOSS_DETECTED';
													
							vSubscriptionDataLossRetryCount = vSubscriptionDataLossRetryCount + row_count();
						END IF; 
					END LOOP; 
				END IF; 
			END IF ; 
		ELSE 
		
			ECHO SELECT /*!ValidateMarketHourlyReportCompleteness*/ 
						vOmAuditLog.spName AS APP_NAME, 
					    'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||') ' AS ARGUMENTS, 
						'FAILED' AS STATUS, 
						'REPORT is NOT ENABLED/INVALID'  AS REASON 
						FROM DUAL;						  
		
			INSERT /*! ValidateMarketHourlyReportCompleteness */ INTO APP_ACTIVITIES_LOG (
									 APP_NAME,
									 BATCH_ID,
									 ACTIVITY_TYPE,
									 ACTIVITY_DETAILS,
									 ACTIVITY_OUTPUT,
									 ACTIVITY_ERROR_MSG,
									 ACTIVITY_START_TS,
									 ACTIVITY_END_TS,
									 ACTIVITY_STATUS) 
									VALUES 
									( 
									 vOmAuditLog.spName,
									 vSessionIdentifier,
									 'Executing Procedure',										 
									 'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||')' ,
									 NULL,
									 'REPORT IS NOT ENABLED/INVALID',
									 vActivityStartTime,
									 NOW(6),
									 'COMPLETE'
									 );
			RETURN;	
		END IF ; 
		COMMIT; 
	END IF; 
  
	/*! Audit Log will be Enabled when vAppLogLevel = DEBUG */
	IF vAppLogLevel='DEBUG' THEN	  
	  	
		CALL writeAuditLogV2(vOmAuditLog);
		/*! - we validate the report id is enabled */
		vSql='SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'
			AND IS_ENABLED = ''Y'' 
			AND REPORT_TYPE = ''Hourly Totals''
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		)';		
		
		vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
		CALL writeAuditLogV2(vOmAuditLog);

		EXECUTE IMMEDIATE vSql INTO vCheckReportisEnabled;

		vOmAuditLog.sqlExecuted = 'Report check returned:'||vCheckReportisEnabled;
		CALL writeAuditLogV2(vOmAuditLog);

		IF vCheckReportisEnabled > 0 THEN
			/*! we select all metadata for the report and lock the report for concurrency control*/
			START TRANSACTION;
			
			vSql='SELECT /*! ValidateMarketHourlyReportCompleteness */ USER_NAME,
				 ENVIRONMENT,
				 VENDOR,
				 REPORT_ID,
				 REPORT_NAME,
				 REPORT_TYPE,
				 REPORT_END_DATE, 
				 MARKET_ID,
				 GROUP_NAME,
				 CountElementsCommaString(GROUP_NAME),
				 CountElementsCommaString(MARKET_ID)
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||' FOR UPDATE ';

			vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
			CALL writeAuditLogV2(vOmAuditLog);

			EXECUTE IMMEDIATE vSql INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
				 vReportEndDate, vMarketId, vGroupName,vCountGroupName, vCountMarketId;
				 
				vOmAuditLog.sqlExecuted = 'Groups in report:'||QUOTE(vGroupName);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of Groups in report:'||vCountGroupName;
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = 'Markets in report:'||QUOTE(vMarketId);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of markets in report:'||vCountMarketId;
				CALL writeAuditLogV2(vOmAuditLog);
			
				/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */		
				vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);
				
				vOmAuditLog.sqlExecuted = 'Logging active countmarketgroup: '||vCountMarketGroup;
				CALL writeAuditLogV2(vOmAuditLog);

			/*! - Case 1 for published reports */
			/*! find out if we ever published this report within vLookBackHours hours*/
			
			vSql='SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
						(
							SELECT 1 
							FROM USER_REPORTS_SUBSCRIPTION_STATUS 
							WHERE SUBSCRIPTION_ID ='||QUOTE( pSubscriptionId)||'
							AND REPORT_DELIVERY_STATUS = ''PUBLISHER_COMPLETE''
							AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL '||vLookBackHours||' HOUR
							LIMIT 1
						) ';
			vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
			CALL writeAuditLogV2(vOmAuditLog);
			
			EXECUTE IMMEDIATE vSql INTO vReportDeliveryStatus;

			vOmAuditLog.sqlExecuted = 'Publisher Report Delivery Status -'||vReportDeliveryStatus;
			CALL writeAuditLogV2(vOmAuditLog);
			
			IF (vReportDeliveryStatus > 0) THEN
	   
				/*! We grab all intervals that was ever published for this report until SUBSCRIPTION_CHECK_LOOKBACK_HOURS */

				vSql = 'SELECT /*! ValidateMarketHourlyReportCompleteness */ MARKET_ID, 
													REPORT_INTERVAL_START_TIME, REPORT_DELIVERY_START_TIME
								FROM USER_REPORTS_SUBSCRIPTION_STATUS
								WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||' 
								AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL '||vLookBackHours ||' HOUR
								AND REPORT_DELIVERY_STATUS = ''PUBLISHER_COMPLETE''';	
					
					vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
					CALL writeAuditLogV2(vOmAuditLog);

				qryReportIntervalStartTime = SELECT /*! ValidateMarketHourlyReportCompleteness */ MARKET_ID, 
													REPORT_INTERVAL_START_TIME, REPORT_DELIVERY_START_TIME
											 FROM USER_REPORTS_SUBSCRIPTION_STATUS
											 WHERE SUBSCRIPTION_ID = pSubscriptionId
											 AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
											 AND REPORT_DELIVERY_STATUS = 'PUBLISHER_COMPLETE';
																		
				recReportIntervalStartTime = COLLECT(qryReportIntervalStartTime);

				/*! we check if any group, in the list of groups for the report, for that particular REPORT_INTERVAL_START_TIME, the REPORT_DELIVERY_START_TIME < hourly_data_timestamp */

				vOmAuditLog.sqlExecuted ='Lenght of Report Interval Start Time '||LENGTH(recReportIntervalStartTime);
				CALL writeAuditLogV2(vOmAuditLog);
	
				IF LENGTH(recReportIntervalStartTime) > 0 THEN
	
					FOR i IN 1..LENGTH(recReportIntervalStartTime) - 1 LOOP
					
					vMarketId2 = recReportIntervalStartTime[i].MARKET_ID;
					vReportIntervalStartTime = recReportIntervalStartTime[i].REPORT_INTERVAL_START_TIME;
					vReportDeliveryStartTime = recReportIntervalStartTime[i].REPORT_DELIVERY_START_TIME;

					vOmAuditLog.sqlExecuted ='vMarketId2 ('||vMarketId2||') vReportIntervalStartTime ( '||vReportIntervalStartTime||' ) vReportDeliveryStartTime ('||vReportDeliveryStartTime||')';
					CALL writeAuditLogV2(vOmAuditLog);	
					
					vSql = 	'SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
							(
								SELECT 1 FROM '||pDatabase||'.OM_DATA_INTERVALS
								WHERE GROUP_NAME IN (SELECT TABLE_COL FROM TABLE(SPLIT('||QUOTE(vGroupName)||','','')))
								AND MARKET_ID = '||QUOTE(vMarketId2)||'
								AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||'
								AND HOURLY_DATA_TIMESTAMP > '||QUOTE(vReportDeliveryStartTime)||'
							)';
					vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
					CALL writeAuditLogV2(vOmAuditLog);
				
					EXECUTE IMMEDIATE vSql INTO vReportReRunExtractStatus;

					vOmAuditLog.sqlExecuted = 'Report Re-run extract status: '||vReportReRunExtractStatus;
					CALL writeAuditLogV2(vOmAuditLog);						
	
						IF vReportReRunExtractStatus > 0 THEN
	
							vSql ='UPDATE /*! ValidateMarketHourlyReportCompleteness */ USER_REPORTS_SUBSCRIPTION_STATUS 
									SET REPORT_DELIVERY_STATUS = NULL
									WHERE 
									SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||' 
									AND REPORT_INTERVAL_START_TIME = '||QUOTE(vReportIntervalStartTime)||' 
									AND REPORT_INTERVAL_END_TIME = '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
									AND REPORT_DELIVERY_STATUS = ''PUBLISHER_COMPLETE''';
						
							vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
							CALL writeAuditLogV2(vOmAuditLog);
				
							EXECUTE IMMEDIATE vSql;	
													
							vSubscriptionRetryCount = vSubscriptionRetryCount + row_count();
							
							vOmAuditLog.sqlExecuted = 'Subscription retry count: '||vSubscriptionRetryCount;
							CALL writeAuditLogV2(vOmAuditLog);
												
						END IF; 
					END LOOP; 
				END IF; 
			END IF; 

			/*! Case 2 - DATA_LOSS_DETECTED scenarios */

			vOmAuditLog.sqlExecuted = 'CASE 2-DATA_LOSS_DETECTED' ;
			CALL writeAuditLogV2(vOmAuditLog);
			
			vSql ='SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
					(
						SELECT 1 
						FROM USER_REPORTS_SUBSCRIPTION_STATUS 
						WHERE SUBSCRIPTION_ID ='||QUOTE( pSubscriptionId)||' 
						AND REPORT_READINESS = ''DATA_LOSS_DETECTED''
						AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL '||vLookBackHours ||' HOUR
						LIMIT 1
					) ';
			
			vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
			CALL writeAuditLogV2(vOmAuditLog);
				
			EXECUTE IMMEDIATE vSql INTO vReportDataLossStatus;	

			vOmAuditLog.sqlExecuted = 'Report Data Loss Status '||vReportDataLossStatus;
			CALL writeAuditLogV2(vOmAuditLog);
			
			IF vReportDataLossStatus > 0 THEN
			  
				/*! We grab all intervals that was ever published for this report until SUBSCRIPTION_CHECK_LOOKBACK_HOURS */
				vSql ='SELECT /*! ValidateMarketHourlyReportCompleteness */ 
												MARKET_ID, 
												REPORT_INTERVAL_START_TIME, 
												REPORT_DELIVERY_START_TIME
						FROM USER_REPORTS_SUBSCRIPTION_STATUS
						WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'
						AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL '||vLookBackHours ||' HOUR
						AND REPORT_READINESS = ''DATA_LOSS_DETECTED''';

				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				
				qryReportIntervalStartTime = SELECT /*! ValidateMarketHourlyReportCompleteness */ 
												MARKET_ID, 
												REPORT_INTERVAL_START_TIME, 
												REPORT_DELIVERY_START_TIME
											 FROM USER_REPORTS_SUBSCRIPTION_STATUS
											 WHERE SUBSCRIPTION_ID = pSubscriptionId
											 AND REPORT_INTERVAL_START_TIME > NOW() - INTERVAL vLookBackHours HOUR
											 AND REPORT_READINESS = 'DATA_LOSS_DETECTED';
							
				recReportIntervalStartTime = COLLECT(qryReportIntervalStartTime);

				/*! we need to check if data is available for the report  */
	
				IF LENGTH(recReportIntervalStartTime) > 0 THEN
	
					FOR i IN 1..LENGTH(recReportIntervalStartTime) - 1 LOOP
					
					vMarketId2 = recReportIntervalStartTime[i].MARKET_ID;
					vReportIntervalStartTime = recReportIntervalStartTime[i].REPORT_INTERVAL_START_TIME;
					vReportDeliveryStartTime = recReportIntervalStartTime[i].REPORT_DELIVERY_START_TIME;

					vOmAuditLog.sqlExecuted ='vMarketId2 ('||vMarketId2||') vReportIntervalStartTime ( '||vReportIntervalStartTime||' ) vReportDeliveryStartTime ('||vReportDeliveryStartTime||')';
					CALL writeAuditLogV2(vOmAuditLog);	
										
					vSql = 'SELECT /*! ValidateMarketHourlyReportCompleteness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportCompleteness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN (SELECT TABLE_COL FROM TABLE(SPLIT('||QUOTE(vGroupName)||','','')))
							AND MARKET_ID = '||QUOTE(vMarketId2)||'
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
						)';
	
					vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
					CALL writeAuditLogV2(vOmAuditLog);
					
					EXECUTE IMMEDIATE vSql INTO vReportDataLossTrafficHourCheckStatus;
					
					vOmAuditLog.sqlExecuted = 'Report DataLoss Traffic Hour Check Status: '||vReportDataLossTrafficHourCheckStatus;
					CALL writeAuditLogV2(vOmAuditLog);			
	
						IF vReportDataLossTrafficHourCheckStatus > 0 THEN
	
							vSql ='UPDATE /*! ValidateMarketHourlyReportCompleteness */ USER_REPORTS_SUBSCRIPTION_STATUS  
										SET REPORT_READINESS = ''READY_FOR_DELIVERY'',
											REPORT_READINESS_TRIGGER = ''INTERVAL_IS_AVAILABLE''
										WHERE 
										SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId) ||'
										AND REPORT_INTERVAL_START_TIME = '||QUOTE(vReportIntervalStartTime)||'
										AND REPORT_INTERVAL_END_TIME = '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
										AND REPORT_READINESS =   ''DATA_LOSS_DETECTED''';
													
							vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
							CALL writeAuditLogV2(vOmAuditLog);

							EXECUTE IMMEDIATE vSql;

							vSubscriptionDataLossRetryCount = vSubscriptionDataLossRetryCount + row_count();

							vOmAuditLog.sqlExecuted = 'Subscription Data Loass Retry Count: '||vSubscriptionDataLossRetryCount;
							CALL writeAuditLogV2(vOmAuditLog);	

						END IF; 
					END LOOP; 
				END IF; 
			END IF ; 
		ELSE 		

			ECHO SELECT /*!ValidateMarketHourlyReportCompleteness*/ 
						vOmAuditLog.spName AS APP_NAME, 
					    'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||') ' AS ARGUMENTS, 
						'FAILED' AS STATUS, 
						'REPORT is NOT ENABLED/INVALID'  AS REASON 
						FROM DUAL;

			vOmAuditLog.sqlExecuted = 'REPORT IS NOT ENABLED/INVALID';
			CALL writeAuditLogV2(vOmAuditLog);			  
			RETURN;	
		END IF ; 
		
		COMMIT; 
		
		vOmAuditLog.sqlExecuted = 'Process Completed';
		CALL writeAuditLogV2(vOmAuditLog);	
	
	END IF; 

	INSERT /*! ValidateMarketHourlyReportCompleteness */ INTO APP_ACTIVITIES_LOG 
		   (APP_NAME,
		   BATCH_ID,
		   ACTIVITY_TYPE,
		   ACTIVITY_DETAILS,
		   ACTIVITY_OUTPUT,
		   ACTIVITY_ERROR_MSG,
		   ACTIVITY_START_TS,
		   ACTIVITY_END_TS,
		   ACTIVITY_STATUS) 
    VALUES (vOmAuditLog.spName,
		   vSessionIdentifier,
		   'Executing Procedure',
		   'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||')' ,
		   'Total of '||vSubscriptionRetryCount+vSubscriptionDataLossRetryCount ||' TRAFFIC_HOURS updated: ('||vSubscriptionRetryCount||') as retries and ('||vSubscriptionDataLossRetryCount||') as data loss for Subscription '||pSubscriptionId||' to re-export',
		   NULL,
		   vActivityStartTime,
		   NOW(6),
		   'COMPLETE');
  COMMIT;

  ECHO SELECT /*!ValidateMarketHourlyReportCompleteness*/ 
			  vOmAuditLog.spName AS APP_NAME, 
			  'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||') ' AS ARGUMENTS, 
		       'COMPLETE' AS STATUS, 
			   'Total of ' ||vSubscriptionRetryCount+vSubscriptionDataLossRetryCount ||' TRAFFIC_HOURS updated: ('||vSubscriptionRetryCount||') as retries and ('||vSubscriptionDataLossRetryCount||') as data loss for Subscription '||pSubscriptionId||' to re-export' AS REASON
		 FROM DUAL;

EXCEPTION	
    WHEN OTHERS THEN
        /*! Trapping Exceptions into APP_ACTIVITIES_LOG When Audit Log is disabled */	
	    IF vAppLogLevel='ERROR' THEN
		ROLLBACK;
		INSERT /*! ValidateMarketHourlyReportCompleteness */ INTO APP_ACTIVITIES_LOG (
										 APP_NAME,
										 BATCH_ID,
										 ACTIVITY_TYPE,
										 ACTIVITY_DETAILS,
										 ACTIVITY_OUTPUT,
										 ACTIVITY_ERROR_MSG,
										 ACTIVITY_START_TS,
										 ACTIVITY_END_TS,
										 ACTIVITY_STATUS) 
										VALUES 
										( 
										 vOmAuditLog.spName,
										 vSessionIdentifier,
										 'Executing Procedure',										 
										 'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||')' ,
										 NULL,
										 exception_message(),
										 vActivityStartTime,
										 NOW(6),
										 'COMPLETE'
										 );
        COMMIT;
		END IF;
	  /*! Trapping Exceptions into OM_AUDIT_LOG table When Audit Log is enabled */
	  IF vAppLogLevel='DEBUG' THEN
		  vOmAuditLog.errorMsg = exception_message();
		  vOmAuditLog.sqlExecuted =  'Found Exception ';
		  CALL writeAuditLogV2(vOmAuditLog);
		  COMMIT;
      END IF;		  

	ECHO SELECT /*!ValidateMarketHourlyReportCompleteness*/ 
			    vOmAuditLog.spName AS APP_NAME, 
			  'Procedure Arguments: (' || QUOTE(pDatabase)  || ',' || QUOTE(pSubscriptionId) || ',' || vLookBackHours||') ' AS ARGUMENTS, 
		        'FAILED' AS STATUS, 
		        exception_message() AS REASON 
		   FROM DUAL;
	  
	 RAISE;  
END;
//
DELIMITER ;

