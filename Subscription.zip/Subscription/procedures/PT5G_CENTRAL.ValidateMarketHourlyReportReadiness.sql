/*
Database : PT5G_CENTRAL
Procedure: ValidateMarketHourlyReportReadiness
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `ValidateMarketHourlyReportReadiness`(pDatabase varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pSubscriptionId varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pLookBackHours int(11) NULL DEFAULT NULL, pDataLossIsTrue tinyint(1) NULL DEFAULT NULL) RETURNS void AS
DECLARE

/*!
  PROCEDURE NAME       : ValidateMarketHourlyReportReadiness
  DATE CREATED         : DEC 22, 2023
  VERSION			   : V2
  AUTHOR			   : Krishna M
  PROCEDURE DESC	   : Smart Reports - NTSCA-26827
					   : Example invocation - call ValidateMarketHourlyReportReadiness('PT5G','0ce65105a59c4fcf847fe543749c1f8a28242c4408448462c16f6e79b767cf25a5d67aa31fd400fa3ccb9132472a4089593b1fd7e856d254f87020bd16ee3292',NULL,0);
					    The procedure will do the following.
						1. Lookup SUBSCRIPTION_ID (combination of REPORT_ID and MARKET_ID) from USER_REPORTS_SUBSCRIPTION (maintained by the UI) with select for update. We will take a rowlevel lock for the duration  of procedure to prevent multiple instances running at same time for the same report.
						2. Validate that the Report is Market/Hourly
						3. Retrieve the lists of market_ids and the corresponding GROUP_NAMEs for the Report from USER_REPORTS_SUBSCRIPTION
						4. Retrieve other metadata relating to the Report.
						5. Check latest traffic_hour in OM_DATA_INTERVALS for a combination of GROUP_NAME+Market_id. 
						6. Manage the following cases
							6.1 - Current PENDING interval is ready. Next TRAFFIC_HOUR is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING.
							6.2 - Current PENDING interval is not ready. Next interval has not started loading yet. Check for next available interval. If identified, then mark all intervals upto next available interval as DATA_LOSS_DETECTED. Add the next available interval as READY_FOR_DELIVERY and continue. 
							6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.
							6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available traffic_hour to create the first entry and use pLookBackHours as the window to go back in time.
							6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.
							6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest traffic_hour
							
						How do we cross-validate? This query should help
						SELECT TRAFFIC_HOUR,  market_id, count(1)
						FROM  OM_DATA_INTERVALS WHERE CURRENT_HOUR = 'Y' AND GROUP_NAME IN  (<list of groups for the report>) GROUP BY traffic_hour, market_id order by 3
						We expect that the the count will match the number of groups in the report for a specific market_id and traffic_hour

  MODIFICATION HISTORY : manohkr - July 11, 2023. NTSCA-21950-Introduced DATA_AVAILABILITY_FACTOR. 
						This is to ensure that Subscriptions will continue to mark intervals as ready even if all the groups for a report are not available. This is a temporary fix until we rework hourly aggregations to be consistent. ALPT is more prone to missing data.
						: manohkr - Oct 2, 2023. NTSCA-24172 - Part 1 of Add hooks into DlpProcessHourlyData to trigger running extracts again if hourly was reprocessed
						Added changes to mark intervals as DATA_LOSS_DETECTED. The goal is to have a secondary process that will run async and determine feasiblity of re-running these extracts
						: manohkr - Dec 9, 2023 - NTSCA-26569 - Bug fix Line 424 to address null values for vReportIntervalFirstAvailableStartTime
  
*/  

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 logTime DATETIME,
						 errorCode INT,
						 errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin 
						 ) 
								= ROW(NULL,
									NULL,
									NULL,
									NULL,
									NULL,
									NULL
									);

	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);
	vCheckReportisEnabled INT;
	vMarketId LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin;
	vMarketId2 LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin;
	vGroupName LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vGroupName2 LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEndDate VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vSql LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vCountMaxTrafficHour INT;
	vCountMarketId INT;
	vCountGroupName INT;
	vCountMarketGroup INT;
	vReportIntervalStartTime DATETIME;
	vReportIntervalEndTime DATETIME;
	vReportIntervalFirstAvailableStartTime DATETIME;
	vReportCheckStatus INT;
	vReportReadinessCheckStatus INT;
	vReportMaxTrafficHour DATETIME;
	vReportCurrentMaxTrafficHour DATETIME;
	vReportUserName VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEnvironment VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportVendor VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportName VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportType VARCHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportCurrentTrafficHourCheckStatus INT;
	vReportNextTrafficHourCheckStatus INT;
	vReportIntervalFirstAvailableStartTimeCheckStatus INT;
	vrowcount BIGINT DEFAULT 0;
	vMarketCurrentTime DATETIME;
	vLookBackHours INT;
	vReportId BIGINT;
	vDataAvailabilityFactor INT;

BEGIN
	vOmAuditLog.spName = 'ValidateMarketHourlyReportReadiness';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';
  
	vOmAuditLog.sqlExecuted =  'Started processing with arguments :(' ||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')';
	vOmAuditLog.sqlVariables = pDatabase||','|| pSubscriptionId||','||pLookBackHours||','||pDataLossIsTrue;
  	
	SELECT /*! ValidateMarketHourlyReportReadiness */ NOW(6) INTO vActivityStartTime;
	SELECT /*! ValidateMarketHourlyReportReadiness */ UUID() INTO vSessionIdentifier;
  
	SELECT /*! ValidateMarketHourlyReportReadiness */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;
  
	/*! - Checking for DATA_AVAILABILITY_FACTOR - Default is 80 if not found */
	  
	SELECT /*! ValidateMarketHourlyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),80) 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'DATA_AVAILABILITY_FACTOR' 
	INTO vDataAvailabilityFactor;	 
	
IF vAppLogLevel = 'ERROR' THEN
		/*! - we validate the report id is enabled */
		SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = pSubscriptionId 
			AND IS_ENABLED = 'Y' 
			AND REPORT_TYPE = 'Hourly Totals' 
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		) 
		INTO vCheckReportisEnabled;

		IF vCheckReportisEnabled > 0 THEN
			/*! we select all metadata for the report */
			START TRANSACTION;
				SELECT /*! ValidateMarketHourlyReportReadiness */ USER_NAME,
					 ENVIRONMENT,
					 VENDOR,
					 REPORT_ID,
					 REPORT_NAME,
					 REPORT_TYPE,
					 REPORT_END_DATE, 
					 '('||CommaStringToList(MARKET_ID)||')', 
					 MARKET_ID,
					 CountElementsCommaString(MARKET_ID), 
					 '('||CommaStringToList(GROUP_NAME)||')',
					 GROUP_NAME,
					 CountElementsCommaString(GROUP_NAME)		
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = pSubscriptionId FOR UPDATE
				INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
					 vReportEndDate, vMarketId, vMarketId2,  vCountMarketId, vGroupName, vGroupName2, vCountGroupName; 

				/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */		
				vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);
					
				/*! find out if we ever checked for this report*/
				SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
				(
					SELECT 1 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS 
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
				) 
				INTO vReportCheckStatus;

				/*! - If prior run is available, then we pickup the last interval that we checked for */
			IF (vReportCheckStatus > 0 AND pDataLossIsTrue = 0) THEN
				/*! We always expect to see an entry in Pending state */
				SELECT /*! ValidateMarketHourlyReportReadiness */ 
					   REPORT_INTERVAL_START_TIME,
					   REPORT_INTERVAL_END_TIME
				FROM USER_REPORTS_SUBSCRIPTION_STATUS 
				WHERE SUBSCRIPTION_ID = pSubscriptionId 
				AND REPORT_READINESS = 'PENDING' 
				INTO vReportIntervalStartTime, vReportIntervalEndTime;
					
				/*! - We need to see if the pending hour is ready for reports */
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportReadiness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
						)';
	
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
					
				/*! - We need to see if the next hour is ready for reports */
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportReadiness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN  '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||
						')';
			
				
				EXECUTE IMMEDIATE vSql INTO vReportNextTrafficHourCheckStatus;

					/*! Case 6.1 - Current PENDING interval is ready. Next TRAFFIC_HOUR is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING. */
					IF (vReportCurrentTrafficHourCheckStatus > 0 and vReportNextTrafficHourCheckStatus = 0 ) THEN 
						UPDATE  /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
						SET REPORT_READINESS = 'READY_FOR_DELIVERY',
							 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
							 REPORT_READINESS_UPDATED_AT = NOW(6)
						WHERE SUBSCRIPTION_ID = pSubscriptionId 
						AND REPORT_INTERVAL_END_TIME = vReportIntervalEndTime 
						AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime;
								
						vrowcount = vrowcount+row_count();
		
						/*! - Add an entry for the next traffic_hour as pending */
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							VALUES
							(
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  vReportIntervalEndTime,
							  vReportIntervalEndTime + INTERVAL 1 HOUR,
							  'PENDING',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							);
							vrowcount = vrowcount + row_count();
							/*! or if the vReportCutoffTimeThresholdHours has elapsed */					
					END IF;
				
				/*!	6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentTrafficHourCheckStatus = 0 AND vReportNextTrafficHourCheckStatus > 0 ) THEN
					UPDATE /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'NEXT_INTERVAL_HAS_FINISHED_LOADING',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					AND REPORT_INTERVAL_END_TIME = vReportIntervalEndTime 
					AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime;
						
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next traffic_hour as READY_FOR_DELIVERY */
					  INSERT  /*! ValidateMarketHourlyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_TRIGGER,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndTime,
						vReportIntervalEndTime + INTERVAL 1 HOUR,
						'READY_FOR_DELIVERY',
						'INTERVAL_IS_AVAILABLE',
						NOW(),
						vGroupName2,
						vMarketId2
					  );

					  /*! - Add an entry for the next traffic_hour as PENDING */
					  INSERT  /*! ValidateMarketHourlyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndTime + INTERVAL 1 HOUR,
						vReportIntervalEndTime + INTERVAL 2 HOUR,
						'PENDING',
						NOW(),
						vGroupName2,
						vMarketId2
					  );					  
					  vrowcount = vrowcount + row_count();
				END IF;
					
				/*!	6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentTrafficHourCheckStatus > 0 AND vReportNextTrafficHourCheckStatus > 0 ) THEN
					UPDATE /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					 SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalEndTime 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime;
					
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next traffic_hour as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndTime,
						 vReportIntervalEndTime + INTERVAL 1 HOUR,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);

					/*! - Add an entry for the next traffic_hour as PENDING */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndTime + INTERVAL 1 HOUR,
						 vReportIntervalEndTime + INTERVAL 2 HOUR,
						 'PENDING',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);
					vrowcount = vrowcount + row_count();							
				END IF;					
										
				/*! 6.2 - Current PENDING interval is not ready. No new intervals available (Next interval has not started loading yet). Sleep and retry. */
				/*! we update the Report readiness updated column to show we checked this report */							
				IF ( vReportCurrentTrafficHourCheckStatus = 0 and vReportNextTrafficHourCheckStatus = 0 )  THEN

				 /*! - Check to see if min(traffic_hour) > vReportIntervalStartTime + INTERVAL 1 HOUR */


					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */  EXISTS 
							(
								SELECT TRAFFIC_HOUR AS TRAFFIC_HOUR 
								FROM '||pDatabase||'.OM_DATA_INTERVALS 
								WHERE CURRENT_HOUR = ''Y'' 
								AND GROUP_NAME IN  '||vGroupName||' 
								AND MARKET_ID IN '||vMarketId||' 
								AND TRAFFIC_HOUR > '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
								GROUP BY TRAFFIC_HOUR 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								LIMIT 1
							)';
				
					EXECUTE IMMEDIATE vSql into vReportIntervalFirstAvailableStartTimeCheckStatus;
				   
					IF vReportIntervalFirstAvailableStartTimeCheckStatus > 0 THEN 
					
						vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MIN(TRAFFIC_HOUR) AS TRAFFIC_HOUR 
								FROM
								(
								SELECT TRAFFIC_HOUR
								FROM '||pDatabase||'.OM_DATA_INTERVALS 
								WHERE CURRENT_HOUR = ''Y'' 
								 AND GROUP_NAME IN  '||vGroupName||' 
								 AND MARKET_ID IN '||vMarketId||' 
								 AND TRAFFIC_HOUR > '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
								GROUP BY TRAFFIC_HOUR 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								)'
								;
			
			  
						EXECUTE IMMEDIATE vSql INTO vReportIntervalFirstAvailableStartTime;
						
							/*! We now mark the intervals < vReportIntervalFirstAvailableStartTime as DATE_LOSS_DETECTED */
						
							UPDATE  /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							SET REPORT_READINESS = 'DATA_LOSS_DETECTED',
								 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_NOT_AVAILABLE',
								 REPORT_READINESS_UPDATED_AT = NOW(6)
							WHERE SUBSCRIPTION_ID = pSubscriptionId 
								  AND REPORT_INTERVAL_END_TIME = vReportIntervalEndTime 
								  AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime;								
							vrowcount = vrowcount+row_count();
						
						
						
						
						
						
						
						
						
						
						
						
					
							/*! Insert all the missing intervals upto vReportIntervalFirstAvailableStartTime as DATA_LOSS_DETECTED */
					
					
							INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_TRIGGER,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							SELECT 
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  TABLE_COL,
							  TABLE_COL + INTERVAL 1 HOUR,
							  'DATA_LOSS_DETECTED',
							  'INTERVAL_IS_NOT_AVAILABLE',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							  FROM 
							  TABLE(getTimeBuckets(vReportIntervalFirstAvailableStartTime,3,'INTERVAL_HOURLY'))
							  WHERE 
							  TABLE_COL >= vReportIntervalStartTime + INTERVAL 1 HOUR 
							  ;					
							vrowcount = vrowcount + row_count();				
					
							/*! - Add an entry for the vReportIntervalFirstAvailableStartTime  as available */
								
							INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_TRIGGER,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartTime,
								vReportIntervalFirstAvailableStartTime + INTERVAL 1 HOUR,
								'READY_FOR_DELIVERY',
								'INTERVAL_IS_AVAILABLE',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );
							  
							vrowcount = vrowcount + row_count();
						
							/*! - Add an entry for the next traffic_hour as pending */
								
							INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartTime + INTERVAL 1 HOUR,
								vReportIntervalFirstAvailableStartTime + INTERVAL 2 HOUR,
								'PENDING',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );					  
							vrowcount = vrowcount + row_count();			
						
						/*! vReportIntervalFirstAvailableStartTimeCheckStatus = 0 */
						ELSE
						
							ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
												
							INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO APP_ACTIVITIES_LOG 
							  ( APP_NAME,
								BATCH_ID,
								ACTIVITY_TYPE,
								ACTIVITY_DETAILS,
								ACTIVITY_OUTPUT,
								ACTIVITY_ERROR_MSG,
								ACTIVITY_START_TS,
								ACTIVITY_END_TS,
								ACTIVITY_STATUS) 
							VALUES 
							 ( vOmAuditLog.spName,
							   vSessionIdentifier,
							   'Executing Procedure',
							   'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
							   NULL,
							   'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId,
							   vActivityStartTime,
							   NOW(6),
							   'EXCEPTION'); 	 
							COMMIT;
							RETURN;					
					    END IF;
				END IF;
			END IF;
		
			IF (vReportCheckStatus = 0 AND pDataLossIsTrue = 0) THEN
				/*!	6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available traffic_hour to create the first entry
				/*! - We see if there is any traffic hour that matches the condition within the last vLookBackHours hours from UTC */
				IF pLookBackHours IS NULL THEN
					SELECT /*! ValidateMarketHourlyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_HOURS' 
					INTO vLookBackHours;
				ELSE 
					vLookBackHours = pLookBackHours;
				END IF;

				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
		
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
					
				/*! - If there is an available traffic_hour - we pickup the max traffic hour that matches the conditions */
				
				IF vReportCurrentTrafficHourCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MAX(TRAFFIC_HOUR) AS TRAFFIC_HOUR
							FROM 
							(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
					
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartTime;
			
					/*! - Add an entry for this traffic_hour as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
						)
					VALUES
					   ( 
						 vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartTime,
						 vReportIntervalStartTime + INTERVAL 1 HOUR,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);
		
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next traffic_hour as pending */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					  INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   SUBSCRIPTION_ID,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_INTERVAL_START_TIME, 
						   REPORT_INTERVAL_END_TIME, 
						   REPORT_READINESS,
						   REPORT_READINESS_UPDATED_AT,
						   GROUP_NAME,
						   MARKET_ID
						 )
					VALUES
						( vReportUserName,
						  vReportEnvironment,
						  vReportVendor,
						  pSubscriptionId,
						  vReportId,
						  vReportName,
						  vReportIntervalStartTime + INTERVAL 1 HOUR,
						  vReportIntervalStartTime + INTERVAL 2 HOUR,
						  'PENDING',
						  NOW(6),
						  vGroupName2,
						  vMarketId2
						);
					
					vrowcount = vrowcount + row_count();
								
				ELSIF vReportCurrentTrafficHourCheckStatus = 0 THEN
				
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;			
			END IF;
					
			IF (pDataLossIsTrue > 0) THEN
				/*! 6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest traffic_hour. Same logic as new entry */
				/*! - All other conditions are negated */
				/*! - We see if there is any traffic hour that matches the condition within the last vLookBackHours hours from UTC */
				IF pLookBackHours IS NULL THEN
					SELECT /*! ValidateMarketHourlyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_HOURS' 
					INTO vLookBackHours;
				ELSE 
					vLookBackHours = pLookBackHours;
				END IF;
						
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
			
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
					
				/*! - If there is an available traffic_hour - we pickup the max traffic hour that matches the conditions */
				IF vReportCurrentTrafficHourCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MAX(TRAFFIC_HOUR) AS TRAFFIC_HOUR 
							FROM
							(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
			  
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartTime;
			
					/*! - Delete entries if any exists for this Report that is for the above traffic_hour */
					DELETE /*! ValidateMarketHourlyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartTime
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalStartTime + INTERVAL 1 HOUR;
							
					/*! - Delete entries if any exists for this Report that is marked as PENDING */
					DELETE /*! ValidateMarketHourlyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_READINESS = 'PENDING';
																	
					/*! - Add an entry for this traffic_hour as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartTime,
						 vReportIntervalStartTime + INTERVAL 1 HOUR,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);			
					vrowcount = vrowcount + row_count();
					/*! - Add an entry for the next traffic_hour as pending */
						
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					  ( vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalStartTime + INTERVAL 1 HOUR,
						vReportIntervalStartTime + INTERVAL 2 HOUR,
						'PENDING',
						NOW(6),
						vGroupName2,
						vMarketId2
					  );
				
					vrowcount = vrowcount + row_count();
				ELSIF vReportCurrentTrafficHourCheckStatus = 0 THEN
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;					
			END IF;
			/*! Release the transaction lock on the Report */
			COMMIT;
		ELSE 
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Subscription -'||pSubscriptionId||' is not enabled AND/OR is not an Hourly report' AS REASON FROM DUAL;
		END IF;
END IF; 

IF vAppLogLevel = 'DEBUG' THEN
		CALL writeAuditLogV2(vOmAuditLog);
		/*! - we validate the report id is enabled */
		vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'
			AND IS_ENABLED = ''Y'' 
			AND REPORT_TYPE = ''Hourly Totals''
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		)';		
		
		vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
		CALL writeAuditLogV2(vOmAuditLog);
		
		EXECUTE IMMEDIATE vSql INTO vCheckReportisEnabled;

		vOmAuditLog.sqlExecuted = 'Report check returned:'||vCheckReportisEnabled;
		CALL writeAuditLogV2(vOmAuditLog);

		IF vCheckReportisEnabled > 0 THEN
			/*! we select all metadata for the report */
			START TRANSACTION;
				SELECT /*! ValidateMarketHourlyReportReadiness */ USER_NAME,
					 ENVIRONMENT,
					 VENDOR,
					 REPORT_ID,
					 REPORT_NAME,
					 REPORT_TYPE,
					 REPORT_END_DATE, 
					 '('||CommaStringToList(MARKET_ID)||')', 
					 MARKET_ID,
					 CountElementsCommaString(MARKET_ID), 
					 '('||CommaStringToList(GROUP_NAME)||')',
					 GROUP_NAME,
					 CountElementsCommaString(GROUP_NAME)		
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = pSubscriptionId FOR UPDATE
				INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
					 vReportEndDate, vMarketId, vMarketId2,  vCountMarketId, vGroupName, vGroupName2, vCountGroupName;				
			 
				vOmAuditLog.sqlExecuted = 'Groups in report:'||QUOTE(vGroupName);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of Groups in report:'||vCountGroupName;
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = 'Markets in report:'||QUOTE(vMarketId);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of markets in report:'||vCountMarketId;
				CALL writeAuditLogV2(vOmAuditLog);

			/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */
		
			vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);
				
			vOmAuditLog.sqlExecuted = 'Logging active countmarketgroup: '||vCountMarketGroup;
			CALL writeAuditLogV2(vOmAuditLog);
		
			/*! find out if we ever checked for this report*/
			vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
				(
					SELECT 1 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS 
					WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||
				')';
				
				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				
				EXECUTE IMMEDIATE vSql INTO vReportCheckStatus;

			vOmAuditLog.sqlExecuted = 'Report status check returned:'||vReportCheckStatus;
			CALL writeAuditLogV2(vOmAuditLog);

			/*! - If prior run is available, then we pickup the last interval that we checked for */
			IF (vReportCheckStatus > 0 AND pDataLossIsTrue = 0) THEN
				/*! We always expect to see an entry in Pending state */
				vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ 
					   REPORT_INTERVAL_START_TIME,
					   REPORT_INTERVAL_END_TIME
					FROM USER_REPORTS_SUBSCRIPTION_STATUS 
					WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||' 
					AND REPORT_READINESS = ''PENDING''';
				
				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				
				EXECUTE IMMEDIATE vSql INTO vReportIntervalStartTime, vReportIntervalEndTime;

				vOmAuditLog.sqlExecuted = 'check for current hour if ready for reports returned: '||vReportCurrentTrafficHourCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! - We need to see if the pending hour is ready for reports */
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportReadiness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
		
				vOmAuditLog.sqlExecuted = 'Check for pending hours: '||NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
						    
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
				
				/*! - We need to see if the next hour is ready for reports */
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketHourlyReportReadiness */ TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN  '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND TRAFFIC_HOUR = '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR 
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							LIMIT 1
							)';
	    
				vOmAuditLog.sqlExecuted = 'Check to see if next hour is ready for reports: '||NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				EXECUTE IMMEDIATE vSql INTO vReportNextTrafficHourCheckStatus;

				/*! Case 6.1 - Current PENDING interval is ready. Next TRAFFIC_HOUR is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING. */
				IF (vReportCurrentTrafficHourCheckStatus > 0 AND vReportNextTrafficHourCheckStatus = 0 ) THEN 
						vSql='UPDATE  /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
								SET REPORT_READINESS = ''READY_FOR_DELIVERY'',
									 REPORT_READINESS_TRIGGER = ''INTERVAL_IS_AVAILABLE'',
									 REPORT_READINESS_UPDATED_AT = NOW(6)
								WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )|| ' 
								AND REPORT_INTERVAL_END_TIME = '||QUOTE(vReportIntervalEndTime)||'  
								AND REPORT_INTERVAL_START_TIME ='||QUOTE( vReportIntervalStartTime);								
						
						vOmAuditLog.sqlExecuted = 'Check to see if next hour is ready for reports: '||NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);
						EXECUTE IMMEDIATE vSql;
						
						vrowcount = vrowcount+row_count();
						vOmAuditLog.sqlExecuted = 'No.of records updated for READY_FOR_DELIVERY: ('||vrowcount||')';
						CALL writeAuditLogV2(vOmAuditLog);
		
						/*! - Add an entry for the next traffic_hour as pending */
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							VALUES
							(
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  vReportIntervalEndTime,
							  vReportIntervalEndTime + INTERVAL 1 HOUR,
							  'PENDING',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							);
							vrowcount = vrowcount + row_count();
							vOmAuditLog.sqlExecuted = 'No.of Pending records inserted for next traffic_hour : ('||vrowcount||')';
							CALL writeAuditLogV2(vOmAuditLog);
							/*! or if the vReportCutoffTimeThresholdHours has elapsed */					
				END IF;	
					
					/*!	6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
					IF ( vReportCurrentTrafficHourCheckStatus = 0 AND vReportNextTrafficHourCheckStatus > 0 ) THEN
						vSql='UPDATE /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
								SET REPORT_READINESS = ''READY_FOR_DELIVERY'',
									 REPORT_READINESS_TRIGGER = ''NEXT_INTERVAL_HAS_FINISHED_LOADING'',
									 REPORT_READINESS_UPDATED_AT = NOW(6)
								WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||' 
								AND REPORT_INTERVAL_END_TIME ='||QUOTE( vReportIntervalEndTime)||'  
								AND REPORT_INTERVAL_START_TIME ='||QUOTE( vReportIntervalStartTime);
						
						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);    
						EXECUTE IMMEDIATE vSql;
							
						vrowcount = vrowcount + row_count();
						vOmAuditLog.sqlExecuted = 'No.of current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.  : ('||vrowcount||')';
						CALL writeAuditLogV2(vOmAuditLog);
						
						/*! - Add an entry for the next traffic_hour as READY_FOR_DELIVERY */
						  INSERT  /*! ValidateMarketHourlyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						  (
							USER_NAME,
							ENVIRONMENT,
							VENDOR,
							SUBSCRIPTION_ID,
							REPORT_ID,
							REPORT_NAME,
							REPORT_INTERVAL_START_TIME, 
							REPORT_INTERVAL_END_TIME, 
							REPORT_READINESS,
							REPORT_READINESS_TRIGGER,
							REPORT_READINESS_UPDATED_AT,
							GROUP_NAME,
							MARKET_ID
						  )
						  VALUES
						  (
							vReportUserName,
							vReportEnvironment,
							vReportVendor,
							pSubscriptionId,
							vReportId,
							vReportName,
							vReportIntervalEndTime,
							vReportIntervalEndTime + INTERVAL 1 HOUR,
							'READY_FOR_DELIVERY',
							'INTERVAL_IS_AVAILABLE',
							NOW(),
							vGroupName2,
							vMarketId2
						  );
						
						  /*! - Add an entry for the next traffic_hour as PENDING */
						  INSERT  /*! ValidateMarketHourlyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						  (
							USER_NAME,
							ENVIRONMENT,
							VENDOR,
							SUBSCRIPTION_ID,
							REPORT_ID,
							REPORT_NAME,
							REPORT_INTERVAL_START_TIME, 
							REPORT_INTERVAL_END_TIME, 
							REPORT_READINESS,
							REPORT_READINESS_UPDATED_AT,
							GROUP_NAME,
							MARKET_ID
						  )
						  VALUES
						  (
							vReportUserName,
							vReportEnvironment,
							vReportVendor,
							pSubscriptionId,
							vReportId,
							vReportName,
							vReportIntervalEndTime + INTERVAL 1 HOUR,
							vReportIntervalEndTime + INTERVAL 2 HOUR,
							'PENDING',
							NOW(),
							vGroupName2,
							vMarketId2
						  );					  
						  vrowcount = vrowcount + row_count();
						vOmAuditLog.sqlExecuted = 'No.of entries added for the next traffic_hour as PENDING ('||vrowcount||')';
						CALL writeAuditLogV2(vOmAuditLog);
					END IF;					
					/*!	6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
					IF ( vReportCurrentTrafficHourCheckStatus > 0 AND vReportNextTrafficHourCheckStatus > 0 ) THEN
						vSql='UPDATE /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							 SET REPORT_READINESS = ''READY_FOR_DELIVERY'',
								 REPORT_READINESS_TRIGGER = ''INTERVAL_IS_AVAILABLE'',
								 REPORT_READINESS_UPDATED_AT = NOW(6)
							WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||' 
							 AND REPORT_INTERVAL_END_TIME ='||QUOTE( vReportIntervalEndTime)||'  
							 AND REPORT_INTERVAL_START_TIME ='||QUOTE( vReportIntervalStartTime);
						
						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);    
						EXECUTE IMMEDIATE vSql;
						
						vrowcount = vrowcount + row_count();
						vOmAuditLog.sqlExecuted = 'current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING: ('||vrowcount||')';
						CALL writeAuditLogV2(vOmAuditLog);

						/*! - Add an entry for the next traffic_hour as READY_FOR_DELIVERY */
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						   ( USER_NAME,
							 ENVIRONMENT,
							 VENDOR,
							 SUBSCRIPTION_ID,
							 REPORT_ID,
							 REPORT_NAME,
							 REPORT_INTERVAL_START_TIME, 
							 REPORT_INTERVAL_END_TIME, 
							 REPORT_READINESS,
							 REPORT_READINESS_TRIGGER,
							 REPORT_READINESS_UPDATED_AT,
							 GROUP_NAME,
							 MARKET_ID
						   )
						VALUES
						   ( vReportUserName,
							 vReportEnvironment,
							 vReportVendor,
							 pSubscriptionId,
							 vReportId,
							 vReportName,
							 vReportIntervalEndTime,
							 vReportIntervalEndTime + INTERVAL 1 HOUR,
							 'READY_FOR_DELIVERY',
							 'INTERVAL_IS_AVAILABLE',
							 NOW(),
							 vGroupName2,
							 vMarketId2
							);

						/*! - Add an entry for the next traffic_hour as PENDING */
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						   ( USER_NAME,
							 ENVIRONMENT,
							 VENDOR,
							 SUBSCRIPTION_ID,
							 REPORT_ID,
							 REPORT_NAME,
							 REPORT_INTERVAL_START_TIME, 
							 REPORT_INTERVAL_END_TIME, 
							 REPORT_READINESS,
							 REPORT_READINESS_UPDATED_AT,
							 GROUP_NAME,
							 MARKET_ID
						   )
						VALUES
						   ( vReportUserName,
							 vReportEnvironment,
							 vReportVendor,
							 pSubscriptionId,
							 vReportId,
							 vReportName,
							 vReportIntervalEndTime + INTERVAL 1 HOUR,
							 vReportIntervalEndTime + INTERVAL 2 HOUR,
							 'PENDING',
							 NOW(),
							 vGroupName2,
							 vMarketId2
							);
						vrowcount = vrowcount + row_count();	
						vOmAuditLog.sqlExecuted = 'No.of next interval as READY_FOR_DELIVERY and insert new record as PENDING: ('||vrowcount||')';
						CALL writeAuditLogV2(vOmAuditLog);
					END IF;			
				/*! 6.2 - Current PENDING interval is not ready. No new intervals available (Next interval has not started loading yet). Sleep and retry. */
				/*! we update the Report readiness updated column to show we checked this report */		
				
				
				 /*! - Check to see if min(traffic_hour) > vReportIntervalStartTime + INTERVAL 1 HOUR */

				
				IF ( vReportCurrentTrafficHourCheckStatus = 0 and vReportNextTrafficHourCheckStatus = 0 )  THEN


					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */  EXISTS 
							(
								SELECT TRAFFIC_HOUR AS TRAFFIC_HOUR 
								FROM '||pDatabase||'.OM_DATA_INTERVALS 
								WHERE CURRENT_HOUR = ''Y'' 
								AND GROUP_NAME IN  '||vGroupName||' 
								AND MARKET_ID IN '||vMarketId||' 
								AND TRAFFIC_HOUR > '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
								GROUP BY TRAFFIC_HOUR 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								LIMIT 1
							)';
					vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null')  ;
					CALL writeAuditLogV2(vOmAuditLog);

				
					EXECUTE IMMEDIATE vSql into vReportIntervalFirstAvailableStartTimeCheckStatus;
				   
					IF vReportIntervalFirstAvailableStartTimeCheckStatus > 0 THEN 
										
						vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MIN(TRAFFIC_HOUR) AS TRAFFIC_HOUR 
								FROM
								(
								SELECT TRAFFIC_HOUR
								FROM '||pDatabase||'.OM_DATA_INTERVALS 
								WHERE CURRENT_HOUR = ''Y'' 
								 AND GROUP_NAME IN  '||vGroupName||' 
								 AND MARKET_ID IN '||vMarketId||' 
								 AND TRAFFIC_HOUR > '||QUOTE(vReportIntervalStartTime)||' + INTERVAL 1 HOUR
								GROUP BY TRAFFIC_HOUR 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								)'
								;
			
					
						vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null')  ;
						CALL writeAuditLogV2(vOmAuditLog);
			  
						EXECUTE IMMEDIATE vSql INTO vReportIntervalFirstAvailableStartTime;
						
							/*!  We now mark the intervals < vReportIntervalFirstAvailableStartTime as DATE_LOSS_DETECTED */
					
						vSql='UPDATE  /*! ValidateMarketHourlyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							SET REPORT_READINESS = ''DATA_LOSS_DETECTED'',
								 REPORT_READINESS_TRIGGER = ''INTERVAL_IS_NOT_AVAILABLE'',
								 REPORT_READINESS_UPDATED_AT = NOW(6)
							WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||' 
								  AND REPORT_INTERVAL_END_TIME ='||QUOTE( vReportIntervalEndTime)||'  
								  AND REPORT_INTERVAL_START_TIME ='||QUOTE( vReportIntervalStartTime);
						
						vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null')  ;
						CALL writeAuditLogV2(vOmAuditLog);
						EXECUTE IMMEDIATE vSql;
									
						vrowcount = vrowcount+row_count();						
						vOmAuditLog.sqlExecuted =  'No.of intervals updated as DATE_LOSS_DETECTED for current hour: ('||vrowcount||')'  ;
						CALL writeAuditLogV2(vOmAuditLog);
					
					
					
					
					
					
					
					

					
					
					
					
						
					
					
				
						/*! Insert all the missing intervals upto vReportIntervalFirstAvailableStartTime as DATA_LOSS_DETECTED */			
				
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						(
						  USER_NAME,
						  ENVIRONMENT,
						  VENDOR,
						  SUBSCRIPTION_ID,
						  REPORT_ID,
						  REPORT_NAME,
						  REPORT_INTERVAL_START_TIME, 
						  REPORT_INTERVAL_END_TIME, 
						  REPORT_READINESS,
						  REPORT_READINESS_TRIGGER,
						  REPORT_READINESS_UPDATED_AT,
						  GROUP_NAME,
						  MARKET_ID
						)
						SELECT 
						  vReportUserName,
						  vReportEnvironment,
						  vReportVendor,
						  pSubscriptionId,
						  vReportId,
						  vReportName,
						  TABLE_COL,
						  TABLE_COL + INTERVAL 1 HOUR,
						  'DATA_LOSS_DETECTED',
						  'INTERVAL_IS_NOT_AVAILABLE',
						  NOW(),
						  vGroupName2,
						  vMarketId2
						  FROM 
						  TABLE(getTimeBuckets(vReportIntervalFirstAvailableStartTime,3,'INTERVAL_HOURLY'))
						  WHERE 
						  TABLE_COL >= vReportIntervalStartTime + INTERVAL 1 HOUR ;					
						
						vrowcount = vrowcount + row_count();		
						vOmAuditLog.sqlExecuted =  'Insert all the missing intervals upto vReportIntervalFirstAvailableStartTime as DATA_LOSS_DETECTED'  ;
						CALL writeAuditLogV2(vOmAuditLog);
				
						/*! - Add an entry for the vReportIntervalFirstAvailableStartTime  as available */
							
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						   ( USER_NAME,
							 ENVIRONMENT,
							 VENDOR,
							 SUBSCRIPTION_ID,
							 REPORT_ID,
							 REPORT_NAME,
							 REPORT_INTERVAL_START_TIME, 
							 REPORT_INTERVAL_END_TIME, 
							 REPORT_READINESS,
							 REPORT_READINESS_TRIGGER,
							 REPORT_READINESS_UPDATED_AT,
							 GROUP_NAME,
							 MARKET_ID
						   )
						VALUES
						  ( vReportUserName,
							vReportEnvironment,
							vReportVendor,
							pSubscriptionId,
							vReportId,
							vReportName,
							vReportIntervalFirstAvailableStartTime,
							vReportIntervalFirstAvailableStartTime + INTERVAL 1 HOUR,
							'READY_FOR_DELIVERY',
							'INTERVAL_IS_AVAILABLE',
							NOW(6),
							vGroupName2,
							vMarketId2
						  );
						  
						vrowcount = vrowcount + row_count();
						vOmAuditLog.sqlExecuted =  'Adding an entry for the vReportIntervalFirstAvailableStartTime as available ('||vrowcount||')'  ;
						CALL writeAuditLogV2(vOmAuditLog);
					
						/*! - Add an entry for the next traffic_hour as pending */
							
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						   ( USER_NAME,
							 ENVIRONMENT,
							 VENDOR,
							 SUBSCRIPTION_ID,
							 REPORT_ID,
							 REPORT_NAME,
							 REPORT_INTERVAL_START_TIME, 
							 REPORT_INTERVAL_END_TIME, 
							 REPORT_READINESS,
							 REPORT_READINESS_UPDATED_AT,
							 GROUP_NAME,
							 MARKET_ID
						   )
						VALUES
						  ( vReportUserName,
							vReportEnvironment,
							vReportVendor,
							pSubscriptionId,
							vReportId,
							vReportName,
							vReportIntervalFirstAvailableStartTime + INTERVAL 1 HOUR,
							vReportIntervalFirstAvailableStartTime + INTERVAL 2 HOUR,
							'PENDING',
							NOW(6),
							vGroupName2,
							vMarketId2
						  );					  
						vrowcount = vrowcount + row_count();
						vOmAuditLog.sqlExecuted =  'Adding an entry for the next traffic_hour as pending ('||vrowcount||')'  ;
						CALL writeAuditLogV2(vOmAuditLog);
					
					/*! vReportIntervalFirstAvailableStartTimeCheckStatus = 0 */
						
					ELSE
					
						ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
											
						INSERT  /*! ValidateMarketHourlyReportReadiness */ 
						INTO APP_ACTIVITIES_LOG 
						  ( APP_NAME,
							BATCH_ID,
							ACTIVITY_TYPE,
							ACTIVITY_DETAILS,
							ACTIVITY_OUTPUT,
							ACTIVITY_ERROR_MSG,
							ACTIVITY_START_TS,
							ACTIVITY_END_TS,
							ACTIVITY_STATUS) 
						VALUES 
						 ( vOmAuditLog.spName,
						   vSessionIdentifier,
						   'Executing Procedure',
						   'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
						   NULL,
						   'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId,
						   vActivityStartTime,
						   NOW(6),
						   'EXCEPTION'); 	 
						COMMIT;
						RETURN;					
					END IF;
			END IF;
		END IF;
		
			IF (vReportCheckStatus = 0 AND pDataLossIsTrue = 0) THEN
				/*!	6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available traffic_hour to create the first entry
				/*! - We see if there is any traffic hour that matches the condition within the last vLookBackHours hours from UTC */
				IF pLookBackHours IS NULL THEN
					SELECT /*! ValidateMarketHourlyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_HOURS' 
					INTO vLookBackHours;
					
				ELSE 
					vLookBackHours = pLookBackHours;
				END IF;

				vOmAuditLog.sqlExecuted = 'Lookback hours :'||vLookBackHours;
				CALL writeAuditLogV2(vOmAuditLog);

				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
		
				vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
				CALL writeAuditLogV2(vOmAuditLog);
						
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
					
				/*! - If there is an available traffic_hour - we pickup the max traffic hour that matches the conditions */
						
				IF vReportCurrentTrafficHourCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MAX(TRAFFIC_HOUR) AS TRAFFIC_HOUR
							FROM 
							(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
				
					vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
					CALL writeAuditLogV2(vOmAuditLog);
								
					
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartTime;
			
					/*! - Add an entry for this traffic_hour as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
						)
					VALUES
					   ( 
						 vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartTime,
						 vReportIntervalStartTime + INTERVAL 1 HOUR,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);
		
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next traffic_hour as pending */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					  INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   SUBSCRIPTION_ID,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_INTERVAL_START_TIME, 
						   REPORT_INTERVAL_END_TIME, 
						   REPORT_READINESS,
						   REPORT_READINESS_UPDATED_AT,
						   GROUP_NAME,
						   MARKET_ID
						 )
					VALUES
						( vReportUserName,
						  vReportEnvironment,
						  vReportVendor,
						  pSubscriptionId,
						  vReportId,
						  vReportName,
						  vReportIntervalStartTime + INTERVAL 1 HOUR,
						  vReportIntervalStartTime + INTERVAL 2 HOUR,
						  'PENDING',
						  NOW(6),
						  vGroupName2,
						  vMarketId2
						);
					
					vrowcount = vrowcount + row_count();
								
				ELSIF vReportCurrentTrafficHourCheckStatus = 0 THEN
				
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;			
			END IF;
					
			IF (pDataLossIsTrue > 0) THEN
				/*! 6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest traffic_hour. Same logic as new entry */
				/*! - All other conditions are negated */
				/*! - We see if there is any traffic hour that matches the condition within the last vLookBackHours hours from UTC */
				IF pLookBackHours IS NULL THEN
					SELECT /*! ValidateMarketHourlyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_HOURS' 
					INTO vLookBackHours;
				ELSE 
					vLookBackHours = pLookBackHours;
				END IF;
						
				vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
						(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
					
				vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
				CALL writeAuditLogV2(vOmAuditLog);
					
				EXECUTE IMMEDIATE vSql INTO vReportCurrentTrafficHourCheckStatus;
					
				/*! - If there is an available traffic_hour - we pickup the max traffic hour that matches the conditions */
				IF vReportCurrentTrafficHourCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketHourlyReportReadiness */ MAX(TRAFFIC_HOUR) AS TRAFFIC_HOUR 
							FROM 
							(
							SELECT TRAFFIC_HOUR 
							FROM '||pDatabase||'.OM_DATA_INTERVALS 
							WHERE CURRENT_HOUR = ''Y'' 
							AND GROUP_NAME IN  '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND TRAFFIC_HOUR >= NOW() - INTERVAL '||vLookBackHours||' HOUR
							GROUP BY TRAFFIC_HOUR 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';

					vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
					CALL writeAuditLogV2(vOmAuditLog);
						  
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartTime;
			
					/*! - Delete entries if any exists for this Report that is for the above traffic_hour */
					vSql='DELETE /*! ValidateMarketHourlyReportReadiness */ 
							FROM USER_REPORTS_SUBSCRIPTION_STATUS
							WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||'
							AND REPORT_INTERVAL_START_TIME = '||QUOTE(vReportIntervalStartTime)||' 
							AND REPORT_INTERVAL_END_TIME = '||QUOTE(vReportIntervalStartTime)'+ INTERVAL 1 HOUR';
					 
					 vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
					CALL writeAuditLogV2(vOmAuditLog);
					 EXECUTE IMMEDIATE vSql;
							
					/*! - Delete entries if any exists for this Report that is marked as PENDING */
					vSql='DELETE /*! ValidateMarketHourlyReportReadiness */ 
							FROM USER_REPORTS_SUBSCRIPTION_STATUS
							WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'  
							 AND REPORT_READINESS = ''PENDING''';
							 
					vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
					CALL writeAuditLogV2(vOmAuditLog);
					EXECUTE IMMEDIATE vSql;
																	
					/*! - Add an entry for this traffic_hour as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartTime,
						 vReportIntervalStartTime + INTERVAL 1 HOUR,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);			
					vrowcount = vrowcount + row_count();
					/*! - Add an entry for the next traffic_hour as pending */
						
					INSERT  /*! ValidateMarketHourlyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					  ( vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalStartTime + INTERVAL 1 HOUR,
						vReportIntervalStartTime + INTERVAL 2 HOUR,
						'PENDING',
						NOW(6),
						vGroupName2,
						vMarketId2
					  );
				
					vrowcount = vrowcount + row_count();
				ELSIF vReportCurrentTrafficHourCheckStatus = 0 THEN
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO TRAFFIC_HOURs available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;					
			END IF;
			/*! Release the transaction lock on the Report */
			COMMIT;
		ELSE 
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Subscription -'||pSubscriptionId||' is not enabled AND/OR is not an Hourly report' AS REASON FROM DUAL;
		END IF;
END IF; 

/*! Final insert to track procedure execution metrics */

	INSERT  /*! ValidateMarketHourlyReportReadiness */ 
		INTO APP_ACTIVITIES_LOG 
	      ( APP_NAME,
	        BATCH_ID,
	        ACTIVITY_TYPE,
	        ACTIVITY_DETAILS,
	        ACTIVITY_OUTPUT,
	        ACTIVITY_ERROR_MSG,
	        ACTIVITY_START_TS,
	        ACTIVITY_END_TS,
	        ACTIVITY_STATUS) 
	 VALUES 
		 ( vOmAuditLog.spName,
	       vSessionIdentifier,
	       'Executing Procedure',
	       'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
	       'Rows inserted/updated in USER_REPORTS_SUBSCRIPTION_STATUS: '||vrowcount,
	       NULL,
	       vActivityStartTime,
	       NOW(6),
	       'COMPLETE'); 	 
  COMMIT;

  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'COMPLETE' AS STATUS, 'Rows inserted/updated in USER_REPORTS_SUBSCRIPTION_STATUS: '||vrowcount AS REASON FROM DUAL;

EXCEPTION
	 WHEN OTHERS THEN
	 ROLLBACK;
     IF vAppLogLevel = 'ERROR' THEN
		INSERT  /*! ValidateMarketHourlyReportReadiness */ 
		  INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
    	       'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
			  NULL,
			  exception_message(),
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );
        
	END IF;
	IF vAppLogLevel = 'DEBUG' THEN
         vOmAuditLog.errorMsg = exception_message();
         vOmAuditLog.sqlExecuted =  'Found Exception ';
         CALL writeAuditLogV2(vOmAuditLog);
	END IF;
	COMMIT;
	ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, exception_message() AS REASON FROM DUAL;
	RAISE;
END;
//
DELIMITER ;

