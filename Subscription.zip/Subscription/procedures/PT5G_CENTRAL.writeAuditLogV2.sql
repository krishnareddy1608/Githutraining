/*
Database : PT5G_CENTRAL
Procedure: writeAuditLogV2
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `writeAuditLogV2`(pOmAuditLog record(`spName` varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NULL, `sqlExecuted` text CHARACTER SET utf8 COLLATE utf8_bin NULL, `sqlVariables` text CHARACTER SET utf8 COLLATE utf8_bin NULL, `logTime` datetime NULL, `errorCode` int(11) NULL, `errorMsg` text CHARACTER SET utf8 COLLATE utf8_bin NULL)) RETURNS void AS
DECLARE

 /*!
  PROCEDURE NAME       : writeAuditLogV2
  DATE CREATED         : Mar 3, 2023
  MODIFY DATE          : 
  VERSION              : V1
  MODIFIED BY           : Krishna
  PROCEDURE DESCRIPTION : This procedure writes debug information to OM_AUDIT_LOG. As to what constitutes Debug, obviously dictated by the procedure itself. 
: The procedure does not have an implicit commit as it maybe called from within a transaction in the parent procedure. Not having explicit commits can cause issues sometimes. 
 */  
 
spName2 varchar(256) CHARACTER SET utf8 COLLATE utf8_bin ;
    sqlExecuted2 TEXT  CHARACTER SET utf8 COLLATE utf8_bin;
    sqlVariables2 TEXT CHARACTER SET utf8 COLLATE utf8_bin ;
    logTime2 datetime(6);
    errorCode2 int;
    errorMsg2 TEXT CHARACTER SET utf8 COLLATE utf8_bin ;
    varBatchId bigint = 0;
    qryId QUERY(a bigint) ;
    vKeyValue varchar(300) CHARACTER SET utf8 COLLATE utf8_bin ;
    doWrite bool = false;
  
BEGIN

spName2 = pOmAuditLog.spName;
sqlExecuted2 =pOmAuditLog.sqlExecuted;
sqlVariables2 = pOmAuditLog.sqlVariables;
logTime2 = nvl(pOmAuditLog.logTime, now(6));
errorCode2 = pOmAuditLog.errorCode;
errorMsg2 = pOmAuditLog.errorMsg ;

    SELECT CONNECTION_ID() 
FROM DUAL 
INTO varBatchId;

    
    INSERT /*!writeAuditLog*/ INTO OM_AUDIT_LOG(
PK_ID, 
SP_NAME ,
SQL_EXECUTED ,
SQL_VARIABLES ,
LOG_TIME ,
ERROR_CODE ,
ERROR_MSG, 
BATCH_ID
) 
    VALUES (
null, 
spName2 ,
sqlExecuted2 ,
sqlVariables2 ,
logTime2 ,
errorCode2 ,
errorMsg2, 
varBatchId
);

EXCEPTION
WHEN OTHERS THEN
RAISE;

END;
//
DELIMITER ;

