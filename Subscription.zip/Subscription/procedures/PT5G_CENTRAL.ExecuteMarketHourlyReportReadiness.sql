/*
Database : PT5G_CENTRAL
Procedure: ExecuteMarketHourlyReportReadiness
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `ExecuteMarketHourlyReportReadiness`(pDatabase varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pReportName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pLookBackHours int(11) NULL DEFAULT NULL, pDataLossIsTrue tinyint(1) NULL DEFAULT NULL) RETURNS void AS
DECLARE

/*!
	PROCEDURE NAME      	: ExecuteMarketHourlyReportReadiness
	DATE CREATED        	: Dec 22 2023
	AUTHOR			   		: 
	PROCEDURE DESC	   		: User Report Subscription - NTSCA-26827
								Example invocation - CALL ExecuteMarketHourlyReportReadiness('PT5G','E_Ethernet_KPIs_sah',NULL,0);
								The procedure will do the following.
								1. Lookup SUBSCRIPTION_ID from REPORT table for a given REPORT_NAME.
								2. Calling ValidateMarketHourlyReportReadiness procedure for each SUBSCRIPTION_ID associated with REPORT_NAME.				    
	VERSION              	: V1
	MODIFICATION HISTORY 	:   
*/  

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
	                    sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						logTime DATETIME,errorCode INT,
						errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin
						) 
						  = ROW( NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL);	

	vActiveReport  INT;
	vSql TEXT; 
	vrowcount BIGINT DEFAULT 0;
	qrySubscriptionId QUERY(SubscriptionId VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL);
  
	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);  

BEGIN
    vOmAuditLog.spName = 'ExecuteMarketHourlyReportReadiness';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';	
	
    vOmAuditLog.sqlVariables =  pDatabase||','||pReportName||','||pLookBackHours||','||pDataLossIsTrue;	
    vOmAuditLog.sqlExecuted =  'Starting processing with params ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')';
    	  
    SELECT /*! ExecuteMarketHourlyReportReadiness */ NOW(6) INTO vActivityStartTime;
    SELECT /*! ExecuteMarketHourlyReportReadiness */ UUID() INTO vSessionIdentifier;
  
    SELECT /*! ExecuteMarketHourlyReportReadiness */  IFNULL(ANY_VALUE(KEY_VALUE),'DEBUG') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;	
 	
IF vAppLogLevel = 'ERROR' THEN
	
   /*! Check to see if the report exists in USER_REPORTS_SUBSCRIPTION */

	SELECT /*! ExecuteMarketHourlyReportReadiness */ EXISTS (SELECT /*! ExecuteMarketHourlyReportReadiness */ 1 
															FROM USER_REPORTS_SUBSCRIPTION 
															WHERE
															REPORT_NAME = pReportName 
															AND REPORT_TYPE = 'Hourly Totals'
															AND IS_ENABLED = 'Y' 
															LIMIT 1
															) INTO vActiveReport;


    IF vActiveReport = 1 THEN	   
		  /*! Looping through each SubscriptionId for the Input Report Name and calling  ValidateMarketHourlyReportReadiness 	 */
		vSql='SELECT /*! ExecuteMarketHourlyReportReadiness */ SUBSCRIPTION_ID 
			  FROM USER_REPORTS_SUBSCRIPTION 
			  WHERE REPORT_NAME  = '|| QUOTE(pReportName)||' 
			  AND IS_ENABLED = ''Y'' ';
			  
		qrySubscriptionId = TO_QUERY(vSql);
  
		FOR x IN COLLECT(qrySubscriptionId) LOOP
			CALL ValidateMarketHourlyReportReadiness(pDatabase,x.SubscriptionId,pLookBackHours,pDataLossIsTrue);
			vrowcount = vrowcount + 1;
		END LOOP;
	  
	ELSE 
		INSERT  /*! ExecuteMarketHourlyReportReadiness */ 
		  INTO APP_ACTIVITIES_LOG 
			 ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
			  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
			  NULL,
			  'Report does not exist or is not enabled',
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );
			  
		ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Report does not exist or is not enabled' AS REASON FROM DUAL;
		
		RETURN;
    END IF;	  	 	  
END IF;	    
		
IF vAppLogLevel = 'DEBUG' THEN

	CALL writeAuditLogV2(vOmAuditLog);

	/*! Check if the Input report/Username is exists or not*/
	/*! Check to see if the report exists in USER_REPORTS_SUBSCRIPTION */

	vSql ='SELECT /*! ExecuteMarketHourlyReportReadiness */ EXISTS (SELECT /*! ExecuteMarketHourlyReportReadiness */ 1 
																	FROM USER_REPORTS_SUBSCRIPTION 
																	WHERE
																	REPORT_NAME = '||QUOTE(pReportName)||' 
																	AND REPORT_TYPE = ''Hourly Totals''
																	AND IS_ENABLED = ''Y''
																	LIMIT 1
																	)';					
	vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
	CALL writeAuditLogV2(vOmAuditLog);
					
	EXECUTE IMMEDIATE vSql INTO vActiveReport;
			
    vOmAuditLog.sqlExecuted =  'Checking to see if report is available in USER_REPORTS_SUBSCRIPTION - 1 indicates report present '||vActiveReport ;
    CALL writeAuditLogV2(vOmAuditLog);	   

    IF vActiveReport = 1 THEN	   
		  /*! Looping through each SubscriptionId for the Input Report Name and calling  ValidateMarketHourlyReportReadiness 	 */
		  
  		vSql='SELECT /*! ExecuteMarketHourlyReportReadiness */ SUBSCRIPTION_ID 
			 FROM USER_REPORTS_SUBSCRIPTION 
			 WHERE REPORT_NAME  = '|| QUOTE(pReportName)||' 
			 AND IS_ENABLED = ''Y'' ';
													 		  		
		vOmAuditLog.sqlExecuted = IFNULL(vSql,'Got NULL'); 
		CALL writeAuditLogV2(vOmAuditLog);
		
		qrySubscriptionId = TO_QUERY(vSql);	
		
		FOR x IN COLLECT(qrySubscriptionId) LOOP
			
			CALL ValidateMarketHourlyReportReadiness(pDatabase,x.SubscriptionId,pLookBackHours,pDataLossIsTrue);
			vrowcount = vrowcount + 1;
			
			vOmAuditLog.sqlExecuted = 'ValidateMarketHourlyReportReadiness executed for Report- ('||pReportName||')';
			CALL writeAuditLogV2(vOmAuditLog);
		END LOOP;						  
	ELSE 
	    vOmAuditLog.sqlExecuted =  'Report does not exist or is not enabled';
		CALL writeAuditLogV2(vOmAuditLog);
		
    	ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Report does not exist or is not enabled' AS REASON FROM DUAL;
		
		RETURN;		
    END IF;	  	 	  
END IF;
	
     /*! Final insert to track procedure execution metrics */	 
	    INSERT  /*! ExecuteMarketHourlyReportReadiness */ 
	      INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
	     VALUES 
		    ( vOmAuditLog.spName,
		     vSessionIdentifier,
		     'Executing Procedure',
       	      'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
		     'ValidateMarketHourlyReportReadiness executed ('||vrowcount||') times for ('||pReportName||')',
		     NULL,
		     vActivityStartTime,
		     now(6),
		     'COMPLETE');
			         	 
    COMMIT;
	
	ECHO SELECT vOmAuditLog.spName AS APP_NAME,  'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'COMPLETE' AS STATUS, 'ValidateMarketHourlyReportReadiness executed ('||vrowcount||') times for ('||pReportName||')' AS REASON FROM DUAL;
	  	   
	EXCEPTION
		WHEN OTHERS THEN
		ROLLBACK;
		IF vAppLogLevel = 'ERROR' THEN
			INSERT  /*! ExecuteMarketHourlyReportReadiness */ 
			  INTO APP_ACTIVITIES_LOG 
				 ( APP_NAME,
				   BATCH_ID,
				   ACTIVITY_TYPE,
				   ACTIVITY_DETAILS,
				   ACTIVITY_OUTPUT,
				   ACTIVITY_ERROR_MSG,
				   ACTIVITY_START_TS,
				   ACTIVITY_END_TS,
				   ACTIVITY_STATUS) 
			VALUES 
				( vOmAuditLog.spName,
				  vSessionIdentifier,
				  'Executing Procedure',
				  'Procedure Arguments: ('||QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
				  NULL,
				  exception_message(),
				  vActivityStartTime,
				  NOW(6),
				  'EXCEPTION' );
        
		END IF;
		IF vAppLogLevel = 'DEBUG' THEN
			vOmAuditLog.sqlExecuted =  'Found Exception ';
			vOmAuditLog.errorMsg = exception_message();
			CALL writeAuditLogV2(vOmAuditLog);
		END IF;
	COMMIT;      
	 
	ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pDatabase) ||','||QUOTE(pReportName)||','||IFNULL(pLookBackHours,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, exception_message() AS REASON FROM DUAL;	 
RAISE;
END;
//
DELIMITER ;

