/*
Database : PT5G_CENTRAL
Procedure: RevalidateMarketUserReportsSubscription
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `RevalidateMarketUserReportsSubscription`(pReportName varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pUserName text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL) RETURNS void AS
  DECLARE

/*!
	PROCEDURE NAME       : RevalidateMarketUserReportsSubscription
	DATE CREATED         : Nov 20, 2024
	AUTHOR			   	 : Krishna M
	PROCEDURE DESC	   	 : User Report Subscription - NTSCA-30577
						 : Example invocation - call RevalidateMarketUserReportsSubscription('E_Ethernet_KPIs_sah','krishna');
							The procedure will do the following.
							2. Check to see if this report already exists in the USER_REPORTS_SUBSCRIPTION table.
								2.1 - If exists, then continue
								2.2 - If not exists, exit
							3. Retrive groups for the report and compare with existing entries in USER_REPORTS_SUBSCRIPTION table 	
								3.1 - checking for each individual market
								3.2 - Checking for active groups for the Report for the specific market
									3.2.1 - Update the USER_REPORTS_SUBSCRIPTION table with updated list
									3.2.2 - If not exists, then exit with ERROR
	VERSION              : V1
	MODIFICATION HISTORY : 

*/  

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
	                    sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						sqlVariables TEXT CHARACTER SET utf8 COLLATE    utf8_bin ,
						logTime DATETIME,errorCode INT,
						errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin
						) 
						 = ROW( NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL,
								 NULL);	

	vReportCount  INT;
	vSql TEXT; 	  
	vReportUrl TEXT;
	vrowcount BIGINT DEFAULT 0;
	vTemplateID BIGINT;
	
	vActiveGroup LONGTEXT;
	vActiveGroup2 LONGTEXT;
	vVendorDatabase VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vCheckReportSubscriptionStatus INT;

	vMarketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin;
	vMarketIdList LONGTEXT DEFAULT '';
	qryCheckActiveGroups QUERY( ActiveGroup LONGTEXT);

	qryMarketId QUERY(marketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin);
	recMarketId ARRAY(RECORD(marketId VARCHAR(3) CHARACTER SET utf8 COLLATE utf8_bin));
  
	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);  
	vGroupValidationLookbackDays INT; 
    vSubscriptionId VARCHAR(25) CHARACTER SET utf8 COLLATE utf8_bin;
  
BEGIN
    vOmAuditLog.spName = 'RevalidateMarketUserReportsSubscription';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';	
	
    vOmAuditLog.sqlVariables =  pReportName||','||pUserName;	
    vOmAuditLog.sqlExecuted =  'Starting processing with params ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')';
    	  
    SELECT /*! RevalidateMarketUserReportsSubscription */ NOW(6) INTO vActivityStartTime;
    SELECT /*! RevalidateMarketUserReportsSubscription */ UUID() INTO vSessionIdentifier;
  
    SELECT /*! RevalidateMarketUserReportsSubscription */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;	
 	
	SELECT /*! RevalidateMarketUserReportsSubscription */  KEY_VALUE 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'VENDOR_DATABASE' 
	INTO vVendorDatabase;	
 	
	SELECT /*! RevalidateMarketUserReportsSubscription */ KEY_VALUE 
	FROM
	APP_CONFIG
	WHERE APP_NAME = vOmAuditLog.spName
	AND APP_KEY = 'EXISTING_SUBSCRIPTION_GROUP_VALIDATION_LOOKBACK_DAYS'
	INTO vGroupValidationLookbackDays;
	
 IF vAppLogLevel = 'ERROR' THEN	
	   
	   /*! Check if the Input report/Username is exists or not*/
	vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ EXISTS  
					( SELECT 1 
						FROM REPORT R
						WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
						AND R.USER_NAME = '||QUOTE(pUserName) ||'
					)';
			
	EXECUTE IMMEDIATE vSql INTO vReportCount;

	IF vReportCount > 0 THEN	   

	/*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
		SELECT /*! RevalidateMarketUserReportsSubscription */ EXISTS 
					( 
						SELECT 1 
						FROM USER_REPORTS_SUBSCRIPTION
						WHERE REPORT_NAME = pReportName
						LIMIT 1
					) INTO vCheckReportSubscriptionStatus;
	
		IF vCheckReportSubscriptionStatus = 0 THEN 
		
			INSERT  /*! RevalidateMarketUserReportsSubscription */ 
			INTO APP_ACTIVITIES_LOG 
			 ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
			VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
			  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
			  NULL,
			  'Entries for '||pReportName||' do not exist in USER_REPORTS_SUBSCRIPTION',
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );

			ECHO SELECT 
						vOmAuditLog.spName AS APP_NAME, 
						'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS,
						'EXCEPTION' AS STATUS, 
						'Entries for '||pReportName||' do not exist in USER_REPORTS_SUBSCRIPTION' AS REASON 
				FROM 
						DUAL;
			
			RETURN;	  
		END IF;

		/*! Check for active groups for the new Report for all markets   */    		
		
		vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ TEMPLATE_ID 
				  FROM TEMPLATE 
				  JOIN REPORT ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
							AND USER_NAME  = '||QUOTE(pUserName) ||'
							AND REPORT_NAME = '||QUOTE(pReportName);
							
		EXECUTE IMMEDIATE vSql into vTemplateID;
		
		vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ 
						GROUP_CONCAT(DISTINCT QUOTE(GROUP_NAME) SEPARATOR '','') GROUP_NM
				FROM
				(
				  SELECT FD.GROUP_NAME 
				 FROM 
						FORMULA F,
						FORMULA_DETAIL FD				
				WHERE 
						F.FORMULA_ID = FD.FORMULA_ID
												AND F.FORMULA_ID IN (SELECT 
													CAST(FD.OM_NAME AS unsigned)
												FROM 
													FORMULA F,
													FORMULA_DETAIL FD
												WHERE 
													F.FORMULA_ID = FD.FORMULA_ID
													AND F.FORMULA_ID IN (SELECT 
																				FORMULA_ID
																		FROM 
																				TEMPLATE_FORMULA H
																		WHERE 
																				H.TEMPLATE_ID = '||vTemplateID||'
																		)
												AND FD.GROUP_NAME = ''FORMULA''									   
											)
						AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
						AND FD.GROUP_NAME IS NOT NULL
				UNION 
				SELECT /*! RevalidateMarketUserReportsSubscription */  
						GROUP_NAME 
				FROM FORMULA_DETAIL FD  
				WHERE  
				FORMULA_ID IN (
					SELECT FORMULA_ID FROM TEMPLATE_FORMULA H 
					WHERE H.TEMPLATE_ID = '||vTemplateID||')
					AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
				)';

		qryCheckActiveGroups  = TO_QUERY(vSql);   
		vActiveGroup2 = SCALAR(qryCheckActiveGroups);

		IF vActiveGroup2 IS NULL THEN 
			 
			INSERT  /*! RevalidateMarketUserReportsSubscription */ 
			  INTO APP_ACTIVITIES_LOG 
				 ( APP_NAME,
				   BATCH_ID,
				   ACTIVITY_TYPE,
				   ACTIVITY_DETAILS,
				   ACTIVITY_OUTPUT,
				   ACTIVITY_ERROR_MSG,
				   ACTIVITY_START_TS,
				   ACTIVITY_END_TS,
				   ACTIVITY_STATUS) 
			VALUES 
				( vOmAuditLog.spName,
				  vSessionIdentifier,
				  'Executing Procedure',
				  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
				  NULL,
				  'Unable to determine active GROUPS for the Report '||pReportName||'. Unable to update GROUP List' ,
				  vActivityStartTime,
				  NOW(6),
				  'EXCEPTION' );
	  
			ECHO SELECT 
						vOmAuditLog.spName AS APP_NAME, 
						'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 
						'EXCEPTION' AS STATUS,  
						'Unable to determine active GROUPS for Report '||pReportName AS REASON
				FROM 
						DUAL;
			
		  RETURN;	  
		END IF;

		/*! Now to check for each individual market */
	
		vSql = 'SELECT 
					DISTINCT MARKET_ID 
				FROM 
					USER_REPORTS_SUBSCRIPTION
				WHERE 
					REPORT_NAME = '||QUOTE(pReportName)||
				'   AND USER_NAME = '||QUOTE(pUserName);

		qryMarketId = TO_QUERY(vSql);
		recMarketId = COLLECT(qryMarketId);
	
		vMarketIdList  = '';
	
		FOR x IN 0 .. LENGTH(recMarketId) - 1 LOOP
	
			vMarketId = recMarketId[x].marketId;
		
			/*! Check for active groups for the new Report for the specific market  */ 

			vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ 
							GROUP_CONCAT(DISTINCT GROUP_NAME SEPARATOR '','') GROUP_NM
				 FROM 
							'||vVendorDatabase||'.OM_DATA_INTERVALS ODI						
				WHERE 
						ODI.GROUP_NAME IN ('||vActiveGroup2||')
						AND ODI.TRAFFIC_HOUR >= NOW() - INTERVAL '||vGroupValidationLookbackDays||' DAY 
						AND ODI.MARKET_ID = '||QUOTE(vMarketId);

			qryCheckActiveGroups  = TO_QUERY(vSql);
			vActiveGroup = SCALAR(qryCheckActiveGroups);
	
			/*! Identify the specific Subscription ID for the report */
	
			SELECT 
					SUBSCRIPTION_ID 
			FROM
					USER_REPORTS_SUBSCRIPTION
			WHERE 
					REPORT_NAME = pReportName
					AND USER_NAME = pUserName
					AND MARKET_ID = vMarketId
			INTO
					vSubscriptionId;			
			
			IF vActiveGroup IS NOT NULL THEN	

				vSql = 'UPDATE  /*! RevalidateMarketUserReportsSubscription */ USER_REPORTS_SUBSCRIPTION 
						SET 
							GROUP_NAME = '||QUOTE(vMarketId)||'
						WHERE 
							SUBSCRIPTION_ID = '||QUOTE(vSubscriptionId);
				
				EXECUTE IMMEDIATE vSql;
				vrowcount = row_count() + vrowcount;
				vMarketIdList = vMarketId||','||vMarketIdList;					
			ELSE 	    
				INSERT  /*! RevalidateMarketUserReportsSubscription */ 
				  INTO APP_ACTIVITIES_LOG 
					 ( APP_NAME,
					   BATCH_ID,
					   ACTIVITY_TYPE,
					   ACTIVITY_DETAILS,
					   ACTIVITY_OUTPUT,
					   ACTIVITY_ERROR_MSG,
					   ACTIVITY_START_TS,
					   ACTIVITY_END_TS,
					   ACTIVITY_STATUS) 
				VALUES 
					( vOmAuditLog.spName,
					  vSessionIdentifier,
					  'Executing Procedure',
					  'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
					  NULL,
					  'Unable to determine active GROUPS in Market '||QUOTE(vMarketId)||' for the Report '||pReportName||'. Not updating groups ' ,
					  vActivityStartTime,
					  NOW(6),
					  'EXCEPTION' );
	  
				ECHO SELECT 
							vOmAuditLog.spName AS APP_NAME, 
							'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 
							'Unable to determine active GROUPS in Market '||QUOTE(vMarketId)||' for Report '||pReportName AS REASON 
					FROM 
							DUAL;	   
			END IF;  
		END LOOP;
	ELSE 
	  	INSERT  /*! RevalidateMarketUserReportsSubscription */ 
		  INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
      	      'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
			  NULL,
			  'Report/User does not exist',
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );
			  
		ECHO SELECT 
					vOmAuditLog.spName AS APP_NAME, 
					'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 
					'EXCEPTION' AS STATUS, 'Report/User does not exist' AS REASON 
			FROM 
					DUAL;

		RETURN;
    END IF; 
 END IF;	
  
 IF vAppLogLevel = 'DEBUG' THEN	

	CALL writeAuditLogV2(vOmAuditLog); 

	   /*! Check if the Input report/Username is exists or not*/
	vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ EXISTS  
					( SELECT 1 
						FROM REPORT R
						WHERE R.REPORT_NAME = '||QUOTE(pReportName) ||' 
						AND R.USER_NAME = '||QUOTE(pUserName) ||'
					)';
	
	vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
	CALL writeAuditLogV2(vOmAuditLog);
	
	EXECUTE IMMEDIATE vSql INTO vReportCount;
	
	IF vReportCount > 0 THEN	   

	/*! Check if report is already present in USER_REPORTS_SUBSCRIPTION */
	
		vSql= 'SELECT /*! RevalidateMarketUserReportsSubscription */ EXISTS 
					( 
						SELECT 1 
						FROM USER_REPORTS_SUBSCRIPTION
						WHERE REPORT_NAME ='||QUOTE(pReportName)||'
						LIMIT 1
					) ';
		
		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);
	
		EXECUTE IMMEDIATE vSql INTO vCheckReportSubscriptionStatus;
		
		IF vCheckReportSubscriptionStatus = 0 THEN 
		
			vOmAuditLog.sqlExecuted =  'Entries for '||pReportName||' do not exist in USER_REPORTS_SUBSCRIPTION' ;
			CALL writeAuditLogV2(vOmAuditLog);		   

			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS,'EXCEPTION' AS STATUS, 'Entries for '||pReportName||' do not exist in USER_REPORTS_SUBSCRIPTION' AS REASON FROM DUAL;
			
			RETURN;
		END IF;
		
		/*! Check for active groups for the new Report for all markets   */    		
		
		vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ TEMPLATE_ID 
				  FROM TEMPLATE 
				  JOIN REPORT ON TEMPLATE.REPORT_ID = REPORT.REPORT_ID 
							AND USER_NAME  = '||QUOTE(pUserName) ||'
							AND REPORT_NAME = '||QUOTE(pReportName);
		
		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);
		
		EXECUTE IMMEDIATE vSql INTO vTemplateID;
		
		vOmAuditLog.sqlExecuted = 'Template ID-'|| vTemplateID ;
		CALL writeAuditLogV2(vOmAuditLog);
		
		vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ 
						GROUP_CONCAT(DISTINCT QUOTE(GROUP_NAME) SEPARATOR '','') GROUP_NM
				FROM
				(
				  SELECT FD.GROUP_NAME 
				 FROM 
						FORMULA F,
						FORMULA_DETAIL FD				
				WHERE 
						F.FORMULA_ID = FD.FORMULA_ID
												AND F.FORMULA_ID IN (SELECT 
													CAST(FD.OM_NAME AS unsigned)
												FROM 
													FORMULA F,
													FORMULA_DETAIL FD
												WHERE 
													F.FORMULA_ID = FD.FORMULA_ID
													AND F.FORMULA_ID IN (SELECT 
																				FORMULA_ID
																		FROM 
																				TEMPLATE_FORMULA H
																		WHERE 
																				H.TEMPLATE_ID = '||vTemplateID||'
																		)
												AND FD.GROUP_NAME = ''FORMULA''									   
											)
						AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
						AND FD.GROUP_NAME IS NOT NULL
				UNION 
				SELECT /*! RevalidateMarketUserReportsSubscription */  
						GROUP_NAME 
				FROM FORMULA_DETAIL FD  
				WHERE  
				FORMULA_ID IN (
					SELECT FORMULA_ID FROM TEMPLATE_FORMULA H 
					WHERE H.TEMPLATE_ID = '||vTemplateID||')
					AND FD.GROUP_NAME NOT IN (''CONSTANT'',''FORMULA'') 
				)';
		
		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);
		
		qryCheckActiveGroups  = TO_QUERY(vSql);   
		vActiveGroup2 = SCALAR(qryCheckActiveGroups);
		
		IF vActiveGroup2 IS NULL THEN 
			 
			vOmAuditLog.sqlExecuted = 'Unable to determine active GROUPS for the Report '||pReportName||'. Unable to update GROUP List' ;
			CALL writeAuditLogV2(vOmAuditLog);
			 
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS,  'Unable to determine active GROUPS for the Report '||pReportName||'. Unable to update GROUP List' AS REASON 
			FROM DUAL;
			
		  RETURN;	  
		END IF;
		
		/*! Now to check for each individual market */
	
		vSql = 'SELECT 
					DISTINCT MARKET_ID 
				FROM 
					USER_REPORTS_SUBSCRIPTION
				WHERE 
					REPORT_NAME = '||QUOTE(pReportName)||
				'   AND USER_NAME = '||QUOTE(pUserName);
				
		vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
		CALL writeAuditLogV2(vOmAuditLog);
		
		qryMarketId = TO_QUERY(vSql);
		recMarketId = COLLECT(qryMarketId);
	
		vMarketIdList  = '';		
		
		FOR x IN 0 .. LENGTH(recMarketId) - 1 LOOP
	
			vMarketId = recMarketId[x].marketId;
		
			/*! Check for active groups for the new Report for the specific market  */ 

			vSql = 'SELECT /*! RevalidateMarketUserReportsSubscription */ 
							GROUP_CONCAT(DISTINCT GROUP_NAME SEPARATOR '','') GROUP_NM
						FROM 
							'||vVendorDatabase||'.OM_DATA_INTERVALS ODI						
						WHERE 
							ODI.GROUP_NAME IN ('||vActiveGroup2||')
							AND ODI.TRAFFIC_HOUR >= NOW() - INTERVAL '||vGroupValidationLookbackDays||' DAY 
							AND ODI.MARKET_ID = '||QUOTE(vMarketId);
			
			vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
			CALL writeAuditLogV2(vOmAuditLog);
		
			qryCheckActiveGroups  = TO_QUERY(vSql);
			vActiveGroup = SCALAR(qryCheckActiveGroups);
			
			/*! Identify the specific Subscription ID for the report */
	
			vSql = 'SELECT 
							SUBSCRIPTION_ID 
						FROM
							USER_REPORTS_SUBSCRIPTION
						WHERE 
							REPORT_NAME = '||QUOTE(pReportName)||
						'   AND USER_NAME = '||QUOTE(pUserName)||
						'	AND MARKET_ID ='||QUOTE(vMarketId);
			
			vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
			CALL writeAuditLogV2(vOmAuditLog);		
				
			EXECUTE IMMEDIATE vSql INTO vSubscriptionId;
			
			IF vActiveGroup IS NOT NULL THEN	

				vSql = 'UPDATE  /*! RevalidateMarketUserReportsSubscription */ USER_REPORTS_SUBSCRIPTION 
						SET 
							GROUP_NAME = '||QUOTE(vMarketId)||'
						WHERE 
							SUBSCRIPTION_ID = '||QUOTE(vSubscriptionId);
				
				vOmAuditLog.sqlExecuted =  NVL(vSql, 'Got Null') ;
				CALL writeAuditLogV2(vOmAuditLog);
				
				EXECUTE IMMEDIATE vSql;
				vrowcount = row_count() + vrowcount;				
				vMarketIdList = vMarketId||','||vMarketIdList;
				
				vOmAuditLog.sqlExecuted =  '('||vrowcount||')- Records updated in USER_REPORTS_SUBSCRIPTION for SUBSCRIPTION_ID-('||QUOTE(vSubscriptionId)||')';
				CALL writeAuditLogV2(vOmAuditLog);				
					
				vOmAuditLog.sqlExecuted = 'MarketIdList-('|| vMarketIdList||')' ;
				CALL writeAuditLogV2(vOmAuditLog);
			ELSE 	    
				vOmAuditLog.sqlExecuted =  'Unable to determine active GROUPS in Market '||QUOTE(vMarketId)||' for the Report '||pReportName||'. Not updating groups ' ;
				CALL writeAuditLogV2(vOmAuditLog);
				
				ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS,  'Unable to determine active GROUPS in Market '||QUOTE(vMarketId)||' for the Report '||pReportName||'. Not updating groups ' AS REASON FROM DUAL;
   
			END IF;  
		END LOOP;
	ELSE 
	  	vOmAuditLog.sqlExecuted =  'Report/User does not exist';
		CALL writeAuditLogV2(vOmAuditLog);
		  
		ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Report/User does not exist' AS REASON FROM DUAL;		

		RETURN;
    END IF; 
 END IF;	
  
    /*! Final insert to track procedure execution metrics */
	 
	INSERT  /*! RevalidateMarketUserReportsSubscription */ 
	    INTO APP_ACTIVITIES_LOG 
		    ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
	    VALUES 
		    ( vOmAuditLog.spName,
		     vSessionIdentifier,
		     'Executing Procedure',
       	      'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
		     'Active Groups identified: ('||vActiveGroup2||') Rows updated in USER_REPORTS_SUBSCRIPTION: ('||vrowcount||') Valid Markets identified: ('||QUOTE(vMarketIdList)||')',
		     NULL,
		     vActivityStartTime,
		     NOW(6),
		     'COMPLETE');    
		
	COMMIT;
			 
    ECHO SELECT 
				vOmAuditLog.spName AS APP_NAME,  
				'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 
				'COMPLETE' AS STATUS, 
				'Active Groups identified: ('||vActiveGroup2||') Rows updated in USER_REPORTS_SUBSCRIPTION: ('||vrowcount||') Valid Markets identified: ('||QUOTE(vMarketIdList)||')'  AS REASON 
		FROM 
				DUAL;	
	
	EXCEPTION
		WHEN OTHERS THEN
		ROLLBACK;
		IF vAppLogLevel = 'ERROR' THEN
			INSERT  /*! RevalidateMarketUserReportsSubscription */ 
			  INTO APP_ACTIVITIES_LOG 
				 ( APP_NAME,
				   BATCH_ID,
				   ACTIVITY_TYPE,
				   ACTIVITY_DETAILS,
				   ACTIVITY_OUTPUT,
				   ACTIVITY_ERROR_MSG,
				   ACTIVITY_START_TS,
				   ACTIVITY_END_TS,
				   ACTIVITY_STATUS) 
			VALUES 
				( vOmAuditLog.spName,
				  vSessionIdentifier,
				  'Executing Procedure',
				  'Procedure Arguments: ('||QUOTE(pReportName) ||','||QUOTE(pUserName)||')',
				  NULL,
				  exception_message(),
				  vActivityStartTime,
				  NOW(6),
				  'EXCEPTION' );
        
		END IF;
		IF vAppLogLevel = 'DEBUG' THEN
			vOmAuditLog.sqlExecuted =  'Found Exception ';
			vOmAuditLog.errorMsg = exception_message();
			CALL writeAuditLogV2(vOmAuditLog);
		END IF;		
	COMMIT;
    
	ECHO SELECT 
				vOmAuditLog.spName AS APP_NAME, 
				'Procedure Arguments: ('|| QUOTE(pReportName) ||','||QUOTE(pUserName)||')' AS ARGUMENTS, 
				'EXCEPTION' AS STATUS, 
				exception_message() AS REASON 
		FROM 
				DUAL;	 
 RAISE;
END;
//
DELIMITER ;

