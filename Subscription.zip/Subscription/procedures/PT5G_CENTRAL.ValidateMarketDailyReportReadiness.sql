/*
Database : PT5G_CENTRAL
Procedure: ValidateMarketDailyReportReadiness
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE PROCEDURE `ValidateMarketDailyReportReadiness`(pDatabase varchar(30) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pSubscriptionId varchar(256) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL, pLookBackDays int(11) NULL DEFAULT NULL, pDataLossIsTrue tinyint(1) NULL DEFAULT NULL) RETURNS void AS
DECLARE

/*!
  PROCEDURE NAME       : ValidateMarketDailyReportReadiness
  DATE CREATED         : JAN 21, 2024
  VERSION			   : V2
  AUTHOR			   : Krishna M
  PROCEDURE DESC	   : Smart Reports - NTSCA-26866
					   : Example invocation - call ValidateMarketDailyReportReadiness('PT5G','0ce65105a59c4fcf847fe543749c1f8a28242c4408448462c16f6e79b767cf25a5d67aa31fd400fa3ccb9132472a4089593b1fd7e856d254f87020bd16ee3292',NULL,0);
					    The procedure will do the following.
						1. Lookup SUBSCRIPTION_ID (combination of REPORT_ID and MARKET_ID) from USER_REPORTS_SUBSCRIPTION (maintained by the UI) with select for update. We will take a rowlevel lock for the duration  of procedure to prevent multiple instances running at same time for the same report.
						2. Validate that the Report is Market/Daily
						3. Retrieve the lists of market_ids and the corresponding GROUP_NAMEs for the Report from USER_REPORTS_SUBSCRIPTION
						4. Retrieve other metadata relating to the Report.
						5. Check latest STARTDATE in OM_DAILY_LOAD_STATUS for a combination of GROUP_NAME+Market_id. 
						6. Manage the following cases
							6.1 - Current PENDING interval is ready. Next STARTDATE is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING.
							6.2 - Current PENDING interval is not ready. Next interval has not started loading yet. Check for next available interval. If identified, then mark all intervals upto next available interval as DATA_LOSS_DETECTED. Add the next available interval as READY_FOR_DELIVERY and continue. 
							6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.
							6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available STARTDATE to create the first entry and use pLookBackDays as the window to go back in time.
							6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.
							6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest STARTDATE
							
						How do we cross-validate? This query should help
						SELECT STARTDATE,  market_id, count(1)
						FROM  OM_DAILY_LOAD_STATUS WHERE CURRENT_HOUR = 'Y' AND GROUP_NAME IN  (<list of groups for the report>) GROUP BY STARTDATE, market_id order by 3
						We expect that the the count will match the number of groups in the report for a specific market_id and STARTDATE

  MODIFICATION HISTORY : manohkr - July 11, 2023. NTSCA-21950-Introduced DATA_AVAILABILITY_FACTOR. 
						This is to ensure that Subscriptions will continue to mark intervals as ready even if all the groups for a report are not available. This is a temporary fix until we rework hourly aggregations to be consistent. PT5G is more prone to missing data.
						: manohkr - Oct 2, 2023. NTSCA-24172 - Part 1 of Add hooks into DlpProcessHourlyData to trigger running extracts again if hourly was reprocessed
						Added changes to mark intervals as DATA_LOSS_DETECTED. The goal is to have a secondary process that will run async and determine feasiblity of re-running these extracts
						: manohkr - Dec 9, 2023 - NTSCA-26569 - Bug fix Line 424 to address null values for vReportIntervalFirstAvailableStartDate
						: pownrvi - Jan 5, 2023 - NTSCA-26866 - Modifying Condition for OM_DAILY_LOAD_STATUS, DAILY_ROLLUP_STATUS is ROLLUP_COMPLETE
  
*/  

	vOmAuditLog RECORD( spName VARCHAR(256) CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlExecuted TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 sqlVariables TEXT CHARACTER SET utf8 COLLATE utf8_bin ,
						 logTime DATETIME,
						 errorCode INT,
						 errorMsg TEXT CHARACTER SET utf8 COLLATE utf8_bin 
						 ) 
								= ROW(NULL,
									NULL,
									NULL,
									NULL,
									NULL,
									NULL
									);

	vSessionIdentifier VARCHAR(36) CHARACTER SET utf8 COLLATE utf8_bin;
	vAppLogLevel VARCHAR(6) CHARACTER SET utf8 COLLATE utf8_bin NULL;
	vActivityStartTime DATETIME(6);
	vCheckReportisEnabled INT;
	vMarketId LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin;
	vMarketId2 LONGTEXT CHARACTER SET utf8 COLLATE utf8_bin;
	vGroupName LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vGroupName2 LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEndDate VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vSql LONGTEXT  CHARACTER SET utf8 COLLATE utf8_bin;
	vCountMarketId INT;
	vCountGroupName INT;
	vCountMarketGroup INT;
	vReportIntervalStartDate DATETIME;
	vReportIntervalEndDate DATETIME;
	vReportIntervalFirstAvailableStartDate DATETIME;
	vReportCheckStatus INT;
	vReportReadinessCheckStatus INT;
	vReportUserName VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportEnvironment VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportVendor VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_bin;
	vReportName VARCHAR(256)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportType VARCHAR(128)  CHARACTER SET utf8 COLLATE utf8_bin;
	vReportCurrentStartDateCheckStatus INT;
	vReportNextStartDateCheckStatus INT;
	vReportIntervalFirstAvailableStartDateCheckStatus INT;
	vrowcount BIGINT DEFAULT 0;
	vLookBackDays INT;
	vReportId BIGINT;
	vDataAvailabilityFactor INT;

BEGIN
	vOmAuditLog.spName = 'ValidateMarketDailyReportReadiness';
	vOmAuditLog.errorCode = 0;
	vOmAuditLog.errorMsg = ' ';
  
	vOmAuditLog.sqlExecuted =  'Started processing with arguments :(' ||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')';
	vOmAuditLog.sqlVariables = pDatabase||','|| pSubscriptionId||','||pLookBackDays||','||pDataLossIsTrue;
  	
	SELECT /*! ValidateMarketDailyReportReadiness */ NOW(6) INTO vActivityStartTime;
	SELECT /*! ValidateMarketDailyReportReadiness */ UUID() INTO vSessionIdentifier;
  
	SELECT /*! ValidateMarketDailyReportReadiness */  IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'APP_LOG_LEVEL' 
	INTO vAppLogLevel;
  
	/*! - Checking for DATA_AVAILABILITY_FACTOR - Default is 80 if not found */
	  
	SELECT /*! ValidateMarketDailyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),80) 
	FROM APP_CONFIG 
	WHERE APP_NAME = vOmAuditLog.spName 
	AND APP_KEY = 'DATA_AVAILABILITY_FACTOR' 
	INTO vDataAvailabilityFactor;	 
	
IF vAppLogLevel = 'ERROR' THEN
		/*! - we validate the report id is enabled */
		SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = pSubscriptionId 
			AND IS_ENABLED = 'Y' 
			AND REPORT_TYPE = 'Daily Totals' 
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		) 
		INTO vCheckReportisEnabled;

		IF vCheckReportisEnabled > 0 THEN
			/*! we select all metadata for the report */
			START TRANSACTION;
			
				
				SELECT /*! ValidateMarketDailyReportReadiness */ USER_NAME,
					 ENVIRONMENT,
					 VENDOR,
					 REPORT_ID,
					 REPORT_NAME,
					 REPORT_TYPE,
					 REPORT_END_DATE, 
					 '('||CommaStringToList(MARKET_ID)||')', 
					 MARKET_ID,
					 CountElementsCommaString(MARKET_ID), 
					 '('||CommaStringToList(GROUP_NAME)||')',
					 GROUP_NAME,
					 CountElementsCommaString(GROUP_NAME)		
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = pSubscriptionId FOR UPDATE
				INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
					 vReportEndDate, vMarketId, vMarketId2,  vCountMarketId, vGroupName, vGroupName2, vCountGroupName; 

				/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */		
				vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);
					
				/*! find out if we ever checked for this report*/
				SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
				(
					SELECT 1 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS 
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					LIMIT 1
				) 
				INTO vReportCheckStatus;

				/*! - If prior run is available, then we pickup the last interval that we checked for */
			IF (vReportCheckStatus > 0 AND pDataLossIsTrue = 0) THEN
				/*! We always expect to see an entry in Pending state */
				SELECT /*! ValidateMarketDailyReportReadiness */ 
					   REPORT_INTERVAL_START_TIME,
					   REPORT_INTERVAL_END_TIME
				FROM USER_REPORTS_SUBSCRIPTION_STATUS 
				WHERE SUBSCRIPTION_ID = pSubscriptionId 
				AND REPORT_READINESS = 'PENDING' 
				INTO vReportIntervalStartDate, vReportIntervalEndDate;
					
				/*! - We need to see if the pending days is ready for reports */
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketDailyReportReadiness */ STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE'' 
							AND GROUP_NAME IN '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND STARTDATE = DATE('||QUOTE(vReportIntervalStartDate)||') 
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
						)';
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;
					
				/*! - We need to see if the next day is ready for reports */
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketDailyReportReadiness */ STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							AND GROUP_NAME IN  '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND STARTDATE = DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY 
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||
						')';
			
				
				EXECUTE IMMEDIATE vSql INTO vReportNextStartDateCheckStatus;

					/*! Case 6.1 - Current PENDING interval is ready. Next STARTDATE is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING. */
					IF (vReportCurrentStartDateCheckStatus > 0 and vReportNextStartDateCheckStatus = 0 ) THEN 
						UPDATE  /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
						SET REPORT_READINESS = 'READY_FOR_DELIVERY',
							 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
							 REPORT_READINESS_UPDATED_AT = NOW(6)
						WHERE SUBSCRIPTION_ID = pSubscriptionId 
						AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
						AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
								
						vrowcount = vrowcount+row_count();
		
						/*! - Add an entry for the next STARTDATE as pending */
						INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							VALUES
							(
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  vReportIntervalEndDate,
							  vReportIntervalEndDate + INTERVAL 1 DAY,
							  'PENDING',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							);
							vrowcount = vrowcount + row_count();
							/*! or if the vReportCutoffTimeThresholddays has elapsed */					
					END IF;
				
				/*!	6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentStartDateCheckStatus = 0 AND vReportNextStartDateCheckStatus > 0 ) THEN
					UPDATE /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'NEXT_INTERVAL_HAS_FINISHED_LOADING',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
					AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
						
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as READY_FOR_DELIVERY */
					  INSERT  /*! ValidateMarketDailyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_TRIGGER,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndDate,
						vReportIntervalEndDate + INTERVAL 1 DAY,
						'READY_FOR_DELIVERY',
						'INTERVAL_IS_AVAILABLE',
						NOW(),
						vGroupName2,
						vMarketId2
					  );

					  /*! - Add an entry for the next STARTDATE as PENDING */
					  INSERT  /*! ValidateMarketDailyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndDate + INTERVAL 1 DAY,
						vReportIntervalEndDate + INTERVAL 2 DAY,
						'PENDING',
						NOW(),
						vGroupName2,
						vMarketId2
					  );					  
					  vrowcount = vrowcount + row_count();
				END IF;
					
				/*!	6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentStartDateCheckStatus > 0 AND vReportNextStartDateCheckStatus > 0 ) THEN
					UPDATE /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					 SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
					
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndDate,
						 vReportIntervalEndDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);

					/*! - Add an entry for the next STARTDATE as PENDING */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndDate + INTERVAL 1 DAY,
						 vReportIntervalEndDate + INTERVAL 2 DAY,
						 'PENDING',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);
					vrowcount = vrowcount + row_count();							
				END IF;					
										
				/*! 6.2 - Current PENDING interval is not ready. No new intervals available (Next interval has not started loading yet). Sleep and retry. */
				/*! we update the Report readiness updated column to show we checked this report */							
				IF ( vReportCurrentStartDateCheckStatus = 0 and vReportNextStartDateCheckStatus = 0 )  THEN

				 /*! - Check to see if min(STARTDATE) > vReportIntervalStartDate + INTERVAL 1 DAY */


					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */  EXISTS 
							(
								SELECT STARTDATE AS STARTDATE 
								FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
								WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
								AND GROUP_NAME IN  '||vGroupName||' 
								AND MARKET_ID IN '||vMarketId||' 
								AND STARTDATE > DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY
								GROUP BY STARTDATE 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								LIMIT 1
							)';
				
					EXECUTE IMMEDIATE vSql into vReportIntervalFirstAvailableStartDateCheckStatus;
				   
					IF vReportIntervalFirstAvailableStartDateCheckStatus > 0 THEN 
					
						vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MIN(STARTDATE) AS STARTDATE 
								FROM
								(
								SELECT STARTDATE
								FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
								WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
								 AND GROUP_NAME IN  '||vGroupName||' 
								 AND MARKET_ID IN '||vMarketId||' 
								 AND STARTDATE > DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY
								GROUP BY STARTDATE 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								)'
								;
			
			  
						EXECUTE IMMEDIATE vSql INTO vReportIntervalFirstAvailableStartDate;
						
							/*! We now mark the intervals < vReportIntervalFirstAvailableStartDate as DATE_LOSS_DETECTED */
						
							UPDATE  /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							SET REPORT_READINESS = 'DATA_LOSS_DETECTED',
								 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_NOT_AVAILABLE',
								 REPORT_READINESS_UPDATED_AT = NOW(6)
							WHERE SUBSCRIPTION_ID = pSubscriptionId 
								  AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
								  AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;								
							vrowcount = vrowcount+row_count();
						
							/*! Insert all the missing intervals upto vReportIntervalFirstAvailableStartDate as DATA_LOSS_DETECTED */
					
					
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_TRIGGER,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							SELECT 
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  TABLE_COL,
							  TABLE_COL + INTERVAL 1 DAY,
							  'DATA_LOSS_DETECTED',
							  'INTERVAL_IS_NOT_AVAILABLE',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							  FROM 
							  TABLE(getTimeBuckets(vReportIntervalFirstAvailableStartDate,3,'INTERVAL_DAILY'))
							  WHERE 
							  TABLE_COL >= vReportIntervalStartDate + INTERVAL 1 DAY 
							  ;					
							vrowcount = vrowcount + row_count();				
					
							/*! - Add an entry for the vReportIntervalFirstAvailableStartDate  as available */
								
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_TRIGGER,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartDate,
								vReportIntervalFirstAvailableStartDate + INTERVAL 1 DAY,
								'READY_FOR_DELIVERY',
								'INTERVAL_IS_AVAILABLE',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );
							  
							vrowcount = vrowcount + row_count();
						
							/*! - Add an entry for the next STARTDATE as pending */
								
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartDate + INTERVAL 1 DAY,
								vReportIntervalFirstAvailableStartDate + INTERVAL 2 DAY,
								'PENDING',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );					  
							vrowcount = vrowcount + row_count();			
						
						/*! vReportIntervalFirstAvailableStartDateCheckStatus = 0 */
						ELSE
						
							ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
												
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO APP_ACTIVITIES_LOG 
							  ( APP_NAME,
								BATCH_ID,
								ACTIVITY_TYPE,
								ACTIVITY_DETAILS,
								ACTIVITY_OUTPUT,
								ACTIVITY_ERROR_MSG,
								ACTIVITY_START_TS,
								ACTIVITY_END_TS,
								ACTIVITY_STATUS) 
							VALUES 
							 ( vOmAuditLog.spName,
							   vSessionIdentifier,
							   'Executing Procedure',
							   'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
							   NULL,
							   'NO STARTDATE available for Subscription: '||pSubscriptionId,
							   vActivityStartTime,
							   NOW(6),
							   'EXCEPTION'); 	 
							COMMIT;
							RETURN;					
					    END IF;
				END IF;
			END IF;
		
			IF (vReportCheckStatus = 0 AND pDataLossIsTrue = 0) THEN
				/*!	6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available STARTDATE to create the first entry*/
				/*! - We see if there is any STARTDATE that matches the condition within the last vLookBackDays  from UTC */
				IF pLookBackDays IS NULL THEN
					SELECT /*! ValidateMarketDailyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_DAYS' 
					INTO vLookBackDays;
				ELSE 
					vLookBackDays = pLookBackDays;
				END IF;

				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
		
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;
					
				/*! - If there is an available STARTDATE - we pickup the max STARTDATE that matches the conditions */
				
				IF vReportCurrentStartDateCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MAX(STARTDATE) AS STARTDATE
							FROM 
							(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
					
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartDate;
			
					/*! - Add an entry for this STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
						)
					VALUES
					   ( 
						 vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartDate,
						 vReportIntervalStartDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);
		
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as pending */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					  INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   SUBSCRIPTION_ID,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_INTERVAL_START_TIME, 
						   REPORT_INTERVAL_END_TIME, 
						   REPORT_READINESS,
						   REPORT_READINESS_UPDATED_AT,
						   GROUP_NAME,
						   MARKET_ID
						 )
					VALUES
						( vReportUserName,
						  vReportEnvironment,
						  vReportVendor,
						  pSubscriptionId,
						  vReportId,
						  vReportName,
						  vReportIntervalStartDate + INTERVAL 1 DAY,
						  vReportIntervalStartDate + INTERVAL 2 DAY,
						  'PENDING',
						  NOW(6),
						  vGroupName2,
						  vMarketId2
						);
					
					vrowcount = vrowcount + row_count();
								
				ELSIF vReportCurrentStartDateCheckStatus = 0 THEN
				
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;			
			END IF;
					
			IF (pDataLossIsTrue > 0) THEN
				/*! 6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest STARTDATE. Same logic as new entry */
				/*! - All other conditions are negated */
				/*! - We see if there is any STARTDATE that matches the condition within the last vLookBackDays  from UTC */
				IF pLookBackDays IS NULL THEN
					SELECT /*! ValidateMarketDailyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_DAYS' 
					INTO vLookBackDays;
				ELSE 
					vLookBackDays = pLookBackDays;
				END IF;
						
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
			
				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;
					
				/*! - If there is an available STARTDATE - we pickup the max STARTDATE that matches the conditions */
				IF vReportCurrentStartDateCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MAX(STARTDATE) AS STARTDATE 
							FROM
							(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
			  
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartDate;
			
					/*! - Delete entries if any exists for this Report that is for the above STARTDATE */
					DELETE /*! ValidateMarketDailyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalStartDate + INTERVAL 1 DAY;
							
					/*! - Delete entries if any exists for this Report that is marked as PENDING */
					DELETE /*! ValidateMarketDailyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_READINESS = 'PENDING';
																	
					/*! - Add an entry for this STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartDate,
						 vReportIntervalStartDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);			
					vrowcount = vrowcount + row_count();
					/*! - Add an entry for the next STARTDATE as pending */
						
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					  ( vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalStartDate + INTERVAL 1 DAY,
						vReportIntervalStartDate + INTERVAL 2 DAY,
						'PENDING',
						NOW(6),
						vGroupName2,
						vMarketId2
					  );
				
					vrowcount = vrowcount + row_count();
				ELSIF vReportCurrentStartDateCheckStatus = 0 THEN
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;					
			END IF;
			/*! Release the transaction lock on the Report */
			COMMIT;
		ELSE 
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Subscription -'||pSubscriptionId||' is not enabled AND/OR is not an Daily report' AS REASON FROM DUAL;
		END IF;
END IF; 

IF vAppLogLevel = 'DEBUG' THEN
		CALL writeAuditLogV2(vOmAuditLog);
		/*! - we validate the report id is enabled */

		vOmAuditLog.sqlExecuted = '1. Lookup SUBSCRIPTION_ID (combination of REPORT_ID and MARKET_ID) from USER_REPORTS_SUBSCRIPTION ';
		CALL writeAuditLogV2(vOmAuditLog);
		
		vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'
			AND IS_ENABLED = ''Y'' 
			AND REPORT_TYPE = ''Daily Totals''
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		)';		
		
		vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
		CALL writeAuditLogV2(vOmAuditLog);
		
		SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
		(
			SELECT SUBSCRIPTION_ID 
			FROM USER_REPORTS_SUBSCRIPTION 
			WHERE SUBSCRIPTION_ID = pSubscriptionId 
			AND IS_ENABLED = 'Y' 
			AND REPORT_TYPE = 'Daily Totals' 
			AND MARKET_ID IS NOT NULL 
			AND REGION_NAME IS NULL
		) 
		INTO vCheckReportisEnabled;
		
		vOmAuditLog.sqlExecuted = '2. Validate that the Report is Market/Daily :'||vCheckReportisEnabled;
		CALL writeAuditLogV2(vOmAuditLog);
				
		IF vCheckReportisEnabled > 0 THEN

			/*! we select all metadata for the report */
			START TRANSACTION;
			
			vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ USER_NAME,
					 ENVIRONMENT,
					 VENDOR,
					 REPORT_ID,
					 REPORT_NAME,
					 REPORT_TYPE,
					 REPORT_END_DATE, 
					 ''(''||CommaStringToList(MARKET_ID)||'')'', 
					 MARKET_ID,
					 CountElementsCommaString(MARKET_ID), 
					 ''(''||CommaStringToList(GROUP_NAME)||'')'',
					 GROUP_NAME,
					 CountElementsCommaString(GROUP_NAME)		
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId)||'';
		
		vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
		CALL writeAuditLogV2(vOmAuditLog);

				
				SELECT /*! ValidateMarketDailyReportReadiness */ USER_NAME,
					 ENVIRONMENT,
					 VENDOR,
					 REPORT_ID,
					 REPORT_NAME,
					 REPORT_TYPE,
					 REPORT_END_DATE, 
					 '('||CommaStringToList(MARKET_ID)||')', 
					 MARKET_ID,
					 CountElementsCommaString(MARKET_ID), 
					 '('||CommaStringToList(GROUP_NAME)||')',
					 GROUP_NAME,
					 CountElementsCommaString(GROUP_NAME)		
				FROM USER_REPORTS_SUBSCRIPTION 
				WHERE SUBSCRIPTION_ID = pSubscriptionId FOR UPDATE
				INTO vReportUserName, vReportEnvironment, vReportVendor, vReportId, vReportName, vReportType, 
					 vReportEndDate, vMarketId, vMarketId2,  vCountMarketId, vGroupName, vGroupName2, vCountGroupName; 

				vOmAuditLog.sqlExecuted = '3. Retrieve the lists of market_ids and the corresponding GROUP_NAMEs for the Report from USER_REPORTS_SUBSCRIPTION';
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = 'Groups in report:'||QUOTE(vGroupName);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of Groups in report:'||vCountGroupName;
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = 'Markets in report:'||QUOTE(vMarketId);
				CALL writeAuditLogV2(vOmAuditLog);
				
				vOmAuditLog.sqlExecuted = 'Number of markets in report:'||vCountMarketId;
				CALL writeAuditLogV2(vOmAuditLog);

				/*! - we find out how many groups + markets and xply by DATA_AVAILABILITY_FACTOR */		
				vCountMarketGroup = ROUND(vCountMarketId * vCountGroupName * (vDataAvailabilityFactor / 100),0);
					
				vOmAuditLog.sqlExecuted = 'Logging active countmarketgroup: '||vCountMarketGroup;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! find out if we ever checked for this report*/
				vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ EXISTS 
					(
						SELECT 1 
						FROM USER_REPORTS_SUBSCRIPTION_STATUS 
						WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||
					' LIMIT 1
					)';
					
					vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
					CALL writeAuditLogV2(vOmAuditLog);
					
					EXECUTE IMMEDIATE vSql INTO vReportCheckStatus;

				vOmAuditLog.sqlExecuted = 'Report status check returned:'||vReportCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);

				/*! - If prior run is available, then we pickup the last interval that we checked for */
			IF (vReportCheckStatus > 0 AND pDataLossIsTrue = 0) THEN
			
				vOmAuditLog.sqlExecuted = '4. Retrieve other metadata relating to the Report.';
				CALL writeAuditLogV2(vOmAuditLog);
			
				/*! We always expect to see an entry in Pending state */
				vSql='SELECT /*! ValidateMarketHourlyReportReadiness */ 
					   REPORT_INTERVAL_START_TIME,
					   REPORT_INTERVAL_END_TIME
					FROM USER_REPORTS_SUBSCRIPTION_STATUS 
					WHERE SUBSCRIPTION_ID = '||QUOTE(pSubscriptionId )||' 
					AND REPORT_READINESS = ''PENDING''';
				
				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				
				SELECT /*! ValidateMarketDailyReportReadiness */ 
					   REPORT_INTERVAL_START_TIME,
					   REPORT_INTERVAL_END_TIME
				FROM USER_REPORTS_SUBSCRIPTION_STATUS 
				WHERE SUBSCRIPTION_ID = pSubscriptionId 
				AND REPORT_READINESS = 'PENDING' 
				INTO vReportIntervalStartDate, vReportIntervalEndDate;

				vOmAuditLog.sqlExecuted = 'ReportIntervalStartDate / ReportIntervalEndDate: '||vReportIntervalStartDate||' / '|| vReportIntervalEndDate;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! - We need to see if the pending days is ready for reports */
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketDailyReportReadiness */ STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE'' 
							AND GROUP_NAME IN '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND STARTDATE = DATE('||QUOTE(vReportIntervalStartDate)||') 
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
						)';

				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
				
				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;

				vOmAuditLog.sqlExecuted = 'ReportCurrentStartDateCheckStatus : '||vReportCurrentStartDateCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! - We need to see if the next day is ready for reports */
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT /*! ValidateMarketDailyReportReadiness */ STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							AND GROUP_NAME IN  '||vGroupName||' 
							AND MARKET_ID IN '||vMarketId||' 
							AND STARTDATE = DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY 
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||
						')';

				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);
			
				
				EXECUTE IMMEDIATE vSql INTO vReportNextStartDateCheckStatus;
				
				vOmAuditLog.sqlExecuted = 'ReportNextStartDateCheckStatus: ('||vReportNextStartDateCheckStatus||')';
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = '5. Check latest STARTDATE in OM_DAILY_LOAD_STATUS for a combination of GROUP_NAME+Market_id';
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = 'ReportCurrentStartDateCheckStatus / ReportNextStartDateCheckStatus : '||vReportCurrentStartDateCheckStatus||' / '|| vReportNextStartDateCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);

				vOmAuditLog.sqlExecuted = '6.Manage the cases';
				CALL writeAuditLogV2(vOmAuditLog);

					/*! Case 6.1 - Current PENDING interval is ready. Next STARTDATE is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING. */
					IF (vReportCurrentStartDateCheckStatus > 0 and vReportNextStartDateCheckStatus = 0 ) THEN 

						vOmAuditLog.sqlExecuted = '6.1 - Current PENDING interval is ready. Next STARTDATE is not ready. Mark PENDING interval (REPORT_INTERVAL_END_TIME) as READY_FOR_DELIVERY. Add next interval as PENDING.';
						CALL writeAuditLogV2(vOmAuditLog);

						UPDATE  /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
						SET REPORT_READINESS = 'READY_FOR_DELIVERY',
							 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
							 REPORT_READINESS_UPDATED_AT = NOW(6)
						WHERE SUBSCRIPTION_ID = pSubscriptionId 
						AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
						AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
								
						vrowcount = vrowcount+row_count();
		
						/*! - Add an entry for the next STARTDATE as pending */
						INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							VALUES
							(
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  vReportIntervalEndDate,
							  vReportIntervalEndDate + INTERVAL 1 DAY,
							  'PENDING',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							);
							vrowcount = vrowcount + row_count();
							/*! or if the vReportCutoffTimeThresholddays has elapsed */					
					END IF;
				
				/*!	6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentStartDateCheckStatus = 0 AND vReportNextStartDateCheckStatus > 0 ) THEN

					vOmAuditLog.sqlExecuted = '6.3 - Current PENDING interval is not ready. Next interval has finished loading. Mark current interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. ';
					CALL writeAuditLogV2(vOmAuditLog);

					UPDATE /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'NEXT_INTERVAL_HAS_FINISHED_LOADING',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
					AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
						
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as READY_FOR_DELIVERY */
					  INSERT  /*! ValidateMarketDailyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_TRIGGER,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndDate,
						vReportIntervalEndDate + INTERVAL 1 DAY,
						'READY_FOR_DELIVERY',
						'INTERVAL_IS_AVAILABLE',
						NOW(),
						vGroupName2,
						vMarketId2
					  );

					  /*! - Add an entry for the next STARTDATE as PENDING */
					  INSERT  /*! ValidateMarketDailyReportReadiness */ INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					  (
						USER_NAME,
						ENVIRONMENT,
						VENDOR,
						SUBSCRIPTION_ID,
						REPORT_ID,
						REPORT_NAME,
						REPORT_INTERVAL_START_TIME, 
						REPORT_INTERVAL_END_TIME, 
						REPORT_READINESS,
						REPORT_READINESS_UPDATED_AT,
						GROUP_NAME,
						MARKET_ID
					  )
					  VALUES
					  (
						vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalEndDate + INTERVAL 1 DAY,
						vReportIntervalEndDate + INTERVAL 2 DAY,
						'PENDING',
						NOW(),
						vGroupName2,
						vMarketId2
					  );					  
					  vrowcount = vrowcount + row_count();
				END IF;
					
				/*!	6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING. */
				IF ( vReportCurrentStartDateCheckStatus > 0 AND vReportNextStartDateCheckStatus > 0 ) THEN

					vOmAuditLog.sqlExecuted = '6.5 - Current PENDING interval is ready. Next interval is also ready. Mark current pending interval to READY_FOR_DELIVERY and next interval as READY_FOR_DELIVERY and insert new record as PENDING.';
					CALL writeAuditLogV2(vOmAuditLog);

					UPDATE /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
					 SET REPORT_READINESS = 'READY_FOR_DELIVERY',
						 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_AVAILABLE',
						 REPORT_READINESS_UPDATED_AT = NOW(6)
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;
					
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndDate,
						 vReportIntervalEndDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);

					/*! - Add an entry for the next STARTDATE as PENDING */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalEndDate + INTERVAL 1 DAY,
						 vReportIntervalEndDate + INTERVAL 2 DAY,
						 'PENDING',
						 NOW(),
						 vGroupName2,
						 vMarketId2
						);
					vrowcount = vrowcount + row_count();							
				END IF;					
										
				/*! 6.2 - Current PENDING interval is not ready. No new intervals available (Next interval has not started loading yet). Sleep and retry. */
				/*! we update the Report readiness updated column to show we checked this report */							
				IF ( vReportCurrentStartDateCheckStatus = 0 and vReportNextStartDateCheckStatus = 0 )  THEN

				 /*! - Check to see if min(STARTDATE) > vReportIntervalStartDate + INTERVAL 1 DAY */

					vOmAuditLog.sqlExecuted = '6.2 - Current PENDING interval is not ready. No new intervals available (Next interval has not started loading yet). Sleep and retry.';
					CALL writeAuditLogV2(vOmAuditLog);

					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */  EXISTS 
							(
								SELECT STARTDATE AS STARTDATE 
								FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
								WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
								AND GROUP_NAME IN  '||vGroupName||' 
								AND MARKET_ID IN '||vMarketId||' 
								AND STARTDATE > DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY
								GROUP BY STARTDATE 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								LIMIT 1
							)';

						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);
				
					EXECUTE IMMEDIATE vSql into vReportIntervalFirstAvailableStartDateCheckStatus;

					vOmAuditLog.sqlExecuted = '6.2.1 ReportIntervalFirstAvailableStartDateCheckStatus : '||vReportIntervalFirstAvailableStartDateCheckStatus;
					CALL writeAuditLogV2(vOmAuditLog);
				   
					IF vReportIntervalFirstAvailableStartDateCheckStatus > 0 THEN 
					
						vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MIN(STARTDATE) AS STARTDATE 
								FROM
								(
								SELECT STARTDATE
								FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
								WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
								 AND GROUP_NAME IN  '||vGroupName||' 
								 AND MARKET_ID IN '||vMarketId||' 
								 AND STARTDATE > DATE('||QUOTE(vReportIntervalStartDate)||') + INTERVAL 1 DAY
								GROUP BY STARTDATE 
								HAVING COUNT(1) >= '||vCountMarketGroup||'
								)'
								;

						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);
			  
						EXECUTE IMMEDIATE vSql INTO vReportIntervalFirstAvailableStartDate;

						vOmAuditLog.sqlExecuted = '6.2.1 ReportIntervalFirstAvailableStartDate : '||vReportIntervalFirstAvailableStartDateCheckStatus;
						CALL writeAuditLogV2(vOmAuditLog);
				   						
							/*! We now mark the intervals < vReportIntervalFirstAvailableStartDate as DATE_LOSS_DETECTED */
						
							UPDATE  /*! ValidateMarketDailyReportReadiness */ USER_REPORTS_SUBSCRIPTION_STATUS 
							SET REPORT_READINESS = 'DATA_LOSS_DETECTED',
								 REPORT_READINESS_TRIGGER = 'INTERVAL_IS_NOT_AVAILABLE',
								 REPORT_READINESS_UPDATED_AT = NOW(6)
							WHERE SUBSCRIPTION_ID = pSubscriptionId 
								  AND REPORT_INTERVAL_END_TIME = vReportIntervalEndDate 
								  AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate;								
							vrowcount = vrowcount+row_count();
						
							/*! Insert all the missing intervals upto vReportIntervalFirstAvailableStartDate as DATA_LOSS_DETECTED */
					
					
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							(
							  USER_NAME,
							  ENVIRONMENT,
							  VENDOR,
							  SUBSCRIPTION_ID,
							  REPORT_ID,
							  REPORT_NAME,
							  REPORT_INTERVAL_START_TIME, 
							  REPORT_INTERVAL_END_TIME, 
							  REPORT_READINESS,
							  REPORT_READINESS_TRIGGER,
							  REPORT_READINESS_UPDATED_AT,
							  GROUP_NAME,
							  MARKET_ID
							)
							SELECT 
							  vReportUserName,
							  vReportEnvironment,
							  vReportVendor,
							  pSubscriptionId,
							  vReportId,
							  vReportName,
							  TABLE_COL,
							  TABLE_COL + INTERVAL 1 DAY,
							  'DATA_LOSS_DETECTED',
							  'INTERVAL_IS_NOT_AVAILABLE',
							  NOW(),
							  vGroupName2,
							  vMarketId2
							  FROM 
							  TABLE(getTimeBuckets(vReportIntervalFirstAvailableStartDate,3,'INTERVAL_DAILY'))
							  WHERE 
							  TABLE_COL >= vReportIntervalStartDate + INTERVAL 1 DAY 
							  ;					
							vrowcount = vrowcount + row_count();				
					
							/*! - Add an entry for the vReportIntervalFirstAvailableStartDate  as available */
								
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_TRIGGER,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartDate,
								vReportIntervalFirstAvailableStartDate + INTERVAL 1 DAY,
								'READY_FOR_DELIVERY',
								'INTERVAL_IS_AVAILABLE',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );
							  
							vrowcount = vrowcount + row_count();
						
							/*! - Add an entry for the next STARTDATE as pending */
								
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO USER_REPORTS_SUBSCRIPTION_STATUS 
							   ( USER_NAME,
								 ENVIRONMENT,
								 VENDOR,
								 SUBSCRIPTION_ID,
								 REPORT_ID,
								 REPORT_NAME,
								 REPORT_INTERVAL_START_TIME, 
								 REPORT_INTERVAL_END_TIME, 
								 REPORT_READINESS,
								 REPORT_READINESS_UPDATED_AT,
								 GROUP_NAME,
								 MARKET_ID
							   )
							VALUES
							  ( vReportUserName,
								vReportEnvironment,
								vReportVendor,
								pSubscriptionId,
								vReportId,
								vReportName,
								vReportIntervalFirstAvailableStartDate + INTERVAL 1 DAY,
								vReportIntervalFirstAvailableStartDate + INTERVAL 2 DAY,
								'PENDING',
								NOW(6),
								vGroupName2,
								vMarketId2
							  );					  
							vrowcount = vrowcount + row_count();			
						
						/*! vReportIntervalFirstAvailableStartDateCheckStatus = 0 */
						ELSE

							vOmAuditLog.sqlExecuted = 'Case I : OM_DAILY_LOAD_STATUS Does not Data . so NO STARTDATE available for Subscription ';
							CALL writeAuditLogV2(vOmAuditLog);
						
							ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
												
							INSERT  /*! ValidateMarketDailyReportReadiness */ 
							INTO APP_ACTIVITIES_LOG 
							  ( APP_NAME,
								BATCH_ID,
								ACTIVITY_TYPE,
								ACTIVITY_DETAILS,
								ACTIVITY_OUTPUT,
								ACTIVITY_ERROR_MSG,
								ACTIVITY_START_TS,
								ACTIVITY_END_TS,
								ACTIVITY_STATUS) 
							VALUES 
							 ( vOmAuditLog.spName,
							   vSessionIdentifier,
							   'Executing Procedure',
							   'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
							   NULL,
							   'NO STARTDATE available for Subscription: '||pSubscriptionId,
							   vActivityStartTime,
							   NOW(6),
							   'EXCEPTION'); 	 
							COMMIT;
							RETURN;					
					    END IF;
				END IF;
			END IF;
		
			IF (vReportCheckStatus = 0 AND pDataLossIsTrue = 0) THEN
				/*!	6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available STARTDATE to create the first entry*/
				/*! - We see if there is any STARTDATE that matches the condition within the last vLookBackDays  from UTC */

				vOmAuditLog.sqlExecuted = '6.4 - If we have never checked this report before, insert a new record for the interval. We identify the last available STARTDATE to create the first entry';
				CALL writeAuditLogV2(vOmAuditLog);

				IF pLookBackDays IS NULL THEN
					SELECT /*! ValidateMarketDailyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_DAYS' 
					INTO vLookBackDays;
				ELSE 
					vLookBackDays = pLookBackDays;
				END IF;

				vOmAuditLog.sqlExecuted = '6.4.1 LookBackDays : '||vLookBackDays;
				CALL writeAuditLogV2(vOmAuditLog);

				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';
		
				vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
				CALL writeAuditLogV2(vOmAuditLog);

				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;

				vOmAuditLog.sqlExecuted = '6.4.2 ReportCurrentStartDateCheckStatus : '||vReportCurrentStartDateCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! - If there is an available STARTDATE - we pickup the max STARTDATE that matches the conditions */
				
				IF vReportCurrentStartDateCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MAX(STARTDATE) AS STARTDATE
							FROM 
							(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);

					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartDate;

					vOmAuditLog.sqlExecuted = '6.4.3 ReportIntervalStartDate : '||vReportIntervalStartDate;
					CALL writeAuditLogV2(vOmAuditLog);
			
					/*! - Add an entry for this STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
						)
					VALUES
					   ( 
						 vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartDate,
						 vReportIntervalStartDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);
		
					vrowcount = vrowcount + row_count();

					/*! - Add an entry for the next STARTDATE as pending */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					  INTO USER_REPORTS_SUBSCRIPTION_STATUS 
						 ( USER_NAME,
						   ENVIRONMENT,
						   VENDOR,
						   SUBSCRIPTION_ID,
						   REPORT_ID,
						   REPORT_NAME,
						   REPORT_INTERVAL_START_TIME, 
						   REPORT_INTERVAL_END_TIME, 
						   REPORT_READINESS,
						   REPORT_READINESS_UPDATED_AT,
						   GROUP_NAME,
						   MARKET_ID
						 )
					VALUES
						( vReportUserName,
						  vReportEnvironment,
						  vReportVendor,
						  pSubscriptionId,
						  vReportId,
						  vReportName,
						  vReportIntervalStartDate + INTERVAL 1 DAY,
						  vReportIntervalStartDate + INTERVAL 2 DAY,
						  'PENDING',
						  NOW(6),
						  vGroupName2,
						  vMarketId2
						);
					
					vrowcount = vrowcount + row_count();
								
				ELSIF vReportCurrentStartDateCheckStatus = 0 THEN

					vOmAuditLog.sqlExecuted = 'Case II : OM_DAILY_LOAD_STATUS Does not Data for LookBackDays : '||vLookBackDays||' . so NO STARTDATE available for Subscription ';
					CALL writeAuditLogV2(vOmAuditLog);
				
					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;			
			END IF;
					
			IF (pDataLossIsTrue > 0) THEN
				/*! 6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest STARTDATE. Same logic as new entry */

				vOmAuditLog.sqlExecuted = '6.6 - In case we have data loss (pDataLossIsTrue = 1), need to update STATUS to latest STARTDATE. Same logic as new entry';
				CALL writeAuditLogV2(vOmAuditLog);

				/*! - All other conditions are negated */
				/*! - We see if there is any STARTDATE that matches the condition within the last vLookBackDays  from UTC */
				IF pLookBackDays IS NULL THEN
					SELECT /*! ValidateMarketDailyReportReadiness */ IFNULL(ANY_VALUE(KEY_VALUE),'ERROR') 
					FROM APP_CONFIG 
					WHERE APP_NAME = vOmAuditLog.spName 
					AND APP_KEY = 'NEW_SUBSCRIPTION_LOOKBACK_DAYS' 
					INTO vLookBackDays;
				ELSE 
					vLookBackDays = pLookBackDays;
				END IF;

				vOmAuditLog.sqlExecuted = '6.6.1 - LookBackDays : '|| vLookBackDays;
				CALL writeAuditLogV2(vOmAuditLog);
						
				vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ EXISTS 
						(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||' 
							LIMIT 1
						)';

					vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
					CALL writeAuditLogV2(vOmAuditLog);
			
				EXECUTE IMMEDIATE vSql INTO vReportCurrentStartDateCheckStatus;

				vOmAuditLog.sqlExecuted = '6.6.1 - ReportCurrentStartDateCheckStatus : '|| vReportCurrentStartDateCheckStatus;
				CALL writeAuditLogV2(vOmAuditLog);
					
				/*! - If there is an available STARTDATE - we pickup the max STARTDATE that matches the conditions */
				IF vReportCurrentStartDateCheckStatus > 0 THEN
					vSql = 'SELECT /*! ValidateMarketDailyReportReadiness */ MAX(STARTDATE) AS STARTDATE 
							FROM
							(
							SELECT STARTDATE 
							FROM '||pDatabase||'.OM_DAILY_LOAD_STATUS 
							WHERE DAILY_ROLLUP_STATUS = ''ROLLUP_COMPLETE''
							 AND GROUP_NAME IN  '||vGroupName||' 
							 AND MARKET_ID IN '||vMarketId||' 
							 AND STARTDATE >= DATE(NOW()) - INTERVAL '||vLookBackDays||' DAY
							GROUP BY STARTDATE 
							HAVING COUNT(1) >= '||vCountMarketGroup||'
							)';
			
						vOmAuditLog.sqlExecuted = NVL(vSql, 'Got Null');
						CALL writeAuditLogV2(vOmAuditLog);
			  
					EXECUTE IMMEDIATE vSql INTO vReportIntervalStartDate;

					vOmAuditLog.sqlExecuted = '6.6.1 - ReportIntervalStartDate : '|| vReportIntervalStartDate;
					CALL writeAuditLogV2(vOmAuditLog);
			
					/*! - Delete entries if any exists for this Report that is for the above STARTDATE */
					DELETE /*! ValidateMarketDailyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_INTERVAL_START_TIME = vReportIntervalStartDate
					 AND REPORT_INTERVAL_END_TIME = vReportIntervalStartDate + INTERVAL 1 DAY;
							
					/*! - Delete entries if any exists for this Report that is marked as PENDING */
					DELETE /*! ValidateMarketDailyReportReadiness */ 
					FROM USER_REPORTS_SUBSCRIPTION_STATUS
					WHERE SUBSCRIPTION_ID = pSubscriptionId 
					 AND REPORT_READINESS = 'PENDING';
																	
					/*! - Add an entry for this STARTDATE as READY_FOR_DELIVERY */
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME,  
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_TRIGGER,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					   ( vReportUserName,
						 vReportEnvironment,
						 vReportVendor,
						 pSubscriptionId,
						 vReportId,
						 vReportName,
						 vReportIntervalStartDate,
						 vReportIntervalStartDate + INTERVAL 1 DAY,
						 'READY_FOR_DELIVERY',
						 'INTERVAL_IS_AVAILABLE',
						 NOW(6),
						 vGroupName2,
						 vMarketId2
						);			
					vrowcount = vrowcount + row_count();
					/*! - Add an entry for the next STARTDATE as pending */
						
					INSERT  /*! ValidateMarketDailyReportReadiness */ 
					INTO USER_REPORTS_SUBSCRIPTION_STATUS 
					   ( USER_NAME,
						 ENVIRONMENT,
						 VENDOR,
						 SUBSCRIPTION_ID,
						 REPORT_ID,
						 REPORT_NAME,
						 REPORT_INTERVAL_START_TIME, 
						 REPORT_INTERVAL_END_TIME, 
						 REPORT_READINESS,
						 REPORT_READINESS_UPDATED_AT,
						 GROUP_NAME,
						 MARKET_ID
					   )
					VALUES
					  ( vReportUserName,
						vReportEnvironment,
						vReportVendor,
						pSubscriptionId,
						vReportId,
						vReportName,
						vReportIntervalStartDate + INTERVAL 1 DAY,
						vReportIntervalStartDate + INTERVAL 2 DAY,
						'PENDING',
						NOW(6),
						vGroupName2,
						vMarketId2
					  );
				
					vrowcount = vrowcount + row_count();
				ELSIF vReportCurrentStartDateCheckStatus = 0 THEN

					vOmAuditLog.sqlExecuted = 'Case II : OM_DAILY_LOAD_STATUS Does not Data for LookBackDays : '||vLookBackDays||' . so NO STARTDATE available for Subscription ';
					CALL writeAuditLogV2(vOmAuditLog);

					ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'NO STARTDATE available for Subscription: '||pSubscriptionId AS REASON FROM DUAL;
				END IF;					
			END IF;
			/*! Release the transaction lock on the Report */
			COMMIT;
		ELSE 
			ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, 'Subscription -'||pSubscriptionId||' is not enabled AND/OR is not an Daily report' AS REASON FROM DUAL;
		END IF;
		
      vOmAuditLog.sqlExecuted =  'Processing completed ';
      CALL writeAuditLogV2(vOmAuditLog);
		
END IF; 

/*! Final insert to track procedure execution metrics */

	INSERT  /*! ValidateMarketDailyReportReadiness */ 
		INTO APP_ACTIVITIES_LOG 
	      ( APP_NAME,
	        BATCH_ID,
	        ACTIVITY_TYPE,
	        ACTIVITY_DETAILS,
	        ACTIVITY_OUTPUT,
	        ACTIVITY_ERROR_MSG,
	        ACTIVITY_START_TS,
	        ACTIVITY_END_TS,
	        ACTIVITY_STATUS) 
	 VALUES 
		 ( vOmAuditLog.spName,
	       vSessionIdentifier,
	       'Executing Procedure',
	       'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
	       'Rows inserted/updated in USER_REPORTS_SUBSCRIPTION_STATUS: '||vrowcount,
	       NULL,
	       vActivityStartTime,
	       NOW(6),
	       'COMPLETE'); 	 
  COMMIT;

  ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'COMPLETE' AS STATUS, 'Rows inserted/updated in USER_REPORTS_SUBSCRIPTION_STATUS: '||vrowcount AS REASON FROM DUAL;

EXCEPTION
	 WHEN OTHERS THEN
	 ROLLBACK;
     IF vAppLogLevel = 'ERROR' THEN
		INSERT  /*! ValidateMarketDailyReportReadiness */ 
		  INTO APP_ACTIVITIES_LOG 
		     ( APP_NAME,
			   BATCH_ID,
			   ACTIVITY_TYPE,
			   ACTIVITY_DETAILS,
			   ACTIVITY_OUTPUT,
			   ACTIVITY_ERROR_MSG,
			   ACTIVITY_START_TS,
			   ACTIVITY_END_TS,
			   ACTIVITY_STATUS) 
		VALUES 
			( vOmAuditLog.spName,
			  vSessionIdentifier,
			  'Executing Procedure',
    	       'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')',
			  NULL,
			  exception_message(),
			  vActivityStartTime,
			  NOW(6),
			  'EXCEPTION' );
        
	END IF;
	IF vAppLogLevel = 'DEBUG' THEN
         vOmAuditLog.errorMsg = exception_message();
         vOmAuditLog.sqlExecuted =  'Found Exception ';
         CALL writeAuditLogV2(vOmAuditLog);
	END IF;
	COMMIT;
	ECHO SELECT vOmAuditLog.spName AS APP_NAME, 'Procedure Arguments: ('||QUOTE(pDatabase)||','||QUOTE(pSubscriptionId)||','||IFNULL(pLookBackDays,'NULL')||','||IFNULL(pDataLossIsTrue,'NULL')||')' AS ARGUMENTS, 'EXCEPTION' AS STATUS, exception_message() AS REASON FROM DUAL;
	RAISE;
END;
//
DELIMITER ;

