/*
Database : PT5G_CENTRAL
Function: CommaStringToList
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE FUNCTION `CommaStringToList`(pInputString longtext CHARACTER SET utf8 COLLATE utf8_bin NOT NULL) RETURNS longtext CHARACTER SET utf8 COLLATE utf8_general_ci NULL AS
DECLARE
vOutPutString LONGTEXT;

BEGIN

vOutPutString = ''''||REPLACE(REPLACE(pInputString,' ',''),',',"','")||'''';

RETURN vOutPutString;

END;
//
DELIMITER ;

