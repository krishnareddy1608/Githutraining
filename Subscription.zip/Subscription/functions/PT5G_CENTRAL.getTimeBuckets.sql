/*
Database : PT5G_CENTRAL
Function: getTimeBuckets
Retrieved: 
*/
DELIMITER //
CREATE OR REPLACE FUNCTION `getTimeBuckets`(pStartDate datetime NOT NULL, pbacklogDays int(11) NOT NULL, pInterval varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL) RETURNS array(timestamp NULL) AS
  /*!
	FUNCTION DESC           : Generating 15MIN/HOURLY/DAILY Intervals for backlog days
                                Example invocation - SELECT TABLE_COL FROM TABLE(getTimeBuckets('2023-12-26 21:00:00',1,'INTERVAL_HOURLY'));
                                    The procedure will do the following.
                                        1) get backlogDays as input for how many days to be generate with startdate as pStartDate
                                        2) Interval will be INTERVAL_DAILY,INTERVAL_HOURLY,INTERVAL_15MIN
                                        3) Based on intervals calculate the timestamp and return as array
  */

DECLARE
  vbacklogDays  INT;
  vTimeStamp    TIMESTAMP ;
  vCurrentDate  DATE DEFAULT CURRENT_DATE;
  vStartTime    TIMESTAMP;
  vEndTime      TIMESTAMP;
  vInterval     VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_bin NULL;
  vDays         INT;
  vMinCnt       INT;
  vMins         TIMESTAMP;
  v15Mins       TIMESTAMP;
  v15MinCnt     INT;
  vHMins        TIMESTAMP;
  vHMinCnt      INT;
  vDMins        TIMESTAMP;
  vDMinCnt      INT;
  varrDays      ARRAY(TIMESTAMP);
BEGIN
  vbacklogDays 	= pbacklogDays;
  vInterval 	= pInterval;
  vMinCnt 		= vbacklogDays * 1440;

  vTimeStamp = DATE_SUB(pStartDate,INTERVAL vbacklogDays DAY);
  vStartTime = vTimeStamp;
  vEndTime   = DATE_SUB(DATE_ADD(vStartTime,INTERVAL vbacklogDays DAY),INTERVAL 1 MINUTE);

	IF vInterval = 'INTERVAL_DAILY' THEN
		vDMins 	 = vStartTime;
        vDMinCnt = CEIL(vMinCnt / 1440);
        varrDays = CREATE_ARRAY(vDMinCnt);

        FOR i IN 0 .. vDMinCnt-1 LOOP
			vDMins 		= DATE_TRUNC('DAY',vDMins);
			varrDays[i] = vDMins;
			vDMins 		= DATE_ADD( vDMins,INTERVAL 1 DAY);
        END LOOP;

	ELSIF vInterval = 'INTERVAL_HOURLY' THEN
			vHMins 		= vStartTime;
			vHMinCnt 	= CEIL(vMinCnt / 60);
			varrDays 	= CREATE_ARRAY(vHMinCnt);

        FOR i IN 0 .. vHMinCnt-1 LOOP
			varrDays[i] = vHMins;
			vHMins 		= DATE_ADD( vHMins,INTERVAL 1 HOUR);
        END LOOP;

	ELSIF vInterval = 'INTERVAL_15MIN' THEN
			v15Mins 	= vStartTime;
			v15MinCnt 	= (vMinCnt / 60) * 4;
			varrDays 	= CREATE_ARRAY(v15MinCnt);

        FOR i IN 0 .. v15MinCnt-1 LOOP
			varrDays[i] = v15Mins;
			v15Mins 	= DATE_ADD( v15Mins,INTERVAL 15 MINUTE);
		END LOOP;
	END IF;
RETURN varrDays;
END;
//
DELIMITER ;

