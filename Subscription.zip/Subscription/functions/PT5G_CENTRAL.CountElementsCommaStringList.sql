DELIMITER //
CREATE OR REPLACE FUNCTION CountElementsCommaString(pInputString text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL) RETURNS int AS
DECLARE
vInputString text;
vInputArray array(text);
vCountElements int;

BEGIN

vInputString=replace(pInputString,' ','');

vInputArray=split(vInputString,',');

vCountElements=length(vInputArray);

RETURN vCountElements;

END;
//
DELIMITER ;